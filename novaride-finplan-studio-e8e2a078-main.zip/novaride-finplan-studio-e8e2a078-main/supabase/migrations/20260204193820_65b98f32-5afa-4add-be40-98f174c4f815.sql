-- Enum pour les niveaux tarifaires
CREATE TYPE public.pricing_tier AS ENUM ('bronze', 'silver', 'gold');

-- Enum pour les statuts de client
CREATE TYPE public.customer_status AS ENUM ('prospect', 'active', 'inactive');

-- Enum pour les statuts de commande
CREATE TYPE public.order_status AS ENUM ('draft', 'confirmed', 'in_progress', 'delivered', 'cancelled');

-- Enum pour les types d'interaction
CREATE TYPE public.interaction_type AS ENUM ('call', 'email', 'meeting', 'note');

-- Table principale des clients
CREATE TABLE public.customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_name TEXT NOT NULL,
    contact_name TEXT,
    email TEXT,
    phone TEXT,
    address TEXT,
    city TEXT,
    postal_code TEXT,
    country TEXT DEFAULT 'France',
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    status customer_status NOT NULL DEFAULT 'prospect',
    pricing_tier pricing_tier NOT NULL DEFAULT 'bronze',
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Remises par niveau tarifaire
CREATE TABLE public.pricing_tier_discounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tier pricing_tier NOT NULL UNIQUE,
    discount_percentage DECIMAL(5, 2) NOT NULL DEFAULT 0,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Insérer les valeurs par défaut des remises
INSERT INTO public.pricing_tier_discounts (tier, discount_percentage, description) VALUES
    ('bronze', 0, 'Tarif standard sans remise'),
    ('silver', 10, 'Remise partenaire'),
    ('gold', 20, 'Remise premium');

-- Interactions/discussions avec les clients
CREATE TABLE public.customer_interactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES public.customers(id) ON DELETE CASCADE NOT NULL,
    interaction_type interaction_type NOT NULL DEFAULT 'note',
    subject TEXT NOT NULL,
    content TEXT,
    interaction_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Rendez-vous et actions planifiées
CREATE TABLE public.customer_appointments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES public.customers(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    appointment_date TIMESTAMP WITH TIME ZONE NOT NULL,
    duration_minutes INTEGER DEFAULT 60,
    location TEXT,
    is_completed BOOLEAN DEFAULT false,
    assigned_to UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Commandes simplifiées
CREATE TABLE public.customer_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES public.customers(id) ON DELETE CASCADE NOT NULL,
    order_reference TEXT NOT NULL,
    order_date DATE NOT NULL DEFAULT CURRENT_DATE,
    expected_delivery_date DATE,
    total_amount DECIMAL(12, 2) NOT NULL DEFAULT 0,
    status order_status NOT NULL DEFAULT 'draft',
    product_category TEXT,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pricing_tier_discounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_interactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_orders ENABLE ROW LEVEL SECURITY;

-- RLS Policies for customers
CREATE POLICY "Authenticated users can view customers"
ON public.customers FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Users with write access can insert customers"
ON public.customers FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL AND (has_role(auth.uid(), 'admin') OR user_can_write_any_tab(auth.uid())));

CREATE POLICY "Users with write access can update customers"
ON public.customers FOR UPDATE
USING (auth.uid() IS NOT NULL AND (has_role(auth.uid(), 'admin') OR user_can_write_any_tab(auth.uid())));

CREATE POLICY "Admins can delete customers"
ON public.customers FOR DELETE
USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for pricing_tier_discounts (read-only for most, admin can modify)
CREATE POLICY "Everyone can view pricing tiers"
ON public.pricing_tier_discounts FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can manage pricing tiers"
ON public.pricing_tier_discounts FOR ALL
USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for customer_interactions
CREATE POLICY "Authenticated users can view interactions"
ON public.customer_interactions FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Users with write access can create interactions"
ON public.customer_interactions FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL AND (has_role(auth.uid(), 'admin') OR user_can_write_any_tab(auth.uid())));

CREATE POLICY "Users with write access can update interactions"
ON public.customer_interactions FOR UPDATE
USING (auth.uid() IS NOT NULL AND (has_role(auth.uid(), 'admin') OR user_can_write_any_tab(auth.uid())));

CREATE POLICY "Admins can delete interactions"
ON public.customer_interactions FOR DELETE
USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for customer_appointments
CREATE POLICY "Authenticated users can view appointments"
ON public.customer_appointments FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Users with write access can create appointments"
ON public.customer_appointments FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL AND (has_role(auth.uid(), 'admin') OR user_can_write_any_tab(auth.uid())));

CREATE POLICY "Users with write access can update appointments"
ON public.customer_appointments FOR UPDATE
USING (auth.uid() IS NOT NULL AND (has_role(auth.uid(), 'admin') OR user_can_write_any_tab(auth.uid())));

CREATE POLICY "Admins can delete appointments"
ON public.customer_appointments FOR DELETE
USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for customer_orders
CREATE POLICY "Authenticated users can view orders"
ON public.customer_orders FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Users with write access can create orders"
ON public.customer_orders FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL AND (has_role(auth.uid(), 'admin') OR user_can_write_any_tab(auth.uid())));

CREATE POLICY "Users with write access can update orders"
ON public.customer_orders FOR UPDATE
USING (auth.uid() IS NOT NULL AND (has_role(auth.uid(), 'admin') OR user_can_write_any_tab(auth.uid())));

CREATE POLICY "Admins can delete orders"
ON public.customer_orders FOR DELETE
USING (has_role(auth.uid(), 'admin'));

-- Triggers for updated_at
CREATE TRIGGER update_customers_updated_at
BEFORE UPDATE ON public.customers
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_pricing_tier_discounts_updated_at
BEFORE UPDATE ON public.pricing_tier_discounts
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_customer_appointments_updated_at
BEFORE UPDATE ON public.customer_appointments
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_customer_orders_updated_at
BEFORE UPDATE ON public.customer_orders
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
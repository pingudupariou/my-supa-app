-- Table pour stocker les snapshots de manière persistante
CREATE TABLE public.snapshots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  comment TEXT,
  state_data JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Activer RLS
ALTER TABLE public.snapshots ENABLE ROW LEVEL SECURITY;

-- Fonction pour vérifier si l'utilisateur a des droits d'écriture sur au moins un onglet
CREATE OR REPLACE FUNCTION public.user_can_write_any_tab(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 
    FROM public.tab_permissions tp
    JOIN public.user_roles ur ON ur.role = tp.role
    WHERE ur.user_id = _user_id 
      AND tp.permission = 'write'
  )
$$;

-- Politique: Seuls les admins et utilisateurs avec droits d'écriture peuvent créer des snapshots
CREATE POLICY "Users with write access can create snapshots"
ON public.snapshots
FOR INSERT
WITH CHECK (
  auth.uid() = user_id 
  AND (
    public.has_role(auth.uid(), 'admin') 
    OR public.user_can_write_any_tab(auth.uid())
  )
);

-- Politique: Les utilisateurs peuvent voir leurs propres snapshots
CREATE POLICY "Users can view their own snapshots"
ON public.snapshots
FOR SELECT
USING (auth.uid() = user_id);

-- Politique: Seuls les admins et utilisateurs avec droits d'écriture peuvent modifier leurs snapshots
CREATE POLICY "Users with write access can update their snapshots"
ON public.snapshots
FOR UPDATE
USING (
  auth.uid() = user_id 
  AND (
    public.has_role(auth.uid(), 'admin') 
    OR public.user_can_write_any_tab(auth.uid())
  )
);

-- Politique: Seuls les admins et utilisateurs avec droits d'écriture peuvent supprimer leurs snapshots
CREATE POLICY "Users with write access can delete their snapshots"
ON public.snapshots
FOR DELETE
USING (
  auth.uid() = user_id 
  AND (
    public.has_role(auth.uid(), 'admin') 
    OR public.user_can_write_any_tab(auth.uid())
  )
);

-- Index pour les performances
CREATE INDEX idx_snapshots_user_id ON public.snapshots(user_id);
CREATE INDEX idx_snapshots_created_at ON public.snapshots(created_at DESC);
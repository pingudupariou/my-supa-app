-- Supprimer l'ancienne politique de lecture
DROP POLICY IF EXISTS "Users can view their own snapshots" ON public.snapshots;

-- Nouvelle politique: Tous les utilisateurs authentifiés peuvent voir toutes les sauvegardes
CREATE POLICY "All authenticated users can view snapshots"
ON public.snapshots
FOR SELECT
USING (auth.uid() IS NOT NULL);
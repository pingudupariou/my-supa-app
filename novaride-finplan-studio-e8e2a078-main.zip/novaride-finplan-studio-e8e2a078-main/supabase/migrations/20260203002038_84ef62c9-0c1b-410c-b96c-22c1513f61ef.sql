-- Create function to update timestamps FIRST
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create app_role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'finance', 'board', 'investisseur', 'lecteur');

-- Create tab_permission enum
CREATE TYPE public.tab_permission AS ENUM ('hidden', 'read', 'write');

-- Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  email TEXT,
  display_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL DEFAULT 'lecteur',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

-- Create tab_permissions table (the matrix)
CREATE TABLE public.tab_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role app_role NOT NULL,
  tab_key TEXT NOT NULL,
  permission tab_permission NOT NULL DEFAULT 'hidden',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (role, tab_key)
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tab_permissions ENABLE ROW LEVEL SECURITY;

-- Triggers for updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_tab_permissions_updated_at
  BEFORE UPDATE ON public.tab_permissions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Security definer function to check role (prevents RLS recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Function to get user's primary role
CREATE OR REPLACE FUNCTION public.get_user_role(_user_id UUID)
RETURNS app_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.user_roles
  WHERE user_id = _user_id
  ORDER BY 
    CASE role 
      WHEN 'admin' THEN 1 
      WHEN 'finance' THEN 2 
      WHEN 'board' THEN 3 
      WHEN 'investisseur' THEN 4 
      ELSE 5 
    END
  LIMIT 1
$$;

-- Function to get tab permission for a user
CREATE OR REPLACE FUNCTION public.get_tab_permission(_user_id UUID, _tab_key TEXT)
RETURNS tab_permission
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT tp.permission 
     FROM public.tab_permissions tp
     JOIN public.user_roles ur ON ur.role = tp.role
     WHERE ur.user_id = _user_id AND tp.tab_key = _tab_key
     ORDER BY 
       CASE tp.permission 
         WHEN 'write' THEN 1 
         WHEN 'read' THEN 2 
         ELSE 3 
       END
     LIMIT 1),
    'hidden'::tab_permission
  )
$$;

-- RLS Policies for profiles
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all profiles"
  ON public.profiles FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all roles"
  ON public.user_roles FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage roles"
  ON public.user_roles FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for tab_permissions
CREATE POLICY "Everyone can read permissions"
  ON public.tab_permissions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage permissions"
  ON public.tab_permissions FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- Trigger to create profile and default role on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, display_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)));
  
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'lecteur');
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Insert default permissions matrix
INSERT INTO public.tab_permissions (role, tab_key, permission) VALUES
('admin', 'home', 'write'),
('admin', 'product-plan', 'write'),
('admin', 'organisation', 'write'),
('admin', 'charges', 'write'),
('admin', 'funding', 'write'),
('admin', 'scenarios', 'write'),
('admin', 'valuation', 'write'),
('admin', 'investment-summary', 'write'),
('finance', 'home', 'read'),
('finance', 'product-plan', 'write'),
('finance', 'organisation', 'write'),
('finance', 'charges', 'write'),
('finance', 'funding', 'write'),
('finance', 'scenarios', 'write'),
('finance', 'valuation', 'write'),
('finance', 'investment-summary', 'write'),
('board', 'home', 'read'),
('board', 'product-plan', 'read'),
('board', 'organisation', 'read'),
('board', 'charges', 'read'),
('board', 'funding', 'read'),
('board', 'scenarios', 'read'),
('board', 'valuation', 'read'),
('board', 'investment-summary', 'read'),
('investisseur', 'home', 'read'),
('investisseur', 'product-plan', 'hidden'),
('investisseur', 'organisation', 'hidden'),
('investisseur', 'charges', 'hidden'),
('investisseur', 'funding', 'hidden'),
('investisseur', 'scenarios', 'hidden'),
('investisseur', 'valuation', 'read'),
('investisseur', 'investment-summary', 'read'),
('lecteur', 'home', 'read'),
('lecteur', 'product-plan', 'hidden'),
('lecteur', 'organisation', 'hidden'),
('lecteur', 'charges', 'hidden'),
('lecteur', 'funding', 'hidden'),
('lecteur', 'scenarios', 'hidden'),
('lecteur', 'valuation', 'hidden'),
('lecteur', 'investment-summary', 'read');
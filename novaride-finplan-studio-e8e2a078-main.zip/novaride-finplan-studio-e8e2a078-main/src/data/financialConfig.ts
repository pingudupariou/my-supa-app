// Novaride Financial Configuration
// All financial data in one place for easy updates

export interface YearlyFinancials {
  year: number;
  revenue: number;
  grossMargin: number;
  payroll: number;
  externalCosts: number;
  depreciation: number;
  cash: number;
  inventory: number;
}

export interface ScenarioData {
  name: string;
  revenueYear5: number;
  ebitdaYear5: number;
  growthRates: number[];
  marginProgression: number[];
}

export interface FundingAllocation {
  hiring: number;
  inventory: number;
  rd: number;
  marketing: number;
  buffer: number;
}

// Historical Financial Data
export const historicalData: YearlyFinancials[] = [
  {
    year: 2023,
    revenue: 420000,
    grossMargin: 0.65,
    payroll: 180000,
    externalCosts: 95000,
    depreciation: 45000,
    cash: 150000,
    inventory: 120000,
  },
  {
    year: 2024,
    revenue: 650000,
    grossMargin: 0.68,
    payroll: 265000,
    externalCosts: 140000,
    depreciation: 85000,
    cash: 280000,
    inventory: 175000,
  },
  {
    year: 2025,
    revenue: 880000,
    grossMargin: 0.70,
    payroll: 353000,
    externalCosts: 180000,
    depreciation: 136000,
    cash: 400000,
    inventory: 230000,
  },
];

// Current Snapshot (2025)
export const currentSnapshot = {
  revenue: 880000,
  grossMargin: 0.70,
  cash: 400000,
  inventory: 230000,
  monthlyBurn: 45000,
};

// Revenue Split Defaults
export const revenueSplitDefaults = {
  b2c: 0.45,
  b2b: 0.35,
  oem: 0.20,
};

// Cost Structure Defaults
export const costStructureDefaults = {
  payroll: 353000,
  marketing: 50000,
  rd: 80000,
  externalCosts: 180000,
  inventoryRatio: 0.30,
  grossMargin: 0.70,
};

// Default Funding Configuration
export const defaultFunding: FundingAllocation = {
  hiring: 800000,
  inventory: 300000,
  rd: 250000,
  marketing: 350000,
  buffer: 300000,
};

export const fundingDefaults = {
  amount: 2000000,
  preMoneyValuation: 8000000,
  allocation: defaultFunding,
};

// Scenarios
export const scenarios: Record<string, ScenarioData> = {
  conservative: {
    name: 'Conservative',
    revenueYear5: 3000000,
    ebitdaYear5: 700000,
    growthRates: [0.30, 0.28, 0.25, 0.22, 0.20],
    marginProgression: [0.70, 0.71, 0.72, 0.72, 0.73],
  },
  base: {
    name: 'Base',
    revenueYear5: 4000000,
    ebitdaYear5: 1390000,
    growthRates: [0.40, 0.35, 0.32, 0.28, 0.25],
    marginProgression: [0.70, 0.72, 0.74, 0.75, 0.76],
  },
  ambitious: {
    name: 'Ambitious',
    revenueYear5: 5000000,
    ebitdaYear5: 1900000,
    growthRates: [0.55, 0.45, 0.38, 0.32, 0.28],
    marginProgression: [0.70, 0.73, 0.76, 0.78, 0.80],
  },
};

// Helper Functions
export function calculateGrossProfit(revenue: number, grossMargin: number): number {
  return revenue * grossMargin;
}

export function calculateEBITDA(grossProfit: number, payroll: number, externalCosts: number): number {
  return grossProfit - payroll - externalCosts;
}

export function calculateOperatingResult(ebitda: number, depreciation: number): number {
  return ebitda - depreciation;
}

export function calculateRunway(cash: number, monthlyBurn: number): number {
  if (monthlyBurn <= 0) return Infinity;
  return Math.floor(cash / monthlyBurn);
}

export function formatCurrency(amount: number, compact = false): string {
  if (compact) {
    if (amount >= 1000000) {
      return `${(amount / 1000000).toFixed(1)}M€`;
    }
    if (amount >= 1000) {
      return `${(amount / 1000).toFixed(0)}k€`;
    }
  }
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatPercent(value: number, decimals = 1): string {
  return `${(value * 100).toFixed(decimals)}%`;
}

export function calculateCAGR(startValue: number, endValue: number, years: number): number {
  if (startValue <= 0 || years <= 0) return 0;
  return Math.pow(endValue / startValue, 1 / years) - 1;
}

// Generate projections based on scenario
export function generateProjections(scenario: ScenarioData, baseYear: YearlyFinancials): YearlyFinancials[] {
  const projections: YearlyFinancials[] = [];
  let currentRevenue = baseYear.revenue;
  
  for (let i = 0; i < 5; i++) {
    const growth = scenario.growthRates[i];
    const margin = scenario.marginProgression[i];
    currentRevenue = currentRevenue * (1 + growth);
    
    const grossProfit = calculateGrossProfit(currentRevenue, margin);
    const payrollRatio = 0.40 - (i * 0.02); // Improving efficiency
    const externalRatio = 0.20 - (i * 0.01);
    
    projections.push({
      year: baseYear.year + i + 1,
      revenue: currentRevenue,
      grossMargin: margin,
      payroll: currentRevenue * payrollRatio,
      externalCosts: currentRevenue * externalRatio,
      depreciation: currentRevenue * 0.10,
      cash: baseYear.cash + (grossProfit * 0.3 * (i + 1)),
      inventory: currentRevenue * 0.25,
    });
  }
  
  return projections;
}

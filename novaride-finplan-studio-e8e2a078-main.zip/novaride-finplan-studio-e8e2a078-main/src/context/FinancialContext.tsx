// ============================================
// CONTEXTE FINANCIER UNIFIÉ
// Source unique de vérité pour tout le modèle
// ============================================

import React, { createContext, useContext, useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { toast } from '@/hooks/use-toast';
import {
  Product,
  Role,
  Expense,
  GlobalAssumptions,
  Scenario,
  FundingRound,
  UseOfFunds,
  CapTableEntry,
  FinancialSummary,
  ValidationAlert,
  Quarter,
} from '@/engine/types';
import {
  generateFinancialProjections,
  validateFinancialModel,
  calculatePayroll,
  calculateHeadcount,
} from '@/engine/calculations';
import {
  defaultProducts,
  defaultRoles,
  defaultExpenses,
  defaultAssumptions,
  defaultScenarios,
  defaultFundingRounds,
  defaultUseOfFunds,
  defaultCapTable,
} from '@/engine/defaults';
import {
  calculateTreasuryProjection,
  TreasuryProjection,
  YearlyProjection,
} from '@/engine/treasuryEngine';
import {
  MonthlyTreasuryConfig,
  MonthlyTreasuryProjection,
  calculateMonthlyTreasuryProjection,
  getDefaultMonthlyTreasuryConfig,
  VariableChargeConfig,
  LoanConfig,
  SeasonalityConfig,
  CapexPaymentConfig,
} from '@/engine/monthlyTreasuryEngine';

// ==================
// TYPES
// ==================

export type ViewMode = 'builder' | 'investor';

// Configuration des scénarios (ajustements % par rapport au Plan Produit)
export interface ScenarioConfig {
  volumeAdjustment: number;  // -0.20 à +0.30
  priceAdjustment: number;
  opexAdjustment: number;
  marginAdjustment: number;
}

// Données historiques éditables
export interface HistoricalYearData {
  year: number;
  revenue: number;
  grossMargin: number;
  payroll: number;
  externalCosts: number;
  depreciation: number;
  cash: number;
  inventory: number;
}

// Configuration des prix globale
export interface GlobalPricingConfig {
  b2bDiscount: number;
  b2bLogisticsCost: number;
  b2bMinMargin: number;
  oemDiscount: number;
  oemMinVolume: number;
  oemMinMargin: number;
  vatRate: number;
}

// Configuration mode OPEX (détaillé vs simplifié)
export interface SimpleOpexConfig {
  baseAmount: number;      // Montant annuel de base
  growthRate: number;      // Taux d'évolution annuel (ex: 0.05 = 5%)
}

// Configuration mode CA (par produit vs global par canal)
export type RevenueMode = 'by-product' | 'by-channel-global';

export interface ChannelRevenueConfig {
  baseAmount: number;
  growthRate: number;
  marginRate: number;  // Taux de marge brute (ex: 0.65 = 65%)
}

export interface GlobalRevenueConfig {
  baseYear: number;
  B2C: ChannelRevenueConfig;
  B2B: ChannelRevenueConfig;
  OEM: ChannelRevenueConfig;
}

// Configuration scénario avec période et trésorerie
export interface ScenarioSettings {
  startYear: number;
  durationYears: number;
  initialCash: number;  // Trésorerie initiale T0 (unique)
}

interface FinancialState {
  // Données sources uniques
  products: Product[];
  roles: Role[];
  expenses: Expense[];
  assumptions: GlobalAssumptions;
  
  // Historique financier éditable
  historicalData: HistoricalYearData[];
  
  // Configuration prix globale
  pricingConfig: GlobalPricingConfig;
  
  // Scénarios
  scenarios: Scenario[];
  activeScenarioId: 'conservative' | 'base' | 'ambitious';
  scenarioConfigs: Record<string, ScenarioConfig>;
  scenarioSettings: ScenarioSettings;
  
  // Financement - UNE SEULE LEVÉE
  fundingRounds: FundingRound[];
  useOfFunds: UseOfFunds;
  capTable: CapTableEntry[];
  fundingPeriod: { start: number; end: number };
  
  // Mode OPEX (détaillé vs simplifié)
  opexMode: 'detailed' | 'simple';
  simpleOpexConfig: SimpleOpexConfig;
  
  // Mode CA (par produit vs global par canal)
  revenueMode: RevenueMode;
  globalRevenueConfig: GlobalRevenueConfig;
  
  // Option Prévisionnel : exclure le financement des calculs
  excludeFundingFromTreasury: boolean;
  
  // Configuration du plan de trésorerie mensuel
  monthlyTreasuryConfig: MonthlyTreasuryConfig;
  
  // UI
  viewMode: ViewMode;
  
  // Persistance
  lastSaved: string | null;
  hasUnsavedChanges: boolean;
}

interface ComputedMetrics {
  // Projection de trésorerie unifiée (source unique)
  treasuryProjection: TreasuryProjection;
  
  // Projection de trésorerie mensuelle (source unique pour le détail mensuel)
  monthlyTreasuryProjection: MonthlyTreasuryProjection;
  
  // Revenus par année (depuis Plan Produit)
  revenueByYear: { year: number; revenue: number; cogs: number }[];
  
  // Masse salariale par année (depuis Organigramme)
  payrollByYear: { year: number; payroll: number; headcount: number }[];
  
  // OPEX par année (depuis Structure des Charges)
  opexByYear: { year: number; opex: number; byCategory: Record<string, number> }[];
  
  // CAPEX par année (depuis Plan Produit - dev costs)
  capexByYear: { year: number; capex: number; depreciation: number }[];
  
  // Projections financières complètes
  baseProjections: FinancialSummary;
  scenarioProjections: Record<string, FinancialSummary>;
  activeProjections: FinancialSummary;
  
  // Besoin de financement (depuis treasuryProjection)
  fundingNeedsByYear: { year: number; need: number; cumulative: number }[];
  totalFundingNeed: number;
  
  // Valorisation
  postMoneyValuation: number;
  equityDilution: number;
  
  // Alertes
  alerts: ValidationAlert[];
  activeScenarioData: Scenario;
  
  // KPIs clés
  currentPayroll: number;
  totalHeadcount: number;
  totalDevCost: number;
}

// ==================
// DONNÉES PAR DÉFAUT
// ==================

const defaultScenarioConfigs: Record<string, ScenarioConfig> = {
  conservative: {
    volumeAdjustment: -0.20,
    priceAdjustment: 0,
    opexAdjustment: 0.10,
    marginAdjustment: -0.05,
  },
  base: {
    volumeAdjustment: 0,
    priceAdjustment: 0,
    opexAdjustment: 0,
    marginAdjustment: 0,
  },
  ambitious: {
    volumeAdjustment: 0.25,
    priceAdjustment: 0.05,
    opexAdjustment: -0.10,
    marginAdjustment: 0.05,
  },
};

const STORAGE_KEY = 'novaride_financial_state_v5';

const defaultHistoricalData: HistoricalYearData[] = [
  {
    year: 2023,
    revenue: 420000,
    grossMargin: 0.65,
    payroll: 180000,
    externalCosts: 95000,
    depreciation: 45000,
    cash: 150000,
    inventory: 120000,
  },
  {
    year: 2024,
    revenue: 650000,
    grossMargin: 0.68,
    payroll: 265000,
    externalCosts: 140000,
    depreciation: 85000,
    cash: 280000,
    inventory: 175000,
  },
  {
    year: 2025,
    revenue: 880000,
    grossMargin: 0.70,
    payroll: 353000,
    externalCosts: 180000,
    depreciation: 136000,
    cash: 400000,
    inventory: 230000,
  },
];

const defaultPricingConfig: GlobalPricingConfig = {
  b2bDiscount: 0.25,
  b2bLogisticsCost: 12,
  b2bMinMargin: 0.25,
  oemDiscount: 0.40,
  oemMinVolume: 500,
  oemMinMargin: 0.15,
  vatRate: 0.20,
};

const defaultScenarioSettings: ScenarioSettings = {
  startYear: 2025,
  durationYears: 5,
  initialCash: 100000,  // Trésorerie initiale T0 unique
};

const defaultSimpleOpexConfig: SimpleOpexConfig = {
  baseAmount: 200000,  // Montant OPEX annuel de base
  growthRate: 0.05,    // 5% d'évolution par an
};

const defaultGlobalRevenueConfig: GlobalRevenueConfig = {
  baseYear: 2025,
  B2C: { baseAmount: 150000, growthRate: 0.15, marginRate: 0.65 },
  B2B: { baseAmount: 250000, growthRate: 0.20, marginRate: 0.45 },
  OEM: { baseAmount: 100000, growthRate: 0.25, marginRate: 0.25 },
};

function loadState(): Partial<FinancialState> | null {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return JSON.parse(stored);
  } catch (e) {
    console.warn('Failed to load financial state:', e);
  }
  return null;
}

function getInitialState(): FinancialState {
  const loaded = loadState();
  
  // Migration des fundingRounds sans quarter
  const migratedRounds = (loaded?.fundingRounds || defaultFundingRounds).map(r => ({
    ...r,
    quarter: (r as any).quarter || 'Q1' as Quarter,
  }));
  
  return {
    products: loaded?.products || defaultProducts,
    roles: loaded?.roles || defaultRoles,
    expenses: loaded?.expenses || defaultExpenses,
    assumptions: loaded?.assumptions || defaultAssumptions,
    historicalData: loaded?.historicalData || defaultHistoricalData,
    pricingConfig: loaded?.pricingConfig || defaultPricingConfig,
    scenarios: loaded?.scenarios || defaultScenarios,
    activeScenarioId: loaded?.activeScenarioId || 'base',
    scenarioConfigs: loaded?.scenarioConfigs || defaultScenarioConfigs,
    scenarioSettings: loaded?.scenarioSettings || defaultScenarioSettings,
    fundingRounds: migratedRounds,
    useOfFunds: loaded?.useOfFunds || defaultUseOfFunds,
    capTable: loaded?.capTable || defaultCapTable,
    fundingPeriod: loaded?.fundingPeriod || { start: 2025, end: 2028 },
    opexMode: loaded?.opexMode || 'detailed',
    simpleOpexConfig: loaded?.simpleOpexConfig || defaultSimpleOpexConfig,
    revenueMode: (loaded as any)?.revenueMode || 'by-product',
    globalRevenueConfig: (loaded as any)?.globalRevenueConfig || defaultGlobalRevenueConfig,
    excludeFundingFromTreasury: (loaded as any)?.excludeFundingFromTreasury || false,
    monthlyTreasuryConfig: (loaded as any)?.monthlyTreasuryConfig || getDefaultMonthlyTreasuryConfig(),
    viewMode: 'builder',
    lastSaved: loaded?.lastSaved || null,
    hasUnsavedChanges: false,
  };
}

// ==================
// CONTEXTE
// ==================

interface FinancialContextType {
  state: FinancialState;
  computed: ComputedMetrics;
  
  // Actions Plan Produit
  updateProducts: (products: Product[]) => void;
  addProduct: (product: Product) => void;
  removeProduct: (id: string) => void;
  
  // Actions Organisation
  updateRoles: (roles: Role[]) => void;
  addRole: (role: Role) => void;
  removeRole: (id: string) => void;
  
  // Actions Charges
  updateExpenses: (expenses: Expense[]) => void;
  addExpense: (expense: Expense) => void;
  removeExpense: (id: string) => void;
  setOpexMode: (mode: 'detailed' | 'simple') => void;
  updateSimpleOpexConfig: (config: Partial<SimpleOpexConfig>) => void;
  
  // Actions Mode CA
  setRevenueMode: (mode: RevenueMode) => void;
  updateGlobalRevenueConfig: (config: Partial<GlobalRevenueConfig>) => void;
  setExcludeFundingFromTreasury: (exclude: boolean) => void;
  
  // Actions Trésorerie mensuelle
  updateMonthlyTreasuryConfig: (config: Partial<MonthlyTreasuryConfig>) => void;
  updateRevenueSeasonality: (seasonality: SeasonalityConfig) => void;
  updateCogsSeasonality: (seasonality: SeasonalityConfig) => void;
  updateVariableCharges: (charges: VariableChargeConfig[]) => void;
  updateLoans: (loans: LoanConfig[]) => void;
  updateCapexPayments: (payments: CapexPaymentConfig[]) => void;
  
  // Actions Scénarios
  setActiveScenario: (id: 'conservative' | 'base' | 'ambitious') => void;
  updateScenarioConfig: (id: string, config: Partial<ScenarioConfig>) => void;
  updateScenarioSettings: (settings: Partial<ScenarioSettings>) => void;
  
  // Actions Financement
  updateFundingRounds: (rounds: FundingRound[]) => void;
  updateUseOfFunds: (useOfFunds: Partial<UseOfFunds>) => void;
  setFundingPeriod: (period: { start: number; end: number }) => void;
  
  // Actions Historique
  updateHistoricalData: (data: HistoricalYearData[]) => void;
  
  // Actions Prix
  updatePricingConfig: (config: Partial<GlobalPricingConfig>) => void;
  
  // Actions Hypothèses
  updateAssumptions: (assumptions: Partial<GlobalAssumptions>) => void;
  
  // UI
  setViewMode: (mode: ViewMode) => void;
  
  // Persistance
  saveAll: () => boolean;
  resetToDefaults: () => void;
}

const FinancialContext = createContext<FinancialContextType | null>(null);

// ==================
// FONCTIONS DE CALCUL LEGACY (pour compatibilité)
// ==================

function calculateRevenueByYear(products: Product[], scenarioConfig: ScenarioConfig, years: number[]) {
  return years.map(year => {
    let revenue = 0;
    let cogs = 0;
    
    products.forEach(product => {
      const volumesByChannel = product.volumesByChannel;
      
      if (volumesByChannel) {
        const priceHT_B2C = product.priceHT || (product.priceTTC_B2C / (1 + (product.vatRate || 0.20)));
        const coef_shop = product.coef_shop || 1.6;
        const coef_dist = product.coef_dist || 1.3;
        const coef_oem = product.coef_oem || 1.4;
        
        const priceMarqueB2B_HT = priceHT_B2C / coef_shop / coef_dist;
        const priceOEM_HT = product.unitCost * coef_oem;
        
        const volB2C = Math.round((volumesByChannel.B2C[year] || 0) * (1 + scenarioConfig.volumeAdjustment));
        revenue += volB2C * priceHT_B2C * (1 + scenarioConfig.priceAdjustment);
        cogs += volB2C * product.unitCost;
        
        const volB2B = Math.round((volumesByChannel.B2B[year] || 0) * (1 + scenarioConfig.volumeAdjustment));
        revenue += volB2B * priceMarqueB2B_HT * (1 + scenarioConfig.priceAdjustment);
        cogs += volB2B * product.unitCost;
        
        const volOEM = Math.round((volumesByChannel.OEM[year] || 0) * (1 + scenarioConfig.volumeAdjustment));
        revenue += volOEM * priceOEM_HT * (1 + scenarioConfig.priceAdjustment);
        cogs += volOEM * product.unitCost;
      } else if (product.volumesByYear[year]) {
        const volume = Math.round(product.volumesByYear[year] * (1 + scenarioConfig.volumeAdjustment));
        revenue += volume * product.priceHT * (1 + scenarioConfig.priceAdjustment);
        cogs += volume * product.unitCost;
      }
    });
    
    return { year, revenue, cogs };
  });
}

// Calcul CA mode global par canal avec marges spécifiques
function calculateGlobalRevenueByYear(
  config: GlobalRevenueConfig,
  years: number[],
  scenarioConfig: ScenarioConfig
) {
  return years.map((year, yearIndex) => {
    // CA par canal
    const b2c = config.B2C.baseAmount * Math.pow(1 + config.B2C.growthRate, yearIndex);
    const b2b = config.B2B.baseAmount * Math.pow(1 + config.B2B.growthRate, yearIndex);
    const oem = config.OEM.baseAmount * Math.pow(1 + config.OEM.growthRate, yearIndex);
    
    // Appliquer les ajustements de scénario
    const adjustedB2C = b2c * (1 + scenarioConfig.volumeAdjustment) * (1 + scenarioConfig.priceAdjustment);
    const adjustedB2B = b2b * (1 + scenarioConfig.volumeAdjustment) * (1 + scenarioConfig.priceAdjustment);
    const adjustedOEM = oem * (1 + scenarioConfig.volumeAdjustment) * (1 + scenarioConfig.priceAdjustment);
    
    const revenue = adjustedB2C + adjustedB2B + adjustedOEM;
    
    // COGS calculé à partir des marges spécifiques par canal
    // COGS = CA * (1 - marge)
    const cogsB2C = adjustedB2C * (1 - config.B2C.marginRate);
    const cogsB2B = adjustedB2B * (1 - config.B2B.marginRate);
    const cogsOEM = adjustedOEM * (1 - config.OEM.marginRate);
    const cogs = cogsB2C + cogsB2B + cogsOEM;
    
    return { year, revenue, cogs };
  });
}

function calculatePayrollByYear(roles: Role[], years: number[]) {
  return years.map(year => {
    const activeRoles = roles.filter(r => r.startYear <= year);
    const payroll = activeRoles.reduce((sum, r) => sum + r.annualCostLoaded, 0);
    const headcount = activeRoles.length;
    return { year, payroll, headcount };
  });
}

function calculateOpexByYear(
  expenses: Expense[],
  revenueByYear: { year: number; revenue: number }[],
  years: number[],
  scenarioConfig: ScenarioConfig,
  opexMode: 'detailed' | 'simple' = 'detailed',
  simpleOpexConfig?: SimpleOpexConfig
) {
  // Mode simplifié : un montant de base avec taux d'évolution
  if (opexMode === 'simple' && simpleOpexConfig) {
    return years.map((year, index) => {
      const opex = simpleOpexConfig.baseAmount * Math.pow(1 + simpleOpexConfig.growthRate, index);
      const adjustedOpex = opex * (1 + scenarioConfig.opexAdjustment);
      return { 
        year, 
        opex: adjustedOpex, 
        byCategory: { 'Total': adjustedOpex } as Record<string, number>
      };
    });
  }
  
  // Mode détaillé : calcul par poste
  return years.map(year => {
    const yearRevenue = revenueByYear.find(r => r.year === year)?.revenue || 0;
    let opex = 0;
    const byCategory: Record<string, number> = {};
    
    expenses.forEach(expense => {
      if (expense.startYear > year) return;
      
      let cost = expense.baseAnnualCost;
      const yearsSinceStart = year - expense.startYear;
      
      switch (expense.evolutionType) {
        case 'fixed':
          break;
        case 'growth_rate':
          cost = expense.baseAnnualCost * Math.pow(1 + (expense.growthRate || 0), yearsSinceStart);
          break;
        case 'linked_to_revenue':
          cost = yearRevenue * (expense.revenueRatio || 0);
          break;
        case 'step':
          const applicableStep = expense.steps?.filter(s => s.year <= year).pop();
          if (applicableStep) cost = applicableStep.newAnnualCost;
          break;
      }
      
      cost = cost * (1 + scenarioConfig.opexAdjustment);
      opex += cost;
      byCategory[expense.category] = (byCategory[expense.category] || 0) + cost;
    });
    
    return { year, opex, byCategory };
  });
}

function calculateCapexByYear(products: Product[], years: number[]) {
  return years.map(year => {
    let capex = 0;
    let depreciation = 0;
    
    products.forEach(product => {
      if (product.launchYear === year) {
        capex += product.devCost;
      }
      
      const amortYears = product.devAmortizationYears || 5;
      if (year >= product.launchYear && year < product.launchYear + amortYears) {
        depreciation += product.devCost / amortYears;
      }
    });
    
    return { year, capex, depreciation };
  });
}

// ==================
// PROVIDER
// ==================

export function FinancialProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<FinancialState>(getInitialState);
  const autosaveTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Autosave: sauvegarde automatique après chaque modification
  const performAutosave = useCallback((stateToSave: FinancialState) => {
    try {
      const toSave = { ...stateToSave, lastSaved: new Date().toISOString(), hasUnsavedChanges: false };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
      setState(prev => ({ ...prev, lastSaved: toSave.lastSaved, hasUnsavedChanges: false }));
    } catch (e) {
      console.error('Autosave failed:', e);
    }
  }, []);

  // Déclenche l'autosave avec debounce
  const triggerAutosave = useCallback((newState: FinancialState) => {
    if (autosaveTimeoutRef.current) {
      clearTimeout(autosaveTimeoutRef.current);
    }
    autosaveTimeoutRef.current = setTimeout(() => {
      performAutosave(newState);
    }, 500); // Debounce de 500ms
  }, [performAutosave]);

  // Helper pour mettre à jour l'état avec autosave
  const updateStateWithAutosave = useCallback((updater: (prev: FinancialState) => FinancialState) => {
    setState(prev => {
      const newState = { ...updater(prev), hasUnsavedChanges: true };
      triggerAutosave(newState);
      return newState;
    });
  }, [triggerAutosave]);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (autosaveTimeoutRef.current) {
        clearTimeout(autosaveTimeoutRef.current);
      }
    };
  }, []);

  // Actions Plan Produit
  const updateProducts = useCallback((products: Product[]) => {
    updateStateWithAutosave(prev => ({ ...prev, products }));
  }, [updateStateWithAutosave]);

  const addProduct = useCallback((product: Product) => {
    updateStateWithAutosave(prev => ({ ...prev, products: [...prev.products, product] }));
  }, [updateStateWithAutosave]);

  const removeProduct = useCallback((id: string) => {
    updateStateWithAutosave(prev => ({ ...prev, products: prev.products.filter(p => p.id !== id) }));
  }, [updateStateWithAutosave]);

  // Actions Organisation
  const updateRoles = useCallback((roles: Role[]) => {
    updateStateWithAutosave(prev => ({ ...prev, roles }));
  }, [updateStateWithAutosave]);

  const addRole = useCallback((role: Role) => {
    updateStateWithAutosave(prev => ({ ...prev, roles: [...prev.roles, role] }));
  }, [updateStateWithAutosave]);

  const removeRole = useCallback((id: string) => {
    updateStateWithAutosave(prev => ({ ...prev, roles: prev.roles.filter(r => r.id !== id) }));
  }, [updateStateWithAutosave]);

  // Actions Charges
  const updateExpenses = useCallback((expenses: Expense[]) => {
    updateStateWithAutosave(prev => ({ ...prev, expenses }));
  }, [updateStateWithAutosave]);

  const addExpense = useCallback((expense: Expense) => {
    updateStateWithAutosave(prev => ({ ...prev, expenses: [...prev.expenses, expense] }));
  }, [updateStateWithAutosave]);

  const removeExpense = useCallback((id: string) => {
    updateStateWithAutosave(prev => ({ ...prev, expenses: prev.expenses.filter(e => e.id !== id) }));
  }, [updateStateWithAutosave]);

  const setOpexMode = useCallback((opexMode: 'detailed' | 'simple') => {
    updateStateWithAutosave(prev => ({ ...prev, opexMode }));
  }, [updateStateWithAutosave]);

  const updateSimpleOpexConfig = useCallback((config: Partial<SimpleOpexConfig>) => {
    updateStateWithAutosave(prev => ({
      ...prev,
      simpleOpexConfig: { ...prev.simpleOpexConfig, ...config },
    }));
  }, [updateStateWithAutosave]);

  // Actions Mode CA
  const setRevenueMode = useCallback((revenueMode: RevenueMode) => {
    updateStateWithAutosave(prev => ({ ...prev, revenueMode }));
  }, [updateStateWithAutosave]);

  const updateGlobalRevenueConfig = useCallback((config: Partial<GlobalRevenueConfig>) => {
    updateStateWithAutosave(prev => ({
      ...prev,
      globalRevenueConfig: { ...prev.globalRevenueConfig, ...config },
    }));
  }, [updateStateWithAutosave]);

  const setExcludeFundingFromTreasury = useCallback((excludeFundingFromTreasury: boolean) => {
    updateStateWithAutosave(prev => ({ ...prev, excludeFundingFromTreasury }));
  }, [updateStateWithAutosave]);

  // Actions Trésorerie mensuelle
  const updateMonthlyTreasuryConfig = useCallback((config: Partial<MonthlyTreasuryConfig>) => {
    updateStateWithAutosave(prev => ({
      ...prev,
      monthlyTreasuryConfig: { ...prev.monthlyTreasuryConfig, ...config },
    }));
  }, [updateStateWithAutosave]);

  const updateRevenueSeasonality = useCallback((seasonality: SeasonalityConfig) => {
    updateStateWithAutosave(prev => ({
      ...prev,
      monthlyTreasuryConfig: { ...prev.monthlyTreasuryConfig, revenueSeasonality: seasonality },
    }));
  }, [updateStateWithAutosave]);

  const updateCogsSeasonality = useCallback((seasonality: SeasonalityConfig) => {
    updateStateWithAutosave(prev => ({
      ...prev,
      monthlyTreasuryConfig: { ...prev.monthlyTreasuryConfig, cogsSeasonality: seasonality },
    }));
  }, [updateStateWithAutosave]);

  const updateVariableCharges = useCallback((variableCharges: VariableChargeConfig[]) => {
    updateStateWithAutosave(prev => ({
      ...prev,
      monthlyTreasuryConfig: { ...prev.monthlyTreasuryConfig, variableCharges },
    }));
  }, [updateStateWithAutosave]);

  const updateLoans = useCallback((loans: LoanConfig[]) => {
    updateStateWithAutosave(prev => ({
      ...prev,
      monthlyTreasuryConfig: { ...prev.monthlyTreasuryConfig, loans },
    }));
  }, [updateStateWithAutosave]);

  const updateCapexPayments = useCallback((capexPayments: CapexPaymentConfig[]) => {
    updateStateWithAutosave(prev => ({
      ...prev,
      monthlyTreasuryConfig: { ...prev.monthlyTreasuryConfig, capexPayments },
    }));
  }, [updateStateWithAutosave]);

  // Actions Scénarios
  const setActiveScenario = useCallback((activeScenarioId: 'conservative' | 'base' | 'ambitious') => {
    updateStateWithAutosave(prev => ({ ...prev, activeScenarioId }));
  }, [updateStateWithAutosave]);

  const updateScenarioConfig = useCallback((id: string, config: Partial<ScenarioConfig>) => {
    updateStateWithAutosave(prev => ({
      ...prev,
      scenarioConfigs: {
        ...prev.scenarioConfigs,
        [id]: { ...prev.scenarioConfigs[id], ...config },
      },
    }));
  }, [updateStateWithAutosave]);

  const updateScenarioSettings = useCallback((settings: Partial<ScenarioSettings>) => {
    updateStateWithAutosave(prev => ({
      ...prev,
      scenarioSettings: { ...prev.scenarioSettings, ...settings },
    }));
  }, [updateStateWithAutosave]);

  // Actions Financement
  const updateFundingRounds = useCallback((fundingRounds: FundingRound[]) => {
    updateStateWithAutosave(prev => ({ ...prev, fundingRounds }));
  }, [updateStateWithAutosave]);

  const updateUseOfFunds = useCallback((useOfFunds: Partial<UseOfFunds>) => {
    updateStateWithAutosave(prev => ({ ...prev, useOfFunds: { ...prev.useOfFunds, ...useOfFunds } }));
  }, [updateStateWithAutosave]);

  const setFundingPeriod = useCallback((fundingPeriod: { start: number; end: number }) => {
    updateStateWithAutosave(prev => ({ ...prev, fundingPeriod }));
  }, [updateStateWithAutosave]);

  // Actions Historique
  const updateHistoricalData = useCallback((historicalData: HistoricalYearData[]) => {
    updateStateWithAutosave(prev => ({ ...prev, historicalData }));
  }, [updateStateWithAutosave]);

  // Actions Prix
  const updatePricingConfig = useCallback((config: Partial<GlobalPricingConfig>) => {
    updateStateWithAutosave(prev => ({
      ...prev,
      pricingConfig: { ...prev.pricingConfig, ...config },
    }));
  }, [updateStateWithAutosave]);

  // Actions Hypothèses
  const updateAssumptions = useCallback((assumptions: Partial<GlobalAssumptions>) => {
    updateStateWithAutosave(prev => ({ ...prev, assumptions: { ...prev.assumptions, ...assumptions } }));
  }, [updateStateWithAutosave]);

  // UI
  const setViewMode = useCallback((viewMode: ViewMode) => {
    setState(prev => ({ ...prev, viewMode }));
  }, []);

  // Persistance manuelle (optionnelle maintenant avec autosave)
  const saveAll = useCallback(() => {
    try {
      const toSave = { ...state, lastSaved: new Date().toISOString(), hasUnsavedChanges: false };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
      setState(toSave);
      toast({ title: "Données sauvegardées", description: "Toutes vos modifications ont été enregistrées." });
      return true;
    } catch (e) {
      console.error('Failed to save state:', e);
      toast({ title: "Erreur de sauvegarde", description: "Impossible d'enregistrer vos modifications.", variant: "destructive" });
      return false;
    }
  }, [state]);

  const resetToDefaults = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setState(getInitialState());
    toast({ title: "Réinitialisation effectuée", description: "Les données par défaut ont été restaurées." });
  }, []);

  // Computed values
  const computed = useMemo((): ComputedMetrics => {
    const { startYear, durationYears, initialCash } = state.scenarioSettings;
    const years = Array.from({ length: durationYears }, (_, i) => startYear + i);
    const activeConfig = state.scenarioConfigs[state.activeScenarioId] || defaultScenarioConfigs.base;
    
    // ======== PROJECTION DE TRÉSORERIE UNIFIÉE ========
    const treasuryProjection = calculateTreasuryProjection(
      state.products,
      state.roles,
      state.expenses,
      state.fundingRounds,
      initialCash,
      startYear,
      durationYears,
      activeConfig,
      state.opexMode,
      state.simpleOpexConfig
    );
    
    // Calculs legacy pour compatibilité avec les autres composants
    // Utilise le mode CA choisi (par produit ou global par canal)
    const revenueByYear = state.revenueMode === 'by-channel-global'
      ? calculateGlobalRevenueByYear(state.globalRevenueConfig, years, activeConfig)
      : calculateRevenueByYear(state.products, activeConfig, years);
    
    const payrollByYear = calculatePayrollByYear(state.roles, years);
    const opexByYear = calculateOpexByYear(state.expenses, revenueByYear, years, activeConfig, state.opexMode, state.simpleOpexConfig);
    const capexByYear = state.revenueMode === 'by-product' 
      ? calculateCapexByYear(state.products, years)
      : years.map(year => ({ year, capex: 0, depreciation: 0 })); // Pas de CAPEX en mode global
    
    // ======== PROJECTION DE TRÉSORERIE MENSUELLE ========
    // Construire les données d'entrée annuelles pour le moteur mensuel
    const annualRevenue: Record<number, number> = {};
    const annualCogs: Record<number, number> = {};
    const annualPayroll: Record<number, number> = {};
    const annualOpex: Record<number, number> = {};
    
    revenueByYear.forEach(r => {
      annualRevenue[r.year] = r.revenue;
      annualCogs[r.year] = r.cogs;
    });
    payrollByYear.forEach(p => {
      annualPayroll[p.year] = p.payroll;
    });
    opexByYear.forEach(o => {
      annualOpex[o.year] = o.opex;
    });
    
    const monthlyTreasuryProjection = calculateMonthlyTreasuryProjection(
      state.monthlyTreasuryConfig,
      { annualRevenue, annualCogs, annualPayroll, annualOpex },
      state.fundingRounds,
      initialCash,
      startYear,
      durationYears,
      state.excludeFundingFromTreasury
    );
    
    // Besoin de financement par année (depuis le moteur unifié)
    let cumulativeNeed = 0;
    const fundingNeedsByYear = treasuryProjection.years.map(yp => {
      // Besoin = quand la tréso fin devient négative
      const needThisYear = yp.treasuryEnd < 0 && yp.treasuryStart >= 0 
        ? Math.abs(yp.treasuryEnd) 
        : yp.treasuryEnd < 0 && yp.treasuryStart < 0 
          ? Math.abs(yp.cashFlow) 
          : 0;
      cumulativeNeed = yp.minTreasuryInYear < 0 ? Math.abs(yp.minTreasuryInYear) : 0;
      return { 
        year: yp.year, 
        need: yp.cashFlow < 0 ? Math.abs(yp.cashFlow) : 0,
        cumulative: treasuryProjection.fundingNeed 
      };
    });
    
    // Total besoin = max(0, -trésorerie minimale)
    const totalFundingNeed = treasuryProjection.fundingNeed;
    
    // Valorisation
    const latestRound = state.fundingRounds[state.fundingRounds.length - 1];
    const postMoneyValuation = latestRound ? latestRound.preMoneyValuation + latestRound.amount : 0;
    const equityDilution = latestRound ? latestRound.amount / postMoneyValuation : 0;
    
    // Projections complètes legacy
    const baseProjections = generateFinancialProjections(
      state.products,
      state.roles,
      state.expenses,
      state.assumptions,
      undefined,
      state.fundingRounds
    );
    
    const scenarioProjections: Record<string, FinancialSummary> = {};
    state.scenarios.forEach(scenario => {
      scenarioProjections[scenario.id] = generateFinancialProjections(
        state.products,
        state.roles,
        state.expenses,
        state.assumptions,
        scenario,
        state.fundingRounds
      );
    });
    
    const activeScenarioData = state.scenarios.find(s => s.id === state.activeScenarioId) || state.scenarios[0];
    const activeProjections = scenarioProjections[state.activeScenarioId] || baseProjections;
    
    const alerts = validateFinancialModel(state.products, state.roles, state.expenses, baseProjections);
    
    // KPIs actuels
    const firstYear = years[0];
    const currentPayroll = payrollByYear.find(p => p.year === firstYear)?.payroll || 0;
    const totalHeadcount = payrollByYear.find(p => p.year === firstYear)?.headcount || 0;
    const totalDevCost = state.products.reduce((sum, p) => sum + p.devCost, 0);
    
    return {
      treasuryProjection,
      monthlyTreasuryProjection,
      revenueByYear,
      payrollByYear,
      opexByYear,
      capexByYear,
      baseProjections,
      scenarioProjections,
      activeProjections,
      fundingNeedsByYear,
      totalFundingNeed,
      postMoneyValuation,
      equityDilution,
      alerts,
      activeScenarioData,
      currentPayroll,
      totalHeadcount,
      totalDevCost,
    };
  }, [state]);

  return (
    <FinancialContext.Provider
      value={{
        state,
        computed,
        updateProducts,
        addProduct,
        removeProduct,
        updateRoles,
        addRole,
        removeRole,
        updateExpenses,
        addExpense,
        removeExpense,
        setOpexMode,
        updateSimpleOpexConfig,
        setRevenueMode,
        updateGlobalRevenueConfig,
        setExcludeFundingFromTreasury,
        updateMonthlyTreasuryConfig,
        updateRevenueSeasonality,
        updateCogsSeasonality,
        updateVariableCharges,
        updateLoans,
        updateCapexPayments,
        setActiveScenario,
        updateScenarioConfig,
        updateScenarioSettings,
        updateFundingRounds,
        updateUseOfFunds,
        setFundingPeriod,
        updateHistoricalData,
        updatePricingConfig,
        updateAssumptions,
        setViewMode,
        saveAll,
        resetToDefaults,
      }}
    >
      {children}
    </FinancialContext.Provider>
  );
}

// ==================
// HOOK
// ==================

export function useFinancial() {
  const context = useContext(FinancialContext);
  if (!context) {
    throw new Error('useFinancial must be used within a FinancialProvider');
  }
  return context;
}

import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

export type AppRole = 'admin' | 'finance' | 'board' | 'investisseur' | 'lecteur';
export type TabPermission = 'hidden' | 'read' | 'write';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  role: AppRole | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (email: string, password: string, displayName?: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  getTabPermission: (tabKey: string) => TabPermission;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [permissions, setPermissions] = useState<Record<string, TabPermission>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        // Defer fetching user data to avoid deadlock
        if (session?.user) {
          setTimeout(() => {
            fetchUserRole(session.user.id);
            fetchPermissions();
          }, 0);
        } else {
          setRole(null);
          setPermissions({});
          setLoading(false);
        }
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        fetchUserRole(session.user.id);
        fetchPermissions();
      } else {
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchUserRole = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId)
        .order('created_at', { ascending: true })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.error('Error fetching role:', error);
        setRole('lecteur');
      } else {
        setRole((data?.role as AppRole) || 'lecteur');
      }
    } catch (e) {
      console.error('Error fetching role:', e);
      setRole('lecteur');
    }
  };

  const fetchPermissions = async () => {
    try {
      const { data, error } = await supabase
        .from('tab_permissions')
        .select('role, tab_key, permission');

      if (error) {
        console.error('Error fetching permissions:', error);
      } else if (data) {
        // Build permissions map keyed by role-tab
        const permsMap: Record<string, Record<string, TabPermission>> = {};
        data.forEach(p => {
          if (!permsMap[p.role]) permsMap[p.role] = {};
          permsMap[p.role][p.tab_key] = p.permission as TabPermission;
        });
        // Store flat for current role lookup
        setPermissions(prev => {
          const allPerms: Record<string, TabPermission> = {};
          data.forEach(p => {
            const key = `${p.role}:${p.tab_key}`;
            allPerms[key] = p.permission as TabPermission;
          });
          return allPerms;
        });
      }
    } catch (e) {
      console.error('Error fetching permissions:', e);
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error as Error | null };
  };

  const signUp = async (email: string, password: string, displayName?: string) => {
    const redirectUrl = `${window.location.origin}/`;
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: { display_name: displayName }
      }
    });
    return { error: error as Error | null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
    setRole(null);
    setPermissions({});
  };

  const getTabPermission = (tabKey: string): TabPermission => {
    if (!role) return 'hidden';
    const key = `${role}:${tabKey}`;
    return permissions[key] || 'hidden';
  };

  const isAdmin = role === 'admin';

  return (
    <AuthContext.Provider value={{
      user,
      session,
      role,
      loading,
      signIn,
      signUp,
      signOut,
      getTabPermission,
      isAdmin,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

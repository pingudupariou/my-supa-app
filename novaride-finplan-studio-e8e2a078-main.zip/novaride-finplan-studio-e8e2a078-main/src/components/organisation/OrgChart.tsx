import { Role, Department } from '@/engine/types';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Edit2, Trash2, Plus, Users } from 'lucide-react';
import { formatCurrency } from '@/data/financialConfig';
import { cn } from '@/lib/utils';

interface OrgChartProps {
  roles: Role[];
  onEdit: (role: Role) => void;
  onRemove: (id: string) => void;
  onAddToTeam: (department: Department) => void;
}

const DEPARTMENTS: Department[] = ['R&D', 'Production', 'Sales', 'Support', 'Admin'];

const DEPT_CONFIG: Record<Department, { color: string; icon: string; bgColor: string }> = {
  'R&D': { color: 'text-blue-600 dark:text-blue-400', icon: '🔬', bgColor: 'bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800' },
  'Production': { color: 'text-amber-600 dark:text-amber-400', icon: '⚙️', bgColor: 'bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800' },
  'Sales': { color: 'text-green-600 dark:text-green-400', icon: '📈', bgColor: 'bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800' },
  'Support': { color: 'text-purple-600 dark:text-purple-400', icon: '🎧', bgColor: 'bg-purple-50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800' },
  'Admin': { color: 'text-gray-600 dark:text-gray-400', icon: '📋', bgColor: 'bg-gray-50 dark:bg-gray-900/30 border-gray-200 dark:border-gray-700' },
};

export function OrgChart({ roles, onEdit, onRemove, onAddToTeam }: OrgChartProps) {
  const rolesByDept = DEPARTMENTS.map(dept => ({
    department: dept,
    roles: roles.filter(r => r.department === dept),
    totalCost: roles.filter(r => r.department === dept).reduce((sum, r) => sum + r.annualCostLoaded, 0),
    currentCount: roles.filter(r => r.department === dept && r.startYear <= 2025).length,
    futureCount: roles.filter(r => r.department === dept && r.startYear > 2025).length,
  }));

  return (
    <div className="space-y-6">
      {/* Direction - niveau supérieur */}
      <div className="flex justify-center">
        <Card className="p-4 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/30">
          <div className="text-center">
            <div className="text-2xl mb-1">👔</div>
            <div className="font-bold">Direction</div>
            <div className="text-sm text-muted-foreground">Fondateurs</div>
          </div>
        </Card>
      </div>

      {/* Ligne de connexion */}
      <div className="flex justify-center">
        <div className="w-px h-8 bg-border" />
      </div>

      {/* Ligne horizontale */}
      <div className="relative flex justify-center">
        <div className="absolute top-0 left-1/4 right-1/4 h-px bg-border" />
      </div>

      {/* Départements */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {rolesByDept.map(({ department, roles: deptRoles, totalCost, currentCount, futureCount }) => {
          const config = DEPT_CONFIG[department];
          
          return (
            <div key={department} className="space-y-2">
              {/* En-tête département */}
              <Card className={cn("p-4 border-2", config.bgColor)}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{config.icon}</span>
                    <span className={cn("font-bold", config.color)}>{department}</span>
                  </div>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-6 w-6"
                    onClick={() => onAddToTeam(department)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{currentCount} en poste</span>
                  {futureCount > 0 && (
                    <Badge variant="secondary" className="text-xs">+{futureCount}</Badge>
                  )}
                </div>
                <div className="text-sm font-mono-numbers font-semibold mt-1">
                  {formatCurrency(totalCost, true)}/an
                </div>
              </Card>

              {/* Membres de l'équipe */}
              <div className="space-y-1.5 pl-2 border-l-2 border-dashed border-muted-foreground/20">
                {deptRoles.length === 0 ? (
                  <div className="text-xs text-muted-foreground italic p-2">Aucun poste</div>
                ) : (
                  deptRoles.map(role => (
                    <div
                      key={role.id}
                      className={cn(
                        "p-2 rounded-lg border text-sm group transition-colors",
                        role.startYear > 2025 
                          ? "bg-muted/50 border-dashed" 
                          : "bg-background"
                      )}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="font-medium truncate flex items-center gap-1">
                            {role.title}
                            {role.startYear > 2025 && (
                              <Badge variant="outline" className="text-[10px] ml-1">
                                {role.startYear}
                              </Badge>
                            )}
                          </div>
                          <div className="text-xs text-muted-foreground font-mono-numbers">
                            {formatCurrency(role.annualCostLoaded, true)}
                          </div>
                        </div>
                        <div className="flex opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => onEdit(role)}>
                            <Edit2 className="h-3 w-3" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => onRemove(role.id)}>
                            <Trash2 className="h-3 w-3 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Résumé global */}
      <Card className="p-4 bg-muted/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-muted-foreground" />
            <span className="font-medium">Total Organisation</span>
          </div>
          <div className="flex items-center gap-6 text-sm">
            <div>
              <span className="text-muted-foreground">En poste: </span>
              <span className="font-bold">{rolesByDept.reduce((sum, d) => sum + d.currentCount, 0)}</span>
            </div>
            <div>
              <span className="text-muted-foreground">À recruter: </span>
              <span className="font-bold">{rolesByDept.reduce((sum, d) => sum + d.futureCount, 0)}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Masse salariale: </span>
              <span className="font-bold font-mono-numbers">
                {formatCurrency(rolesByDept.reduce((sum, d) => sum + d.totalCost, 0), true)}
              </span>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

import { ReactNode } from 'react';
import { useAuth } from '@/context/AuthContext';
import { cn } from '@/lib/utils';
import { Lock } from 'lucide-react';

interface ReadOnlyWrapperProps {
  children: ReactNode;
  tabKey: string;
  className?: string;
  showBadge?: boolean;
}

/**
 * Wrapper qui désactive les éléments éditables (inputs, sliders) 
 * mais permet les boutons d'export et de navigation
 */
export function ReadOnlyWrapper({ children, tabKey, className, showBadge = true }: ReadOnlyWrapperProps) {
  const { getTabPermission } = useAuth();
  const permission = getTabPermission(tabKey);
  const isReadOnly = permission !== 'write';

  if (isReadOnly) {
    return (
      <div className={cn('relative', className)}>
        {/* 
          Désactive uniquement les éléments éditables, pas les boutons d'export
          - input, select, textarea: champs de formulaire
          - [role=slider]: curseurs
          - [data-editable]: éléments marqués comme éditables
        */}
        <div className={cn(
          "[&_input:not([type=checkbox])]:pointer-events-none [&_input:not([type=checkbox])]:opacity-60",
          "[&_select]:pointer-events-none [&_select]:opacity-60",
          "[&_textarea]:pointer-events-none [&_textarea]:opacity-60",
          "[&_[role=slider]]:pointer-events-none [&_[role=slider]]:opacity-60",
          "[&_[data-editable]]:pointer-events-none [&_[data-editable]]:opacity-60"
        )}>
          {children}
        </div>
        {showBadge && (
          <div className="fixed bottom-4 right-4 z-50 bg-muted/90 backdrop-blur text-muted-foreground text-sm px-3 py-2 rounded-lg shadow-lg flex items-center gap-2 border">
            <Lock className="h-4 w-4" />
            Mode lecture seule
          </div>
        )}
      </div>
    );
  }

  return <>{children}</>;
}

export function useReadOnly(tabKey: string): boolean {
  const { getTabPermission } = useAuth();
  return getTabPermission(tabKey) !== 'write';
}

// Hook pour désactiver les éléments interactifs
export function useDisableIfReadOnly(tabKey: string) {
  const isReadOnly = useReadOnly(tabKey);
  return {
    isReadOnly,
    // Props à passer aux éléments interactifs
    disabledProps: isReadOnly ? { disabled: true, className: 'opacity-60 cursor-not-allowed' } : {},
  };
}

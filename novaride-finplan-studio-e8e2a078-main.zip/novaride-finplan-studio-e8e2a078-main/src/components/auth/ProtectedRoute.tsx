import { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth, TabPermission } from '@/context/AuthContext';
import { Loader2 } from 'lucide-react';

interface ProtectedRouteProps {
  children: ReactNode;
  tabKey?: string;
  requiredPermission?: TabPermission;
}

export function ProtectedRoute({ 
  children, 
  tabKey, 
  requiredPermission = 'read' 
}: ProtectedRouteProps) {
  const { user, loading, getTabPermission } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  if (tabKey) {
    const permission = getTabPermission(tabKey);
    
    if (permission === 'hidden') {
      return <Navigate to="/" replace />;
    }
    
    if (requiredPermission === 'write' && permission !== 'write') {
      // User has read access but trying to access write-only feature
      // Still allow access but in read-only mode (handled by components)
    }
  }

  return <>{children}</>;
}

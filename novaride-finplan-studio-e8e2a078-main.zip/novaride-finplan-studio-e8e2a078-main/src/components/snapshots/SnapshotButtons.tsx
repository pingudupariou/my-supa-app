// ============================================
// BOUTONS DE SAUVEGARDE CONDITIONNELS
// ============================================

import { Button } from '@/components/ui/button';
import { History, FolderOpen } from 'lucide-react';
import { QuickSaveButton } from '@/components/snapshots/QuickSaveButton';
import { SnapshotsDialog } from '@/components/snapshots/SnapshotsDialog';
import { useSnapshots } from '@/hooks/useSnapshots';
import { useAuth } from '@/context/AuthContext';

interface SnapshotButtonsProps {
  collapsed: boolean;
}

export function SnapshotButtons({ collapsed }: SnapshotButtonsProps) {
  const { canManageSnapshots } = useSnapshots();
  const { user } = useAuth();

  // Ne pas afficher si la sidebar est réduite ou si l'utilisateur n'est pas connecté
  if (collapsed || !user) {
    return null;
  }

  return (
    <div className="px-3 py-3 border-t border-sidebar-border space-y-2">
      {/* Bouton de sauvegarde rapide - uniquement si droits d'écriture */}
      {canManageSnapshots && (
        <QuickSaveButton className="w-full justify-start" />
      )}
      {/* Bouton charger une sauvegarde - visible par tous */}
      <SnapshotsDialog
        trigger={
          <Button variant="outline" size="sm" className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent/10 border-sidebar-border">
            <FolderOpen className="h-4 w-4 mr-2" />
            Charger une sauvegarde
          </Button>
        }
      />
      {/* Dialogue de gestion - uniquement si droits d'écriture */}
      {canManageSnapshots && (
        <SnapshotsDialog
          trigger={
            <Button variant="ghost" size="sm" className="w-full justify-start text-sidebar-foreground/70 hover:bg-sidebar-accent/10">
              <History className="h-4 w-4 mr-2" />
              Gérer les sauvegardes
            </Button>
          }
        />
      )}
    </div>
  );
}

// ============================================
// DIALOG DE GESTION DES SAUVEGARDES
// ============================================

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Save,
  History,
  RotateCcw,
  Copy,
  Trash2,
  Plus,
  Calendar,
  MessageSquare,
  MoreVertical,
  FolderArchive,
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useSnapshots, Snapshot } from '@/hooks/useSnapshots';
import { cn } from '@/lib/utils';

interface CreateSnapshotDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: (name: string, comment?: string) => void;
}

function CreateSnapshotDialog({ open, onOpenChange, onConfirm }: CreateSnapshotDialogProps) {
  const [name, setName] = useState('');
  const [comment, setComment] = useState('');

  const handleConfirm = () => {
    if (name.trim()) {
      onConfirm(name.trim(), comment.trim() || undefined);
      setName('');
      setComment('');
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Save className="h-5 w-5 text-primary" />
            Créer une sauvegarde
          </DialogTitle>
          <DialogDescription>
            Créez un point de restauration de votre configuration actuelle.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="snapshot-name">Nom de la sauvegarde *</Label>
            <Input
              id="snapshot-name"
              placeholder="Ex: Avant test scénario ambitieux"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoFocus
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="snapshot-comment">Commentaire (optionnel)</Label>
            <Textarea
              id="snapshot-comment"
              placeholder="Notes sur cette version..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuler
          </Button>
          <Button onClick={handleConfirm} disabled={!name.trim()}>
            <Save className="h-4 w-4 mr-2" />
            Sauvegarder
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

interface SnapshotItemProps {
  snapshot: Snapshot;
  formatDate: (date: string) => string;
  onRestore: () => void;
  onDuplicate: () => void;
  onDelete: () => void;
  canManage: boolean; // Indique si l'utilisateur peut modifier/supprimer
}

function SnapshotItem({ snapshot, formatDate, onRestore, onDuplicate, onDelete, canManage }: SnapshotItemProps) {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showRestoreConfirm, setShowRestoreConfirm] = useState(false);

  return (
    <>
      <div className="group flex items-start gap-3 p-4 rounded-lg border border-border bg-card hover:bg-muted/50 transition-colors">
        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
          <FolderArchive className="h-5 w-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4 className="font-medium text-foreground truncate">{snapshot.name}</h4>
          </div>
          <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {formatDate(snapshot.createdAt)}
            </span>
          </div>
          {snapshot.comment && (
            <p className="mt-2 text-sm text-muted-foreground flex items-start gap-1">
              <MessageSquare className="h-3 w-3 mt-0.5 flex-shrink-0" />
              <span className="line-clamp-2">{snapshot.comment}</span>
            </p>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowRestoreConfirm(true)}
            className="opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <RotateCcw className="h-4 w-4 mr-1" />
            Restaurer
          </Button>
          {canManage && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setShowRestoreConfirm(true)}>
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Restaurer
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onDuplicate}>
                  <Copy className="h-4 w-4 mr-2" />
                  Dupliquer
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => setShowDeleteConfirm(true)}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Supprimer
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>

      {/* Confirmation de restauration */}
      <AlertDialog open={showRestoreConfirm} onOpenChange={setShowRestoreConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Restaurer cette sauvegarde ?</AlertDialogTitle>
            <AlertDialogDescription>
              L'état actuel sera remplacé par "{snapshot.name}". 
              Pensez à créer une sauvegarde de votre travail actuel si nécessaire.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={onRestore}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Restaurer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Confirmation de suppression */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer cette sauvegarde ?</AlertDialogTitle>
            <AlertDialogDescription>
              "{snapshot.name}" sera définitivement supprimée. Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={onDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              <Trash2 className="h-4 w-4 mr-2" />
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

interface SnapshotsDialogProps {
  trigger?: React.ReactNode;
}

export function SnapshotsDialog({ trigger }: SnapshotsDialogProps) {
  const [open, setOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const {
    snapshots,
    isLoading,
    canManageSnapshots,
    createSnapshot,
    restoreSnapshot,
    duplicateSnapshot,
    deleteSnapshot,
    formatDate,
  } = useSnapshots();

  const handleCreateSnapshot = async (name: string, comment?: string) => {
    await createSnapshot(name, comment);
  };

  // Trier par date décroissante (déjà trié depuis Supabase)
  const sortedSnapshots = snapshots;

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          {trigger || (
            <Button variant="outline" size="sm">
              <History className="h-4 w-4 mr-2" />
              Sauvegardes
            </Button>
          )}
        </DialogTrigger>
        <DialogContent className="sm:max-w-2xl max-h-[85vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <History className="h-5 w-5 text-primary" />
              Gestion des sauvegardes
            </DialogTitle>
            <DialogDescription>
              Créez des points de restauration pour revenir à une version précédente de vos données.
            </DialogDescription>
          </DialogHeader>

          <div className="flex items-center justify-between py-2">
            <Badge variant="outline" className="text-xs">
              {snapshots.length} sauvegarde{snapshots.length > 1 ? 's' : ''}
            </Badge>
            {canManageSnapshots && (
              <Button size="sm" onClick={() => setCreateOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Nouvelle sauvegarde
              </Button>
            )}
          </div>

          {isLoading ? (
            <div className="py-12 text-center text-muted-foreground">
              Chargement...
            </div>
          ) : sortedSnapshots.length === 0 ? (
            <div className="py-12 text-center">
              <FolderArchive className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">Aucune sauvegarde créée</p>
              <p className="text-sm text-muted-foreground mt-1">
                Créez votre première sauvegarde pour protéger vos données.
              </p>
            </div>
          ) : (
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-3">
                {sortedSnapshots.map((snapshot) => (
                  <SnapshotItem
                    key={snapshot.id}
                    snapshot={snapshot}
                    formatDate={formatDate}
                    onRestore={() => restoreSnapshot(snapshot.id)}
                    onDuplicate={() => duplicateSnapshot(snapshot.id)}
                    onDelete={() => deleteSnapshot(snapshot.id)}
                    canManage={canManageSnapshots}
                  />
                ))}
              </div>
            </ScrollArea>
          )}

          <DialogFooter className="border-t pt-4">
            <p className="text-xs text-muted-foreground flex-1">
              ☁️ Les sauvegardes sont stockées de manière sécurisée dans le cloud.
            </p>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Fermer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <CreateSnapshotDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onConfirm={handleCreateSnapshot}
      />
    </>
  );
}

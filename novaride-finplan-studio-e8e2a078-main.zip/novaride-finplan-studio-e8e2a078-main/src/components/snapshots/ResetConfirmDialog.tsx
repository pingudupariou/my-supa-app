// ============================================
// DIALOG DE CONFIRMATION DE RÉINITIALISATION
// ============================================

import { useState } from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { RotateCcw, AlertTriangle } from 'lucide-react';
import { useFinancial } from '@/context/FinancialContext';

interface ResetConfirmDialogProps {
  trigger?: React.ReactNode;
}

export function ResetConfirmDialog({ trigger }: ResetConfirmDialogProps) {
  const [open, setOpen] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const { resetToDefaults } = useFinancial();

  const handleReset = () => {
    if (confirmText === 'RÉINITIALISER') {
      resetToDefaults();
      setConfirmText('');
      setOpen(false);
    }
  };

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
    if (!newOpen) {
      setConfirmText('');
    }
  };

  return (
    <AlertDialog open={open} onOpenChange={handleOpenChange}>
      <AlertDialogTrigger asChild>
        {trigger || (
          <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
            <RotateCcw className="h-4 w-4 mr-2" />
            Réinitialiser
          </Button>
        )}
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Réinitialiser toutes les données ?
          </AlertDialogTitle>
          <AlertDialogDescription asChild>
            <div className="space-y-3">
              <p>
                Cette action va <strong>supprimer définitivement</strong> toutes vos données 
                et restaurer les valeurs par défaut.
              </p>
              <p className="text-warning">
                ⚠️ Pensez à créer une sauvegarde avant de continuer.
              </p>
              <p className="text-sm">
                Pour confirmer, tapez <strong>RÉINITIALISER</strong> ci-dessous :
              </p>
              <Input
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder="RÉINITIALISER"
                className="font-mono"
              />
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Annuler</AlertDialogCancel>
          <Button
            onClick={handleReset}
            disabled={confirmText !== 'RÉINITIALISER'}
            variant="destructive"
            asChild
          >
            <AlertDialogAction>
              <RotateCcw className="h-4 w-4 mr-2" />
            Réinitialiser
            </AlertDialogAction>
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

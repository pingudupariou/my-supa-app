// ============================================
// BOUTON DE SAUVEGARDE RAPIDE
// ============================================

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { Save, Check } from 'lucide-react';
import { useSnapshots } from '@/hooks/useSnapshots';
import { cn } from '@/lib/utils';

interface QuickSaveButtonProps {
  className?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'default' | 'sm' | 'lg' | 'icon';
}

export function QuickSaveButton({ className, variant = 'outline', size = 'sm' }: QuickSaveButtonProps) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [saved, setSaved] = useState(false);
  const { createSnapshot } = useSnapshots();

  const handleSave = () => {
    const snapshotName = name.trim() || `Sauvegarde ${new Date().toLocaleString('fr-FR', { 
      day: '2-digit', 
      month: 'short', 
      hour: '2-digit', 
      minute: '2-digit' 
    })}`;
    
    if (createSnapshot(snapshotName)) {
      setSaved(true);
      setTimeout(() => {
        setSaved(false);
        setName('');
        setOpen(false);
      }, 1500);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSave();
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant={variant} size={size} className={cn(className)}>
          <Save className="h-4 w-4 mr-2" />
          Sauvegarder
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-72" align="end">
        <div className="space-y-3">
          <div className="space-y-1">
            <h4 className="text-sm font-medium">Créer une sauvegarde</h4>
            <p className="text-xs text-muted-foreground">
              Nommez votre point de restauration
            </p>
          </div>
          <Input
            placeholder="Nom (optionnel)"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={handleKeyDown}
            autoFocus
          />
          <Button 
            onClick={handleSave} 
            className="w-full"
            disabled={saved}
          >
            {saved ? (
              <>
                <Check className="h-4 w-4 mr-2" />
                Sauvegardé !
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                Créer la sauvegarde
              </>
            )}
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

import { useFinancial } from '@/context/FinancialContext';
import { Calendar } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface GlobalYearSelectorProps {
  collapsed?: boolean;
  className?: string;
}

export function GlobalYearSelector({ collapsed = false, className }: GlobalYearSelectorProps) {
  const { state, updateScenarioSettings } = useFinancial();
  const { startYear, durationYears } = state.scenarioSettings;

  const availableYears = [2024, 2025, 2026, 2027, 2028];

  const handleYearChange = (value: string) => {
    updateScenarioSettings({ startYear: parseInt(value, 10) });
  };

  if (collapsed) {
    return (
      <div className={cn("flex items-center justify-center px-2 py-2", className)}>
        <div className="flex flex-col items-center text-sidebar-foreground/80">
          <Calendar className="h-4 w-4 mb-1" />
          <span className="text-xs font-mono">{startYear}</span>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("px-3 py-3 border-t border-sidebar-border", className)}>
      <div className="flex items-center gap-2 mb-2">
        <Calendar className="h-4 w-4 text-sidebar-foreground/60" />
        <span className="text-xs font-medium text-sidebar-foreground/80 uppercase tracking-wider">
          Base de travail
        </span>
      </div>
      
      <Select value={startYear.toString()} onValueChange={handleYearChange}>
        <SelectTrigger className="w-full h-9 bg-sidebar-accent/10 border-sidebar-border text-sidebar-foreground">
          <SelectValue placeholder="Année de début" />
        </SelectTrigger>
        <SelectContent>
          {availableYears.map((year) => (
            <SelectItem key={year} value={year.toString()}>
              {year} → {year + durationYears - 1}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      
      <p className="text-[10px] text-sidebar-foreground/50 mt-1.5 text-center">
        Période de projection: {durationYears} ans
      </p>
    </div>
  );
}

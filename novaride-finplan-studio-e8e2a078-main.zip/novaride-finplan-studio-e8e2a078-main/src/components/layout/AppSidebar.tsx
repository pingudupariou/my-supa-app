import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  Package,
  Users,
  Calculator,
  Banknote,
  GitBranch,
  Presentation,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Shield,
  LogOut,
  User,
  Home,
  LineChart,
  Briefcase,
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { NovarideLogo } from '@/components/ui/NovarideLogo';
import { SnapshotButtons } from '@/components/snapshots/SnapshotButtons';
import { GlobalYearSelector } from '@/components/layout/GlobalYearSelector';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import productCcdEvo from '@/assets/product-ccd-evo.png';

// Navigation simplifiée - 10 modules essentiels
const navItems = [
  { path: '/home', label: 'Accueil', icon: Home, tabKey: 'home', description: 'Entreprise & Projet' },
  { path: '/', label: 'Plan Produit', icon: Package, tabKey: 'product-plan', description: 'CA & CAPEX' },
  { path: '/organisation', label: 'Organisation', icon: Users, tabKey: 'organisation', description: 'RH & Masse salariale' },
  { path: '/charges', label: 'Structure des Charges', icon: Calculator, tabKey: 'charges', description: 'OPEX' },
  { path: '/crm', label: 'CRM', icon: Briefcase, tabKey: 'crm', description: 'Clients & Commandes' },
  { path: '/previsionnel', label: 'Prévisionnel', icon: LineChart, tabKey: 'previsionnel', description: 'Cash Flow & SIG' },
  { path: '/funding', label: 'Besoin de Financement', icon: Banknote, tabKey: 'funding', description: 'Levée & Calibrage' },
  { path: '/scenarios', label: 'Scénarios', icon: GitBranch, tabKey: 'scenarios', description: 'Prudent / Base / Ambitieux' },
  { path: '/valuation', label: 'Valorisation & Analyse', icon: TrendingUp, tabKey: 'valuation', description: 'Méthodes & Sortie' },
  { path: '/investment-summary', label: 'Synthèse Investisseur', icon: Presentation, tabKey: 'investment-summary', highlight: true },
];

export function AppSidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, role, isAdmin, signOut, getTabPermission } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Filter nav items based on user permissions
  const visibleNavItems = navItems.filter(item => {
    const permission = getTabPermission(item.tabKey);
    return permission !== 'hidden';
  });

  const handleSignOut = async () => {
    await signOut();
    navigate('/auth');
  };

  return (
    <>
      {/* Mobile toggle button */}
      <button
        onClick={() => setMobileOpen(!mobileOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-card border border-border rounded shadow-sm"
        aria-label="Toggle menu"
      >
        {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed lg:static inset-y-0 left-0 z-40 flex flex-col bg-sidebar border-r border-sidebar-border transition-all duration-200',
          collapsed ? 'w-16' : 'w-64',
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Logo */}
        <div className={cn(
          'h-16 flex items-center border-b border-sidebar-border px-4',
          collapsed && 'justify-center'
        )}>
          {collapsed ? (
            <NovarideLogo variant="compact" color="light" className="text-xl" />
          ) : (
            <NovarideLogo variant="full" color="light" />
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4 overflow-y-auto">
          <ul className="space-y-1 px-2">
            {visibleNavItems.map((item) => {
              const isActive = location.pathname === item.path;
              const Icon = item.icon;
              const isHighlight = 'highlight' in item && item.highlight;
              const permission = getTabPermission(item.tabKey);
              const isReadOnly = permission === 'read';
              
              return (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      'flex items-center gap-3 px-3 py-2.5 rounded text-sm font-medium transition-colors',
                      isActive
                        ? 'bg-accent text-accent-foreground'
                        : isHighlight
                          ? 'text-accent hover:bg-accent/10 border border-accent/30'
                          : 'text-sidebar-foreground hover:bg-sidebar-accent/10 hover:text-sidebar-primary'
                    )}
                  >
                    <Icon className="h-4 w-4 flex-shrink-0" />
                    {!collapsed && (
                      <div className="flex-1 min-w-0">
                        <span className="block truncate">{item.label}</span>
                        {'description' in item && (
                          <span className="block text-xs text-sidebar-foreground/60 truncate">
                            {item.description}
                          </span>
                        )}
                      </div>
                    )}
                    {!collapsed && isReadOnly && (
                      <span className="text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
                        R
                      </span>
                    )}
                  </NavLink>
                </li>
              );
            })}
            
            {/* Admin link */}
            {isAdmin && (
              <li className="pt-4 border-t border-sidebar-border mt-4">
                <NavLink
                  to="/permissions"
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    'flex items-center gap-3 px-3 py-2.5 rounded text-sm font-medium transition-colors',
                    location.pathname === '/permissions'
                      ? 'bg-accent text-accent-foreground'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent/10 hover:text-sidebar-primary'
                  )}
                >
                  <Shield className="h-4 w-4 flex-shrink-0" />
                  {!collapsed && (
                    <div className="flex-1 min-w-0">
                      <span className="block truncate">Permissions</span>
                      <span className="block text-xs text-sidebar-foreground/60 truncate">
                        Admin
                      </span>
                    </div>
                  )}
                </NavLink>
              </li>
            )}
          </ul>
        </nav>

        {/* Sélecteur d'année global */}
        <GlobalYearSelector collapsed={collapsed} />

        {/* Boutons de sauvegarde - visibles uniquement si l'utilisateur peut gérer les snapshots */}
        <SnapshotButtons collapsed={collapsed} />

        {/* Product showcase (only when expanded) */}
        {!collapsed && (
          <div className="px-3 py-3 border-t border-sidebar-border">
            <div className="relative rounded-lg overflow-hidden bg-gradient-to-br from-sidebar-accent/20 to-sidebar-accent/5 p-3">
              <img 
                src={productCcdEvo} 
                alt="CCD EVO" 
                className="h-16 w-auto mx-auto object-contain opacity-90"
              />
              <p className="text-[10px] text-center text-sidebar-foreground/60 mt-2 uppercase tracking-wider">
                Innovation française
              </p>
            </div>
          </div>
        )}

        {/* User info & logout */}
        {user && !collapsed && (
          <div className="px-3 py-3 border-t border-sidebar-border">
            <div className="flex items-center gap-2 mb-2">
              <User className="h-4 w-4 text-sidebar-foreground/60" />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-sidebar-foreground truncate">{user.email}</p>
                <p className="text-[10px] text-sidebar-foreground/60 capitalize">{role || 'lecteur'}</p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent/10"
              onClick={handleSignOut}
            >
              <LogOut className="h-4 w-4 mr-2" />
              Déconnexion
            </Button>
          </div>
        )}

        {/* Collapse toggle (desktop only) */}
        <div className="hidden lg:flex border-t border-sidebar-border p-2">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-sm text-sidebar-foreground hover:bg-sidebar-accent/10 rounded transition-colors"
          >
            {collapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <>
                <ChevronLeft className="h-4 w-4" />
                <span>Réduire</span>
              </>
            )}
          </button>
        </div>
      </aside>
    </>
  );
}

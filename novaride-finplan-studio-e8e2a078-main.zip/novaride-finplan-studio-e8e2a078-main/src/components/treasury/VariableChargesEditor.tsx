import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Trash2, Plus, Percent } from 'lucide-react';
import { VariableChargeConfig } from '@/engine/monthlyTreasuryEngine';
import { formatCurrency } from '@/data/financialConfig';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface VariableChargesEditorProps {
  value: VariableChargeConfig[];
  onChange: (charges: VariableChargeConfig[]) => void;
  estimatedAnnualRevenue?: number;
}

export function VariableChargesEditor({ value, onChange, estimatedAnnualRevenue = 0 }: VariableChargesEditorProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [newCharge, setNewCharge] = useState({ name: '', rate: '' });

  const handleAdd = useCallback(() => {
    if (!newCharge.name.trim() || !newCharge.rate) return;
    
    const rate = parseFloat(newCharge.rate) / 100;
    if (isNaN(rate) || rate < 0 || rate > 1) return;

    const id = `vc-${Date.now()}`;
    onChange([
      ...value,
      {
        id,
        name: newCharge.name.trim(),
        rateOfRevenue: rate,
      },
    ]);
    
    setNewCharge({ name: '', rate: '' });
    setIsAdding(false);
  }, [value, newCharge, onChange]);

  const handleRemove = useCallback((id: string) => {
    onChange(value.filter(c => c.id !== id));
  }, [value, onChange]);

  const handleUpdateRate = useCallback((id: string, rateStr: string) => {
    const rate = parseFloat(rateStr) / 100;
    if (isNaN(rate) || rate < 0 || rate > 1) return;
    
    onChange(value.map(c => 
      c.id === id ? { ...c, rateOfRevenue: rate } : c
    ));
  }, [value, onChange]);

  // Total des charges variables
  const totalRate = value.reduce((sum, c) => sum + c.rateOfRevenue, 0);
  const estimatedAnnualTotal = estimatedAnnualRevenue * totalRate;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="font-medium">Charges Variables</h4>
          <p className="text-sm text-muted-foreground">
            Charges calculées en pourcentage du CA mensuel
          </p>
        </div>
        {!isAdding && (
          <Button variant="outline" size="sm" onClick={() => setIsAdding(true)}>
            <Plus className="h-4 w-4 mr-1" />
            Ajouter
          </Button>
        )}
      </div>

      {/* Formulaire d'ajout */}
      {isAdding && (
        <div className="p-4 border rounded-lg bg-muted/30 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Nom de la charge</Label>
              <Input
                placeholder="Ex: Frais de paiement"
                value={newCharge.name}
                onChange={(e) => setNewCharge(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <Label>Taux (% du CA)</Label>
              <div className="relative">
                <Input
                  type="number"
                  step="0.1"
                  min="0"
                  max="100"
                  placeholder="3"
                  value={newCharge.rate}
                  onChange={(e) => setNewCharge(prev => ({ ...prev, rate: e.target.value }))}
                />
                <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" onClick={handleAdd}>Ajouter</Button>
            <Button size="sm" variant="ghost" onClick={() => {
              setIsAdding(false);
              setNewCharge({ name: '', rate: '' });
            }}>
              Annuler
            </Button>
          </div>
        </div>
      )}

      {/* Liste des charges */}
      {value.length > 0 ? (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Charge</TableHead>
              <TableHead className="text-right">Taux</TableHead>
              <TableHead className="text-right">Estimation annuelle</TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {value.map((charge) => (
              <TableRow key={charge.id}>
                <TableCell className="font-medium">{charge.name}</TableCell>
                <TableCell className="text-right">
                  <Input
                    type="number"
                    step="0.1"
                    min="0"
                    max="100"
                    className="w-20 text-right inline-block"
                    value={(charge.rateOfRevenue * 100).toFixed(1)}
                    onChange={(e) => handleUpdateRate(charge.id, e.target.value)}
                  />
                  <span className="ml-1 text-muted-foreground">%</span>
                </TableCell>
                <TableCell className="text-right font-mono">
                  {formatCurrency(estimatedAnnualRevenue * charge.rateOfRevenue, true)}
                </TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemove(charge.id)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {/* Ligne total */}
            <TableRow className="bg-muted/30 font-medium">
              <TableCell>Total</TableCell>
              <TableCell className="text-right">
                <Badge variant="secondary">{(totalRate * 100).toFixed(1)}%</Badge>
              </TableCell>
              <TableCell className="text-right font-mono">
                {formatCurrency(estimatedAnnualTotal, true)}
              </TableCell>
              <TableCell></TableCell>
            </TableRow>
          </TableBody>
        </Table>
      ) : (
        <div className="text-center py-8 text-muted-foreground border rounded-lg">
          <Percent className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p>Aucune charge variable configurée</p>
          <p className="text-xs mt-1">
            Ex: frais de paiement (2-3%), logistique (5%), marketing variable
          </p>
        </div>
      )}
    </div>
  );
}

import { useCallback } from 'react';
import * as SliderPrimitive from '@radix-ui/react-slider';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { MONTHS, SeasonalityConfig, MonthIndex } from '@/engine/monthlyTreasuryEngine';
import { RotateCcw } from 'lucide-react';

// Slider avec couleur dynamique du thumb
interface ColoredSliderProps {
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
  step: number;
}

function ColoredSlider({ value, onChange, min, max, step }: ColoredSliderProps) {
  const thumbColor = value > 0 
    ? 'border-chart-4 bg-chart-4' 
    : value < 0 
      ? 'border-destructive bg-destructive' 
      : 'border-primary bg-background';

  const trackColor = value > 0 
    ? 'bg-chart-4' 
    : value < 0 
      ? 'bg-destructive' 
      : 'bg-primary';

  return (
    <SliderPrimitive.Root
      className="relative flex w-full touch-none select-none items-center"
      value={[value]}
      min={min}
      max={max}
      step={step}
      onValueChange={([v]) => onChange(v)}
    >
      <SliderPrimitive.Track className="relative h-2 w-full grow overflow-hidden rounded-full bg-secondary">
        <SliderPrimitive.Range className={cn("absolute h-full transition-colors", trackColor)} />
      </SliderPrimitive.Track>
      <SliderPrimitive.Thumb 
        className={cn(
          "block h-5 w-5 rounded-full border-2 ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
          thumbColor
        )} 
      />
    </SliderPrimitive.Root>
  );
}

interface SeasonalitySlidersProps {
  title: string;
  description?: string;
  value: SeasonalityConfig;
  onChange: (config: SeasonalityConfig) => void;
}

export function SeasonalitySliders({ title, description, value, onChange }: SeasonalitySlidersProps) {
  const handleSliderChange = useCallback((month: MonthIndex, newValue: number) => {
    onChange({
      ...value,
      [month]: newValue,
    });
  }, [value, onChange]);

  const handleReset = useCallback(() => {
    const reset: SeasonalityConfig = {
      0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0,
      6: 0, 7: 0, 8: 0, 9: 0, 10: 0, 11: 0,
    };
    onChange(reset);
  }, [onChange]);

  // Calculer si la config est modifiée
  const isModified = Object.values(value).some(v => v !== 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="font-medium">{title}</h4>
          {description && (
            <p className="text-sm text-muted-foreground">{description}</p>
          )}
        </div>
        {isModified && (
          <Button variant="ghost" size="sm" onClick={handleReset}>
            <RotateCcw className="h-4 w-4 mr-1" />
            Réinitialiser
          </Button>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {MONTHS.map((monthName, index) => {
          const monthIndex = index as MonthIndex;
          const variation = value[monthIndex] || 0;
          const displayValue = Math.round(variation * 100);
          
          return (
            <div key={monthIndex} className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-normal">{monthName}</Label>
                <Badge 
                  variant={variation === 0 ? 'outline' : variation > 0 ? 'default' : 'secondary'}
                  className={cn(
                    "font-mono text-xs",
                    variation > 0 && "bg-chart-4 text-chart-4-foreground",
                    variation < 0 && "bg-destructive/10 text-destructive"
                  )}
                >
                  {variation >= 0 ? '+' : ''}{displayValue}%
                </Badge>
              </div>
              <ColoredSlider
                value={variation}
                min={-0.5}
                max={0.5}
                step={0.05}
                onChange={(v) => handleSliderChange(monthIndex, v)}
              />
            </div>
          );
        })}
      </div>

      {/* Visualisation de la répartition */}
      <div className="pt-4 border-t">
        <p className="text-xs text-muted-foreground mb-2">Aperçu de la répartition (normalisée)</p>
        <div className="flex h-16 gap-1">
          {MONTHS.map((_, index) => {
            const monthIndex = index as MonthIndex;
            const variation = value[monthIndex] || 0;
            // Coefficient normalisé approximatif pour visualisation
            const rawCoef = 1 + variation;
            const sumRaw = Object.values(value).reduce((a, b) => a + (1 + b), 0);
            const normalizedCoef = sumRaw > 0 ? (rawCoef / sumRaw) * 12 : 1;
            const height = Math.max(10, Math.min(100, normalizedCoef * 50));
            
            return (
              <div
                key={monthIndex}
                className="flex-1 bg-primary/20 rounded-sm relative overflow-hidden"
              >
                <div
                  className={cn(
                    "absolute bottom-0 left-0 right-0 rounded-sm transition-all",
                    variation > 0 ? "bg-chart-4" : variation < 0 ? "bg-destructive" : "bg-muted-foreground"
                  )}
                  style={{ height: `${height}%` }}
                />
              </div>
            );
          })}
        </div>
        <div className="flex text-[10px] text-muted-foreground mt-1">
          {MONTHS.map((name, i) => (
            <div key={i} className="flex-1 text-center truncate">{name.slice(0, 3)}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

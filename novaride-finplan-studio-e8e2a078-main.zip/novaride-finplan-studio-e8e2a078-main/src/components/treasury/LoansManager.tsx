import { useState, useCallback, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Trash2, Plus, Edit2, CreditCard, Euro, Copy } from 'lucide-react';
import { LoanConfig, MONTHS, MonthIndex, getMonthKey } from '@/engine/monthlyTreasuryEngine';
import { formatCurrency } from '@/data/financialConfig';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

// Helper pour générer les périodes d'échéance
function generatePaymentPeriods(
  loan: LoanConfig,
  startYear: number,
  durationYears: number
): { year: number; month: MonthIndex; key: string; label: string }[] {
  const periods: { year: number; month: MonthIndex; key: string; label: string }[] = [];
  
  const startMonth = loan.startDate.year * 12 + loan.startDate.month;
  const endMonth = loan.endDate.year * 12 + loan.endDate.month;
  const periodEnd = (startYear + durationYears) * 12;
  
  const frequencyMonths = loan.frequency === 'monthly' ? 1 : 3;
  let currentMonth = startMonth;
  
  while (currentMonth <= endMonth && currentMonth < periodEnd) {
    const year = Math.floor(currentMonth / 12);
    const month = (currentMonth % 12) as MonthIndex;
    
    if (year >= startYear && year < startYear + durationYears) {
      periods.push({
        year,
        month,
        key: getMonthKey(year, month),
        label: `${MONTHS[month].slice(0, 3)} ${year}`,
      });
    }
    
    currentMonth += frequencyMonths;
  }
  
  return periods;
}

interface LoansManagerProps {
  value: LoanConfig[];
  onChange: (loans: LoanConfig[]) => void;
  startYear: number;
  durationYears: number;
}

const MONTH_OPTIONS = MONTHS.map((name, index) => ({
  value: index.toString(),
  label: name,
}));

export function LoansManager({ value, onChange, startYear, durationYears }: LoansManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingLoan, setEditingLoan] = useState<LoanConfig | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    startYear: startYear.toString(),
    startMonth: '0',
    endYear: (startYear + 3).toString(),
    endMonth: '11',
    frequency: 'monthly' as 'monthly' | 'quarterly',
  });
  // Échéances manuelles en cours d'édition
  const [editingPayments, setEditingPayments] = useState<Record<string, string>>({});
  // Mode de saisie : uniform = même montant partout, custom = un par un
  const [paymentMode, setPaymentMode] = useState<'uniform' | 'custom'>('uniform');
  // Montant uniforme
  const [uniformAmount, setUniformAmount] = useState('');

  const yearOptions = Array.from({ length: durationYears + 2 }, (_, i) => ({
    value: (startYear + i).toString(),
    label: (startYear + i).toString(),
  }));

  const resetForm = useCallback(() => {
    setFormData({
      name: '',
      startYear: startYear.toString(),
      startMonth: '0',
      endYear: (startYear + 3).toString(),
      endMonth: '11',
      frequency: 'monthly',
    });
    setEditingPayments({});
    setPaymentMode('uniform');
    setUniformAmount('');
    setEditingLoan(null);
  }, [startYear]);

  // Déterminer si un prêt existant utilise des montants uniformes
  const detectPaymentMode = useCallback((payments: Record<string, number>): { mode: 'uniform' | 'custom'; amount: string } => {
    const values = Object.values(payments);
    if (values.length === 0) return { mode: 'uniform', amount: '' };
    
    const firstValue = values[0];
    const allSame = values.every(v => v === firstValue);
    
    if (allSame) {
      return { mode: 'uniform', amount: firstValue.toString() };
    }
    return { mode: 'custom', amount: '' };
  }, []);

  const handleOpenDialog = useCallback((loan?: LoanConfig) => {
    if (loan) {
      setEditingLoan(loan);
      setFormData({
        name: loan.name,
        startYear: loan.startDate.year.toString(),
        startMonth: loan.startDate.month.toString(),
        endYear: loan.endDate.year.toString(),
        endMonth: loan.endDate.month.toString(),
        frequency: loan.frequency,
      });
      // Charger les échéances existantes
      const payments: Record<string, string> = {};
      if (loan.manualPayments) {
        Object.entries(loan.manualPayments).forEach(([key, amount]) => {
          payments[key] = amount.toString();
        });
        // Détecter le mode
        const detected = detectPaymentMode(loan.manualPayments);
        setPaymentMode(detected.mode);
        setUniformAmount(detected.amount);
      } else {
        setPaymentMode('uniform');
        setUniformAmount('');
      }
      setEditingPayments(payments);
    } else {
      resetForm();
    }
    setIsDialogOpen(true);
  }, [resetForm, detectPaymentMode]);

  // Prévisualiser les périodes pour le formulaire
  const previewPeriods = useMemo(() => {
    const tempLoan: LoanConfig = {
      id: 'preview',
      name: '',
      principalAmount: 0,
      interestRate: 0,
      startDate: {
        year: parseInt(formData.startYear),
        month: parseInt(formData.startMonth) as MonthIndex,
      },
      endDate: {
        year: parseInt(formData.endYear),
        month: parseInt(formData.endMonth) as MonthIndex,
      },
      frequency: formData.frequency,
    };
    return generatePaymentPeriods(tempLoan, startYear, durationYears);
  }, [formData.startYear, formData.startMonth, formData.endYear, formData.endMonth, formData.frequency, startYear, durationYears]);

  const handleSave = useCallback(() => {
    if (!formData.name.trim()) return;

    // Convertir les échéances en Record<string, number>
    const manualPayments: Record<string, number> = {};
    
    if (paymentMode === 'uniform') {
      // Mode uniforme : appliquer le même montant à toutes les périodes
      const amount = parseFloat(uniformAmount);
      if (!isNaN(amount) && amount > 0) {
        previewPeriods.forEach(period => {
          manualPayments[period.key] = amount;
        });
      }
    } else {
      // Mode personnalisé : utiliser les valeurs individuelles
      Object.entries(editingPayments).forEach(([key, value]) => {
        const amount = parseFloat(value);
        if (!isNaN(amount) && amount > 0) {
          manualPayments[key] = amount;
        }
      });
    }

    // Calculer le total
    const totalAmount = Object.values(manualPayments).reduce((sum, val) => sum + val, 0);

    const loan: LoanConfig = {
      id: editingLoan?.id || `loan-${Date.now()}`,
      name: formData.name.trim(),
      principalAmount: totalAmount, // Total des échéances
      interestRate: 0, // Non utilisé en mode manuel
      startDate: {
        year: parseInt(formData.startYear),
        month: parseInt(formData.startMonth) as MonthIndex,
      },
      endDate: {
        year: parseInt(formData.endYear),
        month: parseInt(formData.endMonth) as MonthIndex,
      },
      frequency: formData.frequency,
      manualPayments,
    };

    if (editingLoan) {
      onChange(value.map(l => l.id === loan.id ? loan : l));
    } else {
      onChange([...value, loan]);
    }

    setIsDialogOpen(false);
    resetForm();
  }, [value, formData, editingPayments, editingLoan, onChange, resetForm, paymentMode, uniformAmount, previewPeriods]);

  const handlePaymentChange = useCallback((key: string, val: string) => {
    setEditingPayments(prev => ({ ...prev, [key]: val }));
  }, []);

  // Appliquer le montant uniforme à toutes les périodes (pour preview)
  const handleApplyUniform = useCallback(() => {
    const amount = parseFloat(uniformAmount);
    if (isNaN(amount)) return;
    
    const newPayments: Record<string, string> = {};
    previewPeriods.forEach(period => {
      newPayments[period.key] = uniformAmount;
    });
    setEditingPayments(newPayments);
  }, [uniformAmount, previewPeriods]);

  // Calculer le total affiché
  const displayedTotal = useMemo(() => {
    if (paymentMode === 'uniform') {
      const amount = parseFloat(uniformAmount) || 0;
      return amount * previewPeriods.length;
    }
    return Object.values(editingPayments).reduce((sum, v) => sum + (parseFloat(v) || 0), 0);
  }, [paymentMode, uniformAmount, previewPeriods.length, editingPayments]);

  const handleRemove = useCallback((id: string) => {
    onChange(value.filter(l => l.id !== id));
  }, [value, onChange]);

  // Calculer le total des prêts
  const totalPrincipal = value.reduce((sum, l) => sum + l.principalAmount, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="font-medium">Prêts</h4>
          <p className="text-sm text-muted-foreground">
            Gérez les prêts et leurs échéances
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" onClick={() => handleOpenDialog()}>
              <Plus className="h-4 w-4 mr-1" />
              Ajouter un prêt
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingLoan ? 'Modifier le prêt' : 'Nouveau prêt'}
              </DialogTitle>
              <DialogDescription>
                Définissez la période et saisissez manuellement chaque échéance.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div>
                <Label>Nom du prêt</Label>
                <Input
                  placeholder="Ex: Prêt BPI Innovation"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Date de début</Label>
                  <div className="flex gap-1">
                    <Select
                      value={formData.startMonth}
                      onValueChange={(v) => setFormData(prev => ({ ...prev, startMonth: v }))}
                    >
                      <SelectTrigger className="flex-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {MONTH_OPTIONS.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>
                            {opt.label.slice(0, 3)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select
                      value={formData.startYear}
                      onValueChange={(v) => setFormData(prev => ({ ...prev, startYear: v }))}
                    >
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {yearOptions.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>
                            {opt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label>Date de fin</Label>
                  <div className="flex gap-1">
                    <Select
                      value={formData.endMonth}
                      onValueChange={(v) => setFormData(prev => ({ ...prev, endMonth: v }))}
                    >
                      <SelectTrigger className="flex-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {MONTH_OPTIONS.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>
                            {opt.label.slice(0, 3)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select
                      value={formData.endYear}
                      onValueChange={(v) => setFormData(prev => ({ ...prev, endYear: v }))}
                    >
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {yearOptions.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>
                            {opt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div>
                <Label>Fréquence des échéances</Label>
                <Select
                  value={formData.frequency}
                  onValueChange={(v) => setFormData(prev => ({ ...prev, frequency: v as 'monthly' | 'quarterly' }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Mensuelle</SelectItem>
                    <SelectItem value="quarterly">Trimestrielle</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Mode de saisie des échéances */}
              {previewPeriods.length > 0 && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Mode de saisie des échéances</Label>
                    <RadioGroup
                      value={paymentMode}
                      onValueChange={(v) => setPaymentMode(v as 'uniform' | 'custom')}
                      className="flex gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="uniform" id="uniform" />
                        <Label htmlFor="uniform" className="font-normal cursor-pointer">
                          Montant identique
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="custom" id="custom" />
                        <Label htmlFor="custom" className="font-normal cursor-pointer">
                          Personnalisé
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {paymentMode === 'uniform' ? (
                    // Mode uniforme : un seul champ
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        <Euro className="h-4 w-4" />
                        Montant par échéance ({previewPeriods.length} périodes)
                      </Label>
                      <div className="flex gap-2">
                        <Input
                          type="number"
                          placeholder="Ex: 2500"
                          value={uniformAmount}
                          onChange={(e) => setUniformAmount(e.target.value)}
                          className="flex-1"
                        />
                        <Button 
                          type="button" 
                          variant="outline" 
                          size="sm"
                          onClick={handleApplyUniform}
                        >
                          <Copy className="h-4 w-4 mr-1" />
                          Voir détail
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Ce montant sera appliqué à chacune des {previewPeriods.length} échéances
                      </p>
                    </div>
                  ) : (
                    // Mode personnalisé : tableau complet
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        <Euro className="h-4 w-4" />
                        Échéances personnalisées ({previewPeriods.length} périodes)
                      </Label>
                      <div className="border rounded-lg max-h-64 overflow-y-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Période</TableHead>
                              <TableHead className="text-right">Montant (€)</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {previewPeriods.map((period) => (
                              <TableRow key={period.key}>
                                <TableCell className="font-medium">{period.label}</TableCell>
                                <TableCell className="text-right">
                                  <Input
                                    type="number"
                                    placeholder="0"
                                    className="w-28 ml-auto text-right"
                                    value={editingPayments[period.key] || ''}
                                    onChange={(e) => handlePaymentChange(period.key, e.target.value)}
                                  />
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}

                  {/* Total */}
                  <div className="flex justify-between items-center p-2 bg-muted/30 rounded text-sm">
                    <span className="font-medium">Total des échéances</span>
                    <span className="font-mono font-bold">
                      {formatCurrency(displayedTotal, true)}
                    </span>
                  </div>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Annuler
              </Button>
              <Button onClick={handleSave} disabled={!formData.name.trim()}>
                {editingLoan ? 'Enregistrer' : 'Ajouter'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Liste des prêts */}
      {value.length > 0 ? (
        <Accordion type="single" collapsible className="space-y-2">
          {value.map((loan) => {
            const startLabel = `${MONTHS[loan.startDate.month].slice(0, 3)} ${loan.startDate.year}`;
            const endLabel = `${MONTHS[loan.endDate.month].slice(0, 3)} ${loan.endDate.year}`;
            
            return (
              <AccordionItem 
                key={loan.id} 
                value={loan.id}
                className="border rounded-lg px-4"
              >
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-center gap-3 flex-1">
                    <CreditCard className="h-4 w-4 text-primary" />
                    <div className="text-left">
                      <p className="font-medium">{loan.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {startLabel} → {endLabel} • {loan.frequency === 'monthly' ? 'Mensuel' : 'Trimestriel'}
                      </p>
                    </div>
                    <Badge variant="secondary" className="ml-auto mr-4">
                      {formatCurrency(loan.principalAmount, true)}
                    </Badge>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="pt-2 pb-4 space-y-3">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Total des échéances</p>
                        <p className="font-mono font-medium">{formatCurrency(loan.principalAmount, true)}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Nombre d'échéances</p>
                        <p className="font-medium">
                          {loan.manualPayments ? Object.keys(loan.manualPayments).length : 0} paiements
                        </p>
                      </div>
                    </div>
                    {loan.manualPayments && Object.keys(loan.manualPayments).length > 0 && (
                      <div className="border rounded-lg max-h-32 overflow-y-auto">
                        <Table>
                          <TableBody>
                            {Object.entries(loan.manualPayments)
                              .sort(([a], [b]) => a.localeCompare(b))
                              .map(([key, amount]) => {
                                const [year, month] = key.split('-');
                                const monthIdx = parseInt(month);
                                return (
                                  <TableRow key={key} className="text-sm">
                                    <TableCell className="py-1.5">{MONTHS[monthIdx].slice(0, 3)} {year}</TableCell>
                                    <TableCell className="py-1.5 text-right font-mono">
                                      {formatCurrency(amount, true)}
                                    </TableCell>
                                  </TableRow>
                                );
                              })}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleOpenDialog(loan)}
                      >
                        <Edit2 className="h-3 w-3 mr-1" />
                        Modifier
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemove(loan.id)}
                      >
                        <Trash2 className="h-3 w-3 mr-1 text-destructive" />
                        Supprimer
                      </Button>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
            );
          })}
        </Accordion>
      ) : (
        <div className="text-center py-8 text-muted-foreground border rounded-lg">
          <CreditCard className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p>Aucun prêt configuré</p>
          <p className="text-xs mt-1">
            Les prêts génèrent des échéances automatiques intégrées au plan de trésorerie
          </p>
        </div>
      )}

      {value.length > 0 && (
        <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
          <span className="text-sm font-medium">Total des prêts</span>
          <Badge variant="outline" className="font-mono">
            {formatCurrency(totalPrincipal, true)}
          </Badge>
        </div>
      )}
    </div>
  );
}

import { useMemo, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { MonthlyData, MONTHS, aggregateByYear } from '@/engine/monthlyTreasuryEngine';
import { formatCurrency } from '@/data/financialConfig';
import { ChevronDown, ChevronUp, AlertTriangle } from 'lucide-react';

interface MonthlyTreasuryTableProps {
  months: MonthlyData[];
  startYear: number;
  durationYears: number;
}

type ViewMode = 'single-year' | 'all-years';

export function MonthlyTreasuryTable({ months, startYear, durationYears }: MonthlyTreasuryTableProps) {
  const [viewMode, setViewMode] = useState<ViewMode>('single-year');
  const [selectedYear, setSelectedYear] = useState(startYear);
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

  const years = Array.from({ length: durationYears }, (_, i) => startYear + i);

  // Filtrer les mois selon le mode de vue
  const displayedMonths = useMemo(() => {
    if (viewMode === 'all-years') {
      return months;
    }
    return months.filter(m => m.year === selectedYear);
  }, [months, viewMode, selectedYear]);

  // Données agrégées par année
  const yearlyAggregates = useMemo(() => aggregateByYear(months), [months]);

  const toggleRowExpansion = (key: string) => {
    setExpandedRows(prev => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };

  // Trouver le point bas
  const minTreasuryMonth = useMemo(() => {
    let min = Infinity;
    let minMonth: MonthlyData | null = null;
    months.forEach(m => {
      if (m.treasuryEnd < min) {
        min = m.treasuryEnd;
        minMonth = m;
      }
    });
    return minMonth;
  }, [months]);

  return (
    <div className="space-y-4">
      {/* Contrôles de vue */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Select
            value={viewMode}
            onValueChange={(v) => setViewMode(v as ViewMode)}
          >
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="single-year">Vue par année</SelectItem>
              <SelectItem value="all-years">Vue complète ({durationYears} ans)</SelectItem>
            </SelectContent>
          </Select>

          {viewMode === 'single-year' && (
            <Select
              value={selectedYear.toString()}
              onValueChange={(v) => setSelectedYear(parseInt(v))}
            >
              <SelectTrigger className="w-24">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(year => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        <Badge variant="outline">
          {displayedMonths.length} mois affichés
        </Badge>
      </div>

      {/* Tableau mensuel */}
      <div className="border rounded-lg overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="sticky left-0 bg-background z-10 min-w-32">Mois</TableHead>
              <TableHead className="text-right min-w-24">Tréso Début</TableHead>
              <TableHead className="text-right min-w-24 text-chart-4">CA Encaissé</TableHead>
              <TableHead className="text-right min-w-24 text-chart-4">Levée</TableHead>
              <TableHead className="text-right min-w-24 text-destructive">Achats</TableHead>
              <TableHead className="text-right min-w-24 text-destructive">Salaires</TableHead>
              <TableHead className="text-right min-w-24 text-destructive">OPEX</TableHead>
              <TableHead className="text-right min-w-24 text-destructive">Var.</TableHead>
              <TableHead className="text-right min-w-24 text-destructive">Prêts</TableHead>
              <TableHead className="text-right min-w-24 text-destructive">CAPEX</TableHead>
              <TableHead className="text-right min-w-24 font-medium">Cash Flow</TableHead>
              <TableHead className="text-right min-w-24 font-medium">Tréso Fin</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {displayedMonths.map((m, idx) => {
              const rowKey = `${m.year}-${m.month}`;
              const isExpanded = expandedRows.has(rowKey);
              const isMinTreasury = minTreasuryMonth && 
                minTreasuryMonth.year === m.year && 
                minTreasuryMonth.month === m.month;
              const isNegative = m.treasuryEnd < 0;
              const isNewYear = idx === 0 || displayedMonths[idx - 1].year !== m.year;

              return (
                <>
                  {/* Séparateur d'année en mode multi-années */}
                  {viewMode === 'all-years' && isNewYear && idx > 0 && (
                    <TableRow key={`sep-${m.year}`} className="bg-muted/50">
                      <TableCell colSpan={11} className="py-1 text-center text-xs font-medium text-muted-foreground">
                        — {m.year} —
                      </TableCell>
                    </TableRow>
                  )}
                  
                  <TableRow 
                    key={rowKey}
                    className={cn(
                      isNegative && "bg-destructive/5",
                      isMinTreasury && "ring-2 ring-inset ring-destructive/50"
                    )}
                  >
                    <TableCell className="sticky left-0 bg-background z-10 font-medium">
                      <div className="flex items-center gap-2">
                        <span>{m.monthName.slice(0, 3)} {viewMode === 'all-years' ? m.year : ''}</span>
                        {isMinTreasury && (
                          <AlertTriangle className="h-3 w-3 text-destructive" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs">
                      {formatCurrency(m.treasuryStart, true)}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs text-chart-4">
                      {m.revenue > 0 ? formatCurrency(m.revenue, true) : '-'}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs text-chart-4">
                      {m.fundingInjection > 0 ? formatCurrency(m.fundingInjection, true) : '-'}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs text-destructive">
                      {m.cogs > 0 ? `-${formatCurrency(m.cogs, true)}` : '-'}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs text-destructive">
                      {m.payroll > 0 ? `-${formatCurrency(m.payroll, true)}` : '-'}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs text-destructive">
                      {m.opex > 0 ? `-${formatCurrency(m.opex, true)}` : '-'}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs text-destructive">
                      {m.variableCharges > 0 ? `-${formatCurrency(m.variableCharges, true)}` : '-'}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs text-destructive">
                      {m.loanPayments > 0 ? `-${formatCurrency(m.loanPayments, true)}` : '-'}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs text-destructive">
                      {m.capexPayments > 0 ? `-${formatCurrency(m.capexPayments, true)}` : '-'}
                    </TableCell>
                    <TableCell className={cn(
                      "text-right font-mono text-xs font-medium",
                      m.netCashFlow >= 0 ? "text-chart-4" : "text-destructive"
                    )}>
                      {m.netCashFlow >= 0 ? '+' : ''}{formatCurrency(m.netCashFlow, true)}
                    </TableCell>
                    <TableCell className={cn(
                      "text-right font-mono text-xs font-bold",
                      m.treasuryEnd < 0 && "text-destructive"
                    )}>
                      {formatCurrency(m.treasuryEnd, true)}
                    </TableCell>
                  </TableRow>
                </>
              );
            })}

            {/* Ligne de total pour la période affichée */}
            <TableRow className="bg-muted font-medium">
              <TableCell className="sticky left-0 bg-muted z-10">
                Total {viewMode === 'single-year' ? selectedYear : `${startYear}-${startYear + durationYears - 1}`}
              </TableCell>
              <TableCell className="text-right">-</TableCell>
              <TableCell className="text-right font-mono">
                {formatCurrency(displayedMonths.reduce((s, m) => s + m.revenue, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono">
                {formatCurrency(displayedMonths.reduce((s, m) => s + m.fundingInjection, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono">
                {formatCurrency(displayedMonths.reduce((s, m) => s + m.cogs, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono">
                {formatCurrency(displayedMonths.reduce((s, m) => s + m.payroll, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono">
                {formatCurrency(displayedMonths.reduce((s, m) => s + m.opex, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono">
                {formatCurrency(displayedMonths.reduce((s, m) => s + m.variableCharges, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono">
                {formatCurrency(displayedMonths.reduce((s, m) => s + m.loanPayments, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono">
                {formatCurrency(displayedMonths.reduce((s, m) => s + m.capexPayments, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono">
                {formatCurrency(displayedMonths.reduce((s, m) => s + m.netCashFlow, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono">
                {displayedMonths.length > 0 
                  ? formatCurrency(displayedMonths[displayedMonths.length - 1].treasuryEnd, true)
                  : '-'}
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </div>

      {/* Résumé annuel en mode multi-années */}
      {viewMode === 'all-years' && (
        <div className="border rounded-lg p-4">
          <h4 className="font-medium mb-3">Résumé par année</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {years.map(year => {
              const data = yearlyAggregates.get(year);
              if (!data) return null;
              return (
                <div key={year} className="p-3 bg-muted/30 rounded-lg">
                  <p className="text-sm font-medium">{year}</p>
                  <p className="text-xs text-muted-foreground">CA: {formatCurrency(data.revenue, true)}</p>
                  <p className={cn(
                    "text-sm font-mono font-medium mt-1",
                    data.treasuryEnd < 0 && "text-destructive"
                  )}>
                    Fin: {formatCurrency(data.treasuryEnd, true)}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

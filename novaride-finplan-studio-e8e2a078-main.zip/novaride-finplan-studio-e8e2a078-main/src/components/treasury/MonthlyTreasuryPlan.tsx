import { useState } from 'react';
import { useFinancial } from '@/context/FinancialContext';
import { SectionCard, KPICard } from '@/components/ui/KPICard';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { formatCurrency } from '@/data/financialConfig';
import { cn } from '@/lib/utils';
import {
  CalendarDays,
  TrendingDown,
  TrendingUp,
  Wallet,
  AlertTriangle,
  Settings2,
  Package,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  ReferenceLine,
  ComposedChart,
  Bar,
} from 'recharts';
import { MONTHS, formatMonthYear } from '@/engine/monthlyTreasuryEngine';
import { SeasonalitySliders } from '@/components/treasury/SeasonalitySliders';
import { VariableChargesEditor } from '@/components/treasury/VariableChargesEditor';
import { LoansManager } from '@/components/treasury/LoansManager';
import { MonthlyTreasuryTable } from '@/components/treasury/MonthlyTreasuryTable';
import { CapexEditor } from '@/components/treasury/CapexEditor';

type ChartSeries = 'treasury' | 'revenue' | 'cogs' | 'loans' | 'capex';

const CHART_SERIES_CONFIG: Record<ChartSeries, { label: string; color: string; type: 'area' | 'bar' }> = {
  treasury: { label: 'Trésorerie', color: 'hsl(var(--primary))', type: 'area' },
  revenue: { label: 'Chiffre d\'affaires', color: 'hsl(var(--chart-4))', type: 'bar' },
  cogs: { label: 'Achats (COGS)', color: 'hsl(var(--chart-2))', type: 'bar' },
  loans: { label: 'Échéances prêts', color: 'hsl(var(--destructive))', type: 'bar' },
  capex: { label: 'CAPEX', color: 'hsl(var(--chart-3))', type: 'bar' },
};

export function MonthlyTreasuryPlan() {
  const { 
    state, 
    computed, 
    updateRevenueSeasonality, 
    updateCogsSeasonality,
    updateVariableCharges,
    updateLoans,
    updateCapexPayments,
  } = useFinancial();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [visibleSeries, setVisibleSeries] = useState<ChartSeries[]>(['treasury']);
  
  const { startYear, durationYears } = state.scenarioSettings;
  const { monthlyTreasuryProjection } = computed;
  const config = state.monthlyTreasuryConfig;
  
  // KPIs principaux
  const minTreasury = monthlyTreasuryProjection.minTreasury;
  const minTreasuryMonth = monthlyTreasuryProjection.minTreasuryMonth;
  const totalFunding = monthlyTreasuryProjection.totalFundingRaised;
  const breakEvenMonth = monthlyTreasuryProjection.breakEvenMonth;
  const lastMonth = monthlyTreasuryProjection.months[monthlyTreasuryProjection.months.length - 1];
  const hasNegativeTreasury = minTreasury < 0;
  
  // Données pour le graphique principal
  const chartData = monthlyTreasuryProjection.months.map((m, idx) => ({
    index: idx,
    label: `${m.monthName.slice(0, 3)} ${m.year}`,
    treasury: m.treasuryEnd / 1000,
    revenue: m.revenue / 1000,
    cogs: m.cogs / 1000,
    loans: m.loanPayments / 1000,
    capex: m.capexPayments / 1000,
    netCashFlow: m.netCashFlow / 1000,
  }));

  const toggleSeries = (series: ChartSeries) => {
    setVisibleSeries(prev => 
      prev.includes(series) 
        ? prev.filter(s => s !== series)
        : [...prev, series]
    );
  };
  
  // Estimation CA annuel pour les charges variables
  const estimatedAnnualRevenue = computed.revenueByYear.reduce((sum, r) => sum + r.revenue, 0) / durationYears;

  return (
    <div className="space-y-6">
      {/* Alerte trésorerie négative */}
      {hasNegativeTreasury && (
        <div className="p-4 bg-destructive/10 border border-destructive/30 rounded-lg flex items-center gap-3">
          <AlertTriangle className="h-5 w-5 text-destructive flex-shrink-0" />
          <div>
            <span className="font-medium text-destructive">Alerte Trésorerie</span>
            <span className="text-sm text-muted-foreground ml-2">
              Point bas de {formatCurrency(minTreasury, true)} prévu en{' '}
              {minTreasuryMonth ? formatMonthYear(minTreasuryMonth.year, minTreasuryMonth.month) : 'N/A'}
            </span>
          </div>
        </div>
      )}

      {/* KPIs */}
      <div id="monthly-treasury-kpis" className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KPICard
          label="Trésorerie Initiale"
          value={formatCurrency(monthlyTreasuryProjection.initialCash, true)}
          subValue={`Début ${startYear}`}
        />
        <KPICard
          label="Trésorerie Finale"
          value={formatCurrency(lastMonth?.treasuryEnd || 0, true)}
          subValue={lastMonth ? `Fin ${lastMonth.monthName} ${lastMonth.year}` : ''}
          trend={lastMonth && lastMonth.treasuryEnd > monthlyTreasuryProjection.initialCash ? 'up' : 'down'}
        />
        <KPICard
          label="Point Bas"
          value={formatCurrency(minTreasury, true)}
          subValue={minTreasuryMonth ? formatMonthYear(minTreasuryMonth.year, minTreasuryMonth.month) : ''}
          trend={minTreasury < 0 ? 'down' : undefined}
        />
        <KPICard
          label="Levées de Fonds"
          value={formatCurrency(totalFunding, true)}
          subValue="Total injecté"
        />
      </div>

      {/* Graphique principal */}
      <SectionCard title="Évolution de la Trésorerie Mensuelle" id="monthly-treasury-chart">
        {/* Sélecteur de séries */}
        <div className="flex flex-wrap gap-4 mb-4 pb-4 border-b">
          {(Object.keys(CHART_SERIES_CONFIG) as ChartSeries[]).map((series) => (
            <div key={series} className="flex items-center space-x-2">
              <Checkbox
                id={`chart-${series}`}
                checked={visibleSeries.includes(series)}
                onCheckedChange={() => toggleSeries(series)}
              />
              <Label 
                htmlFor={`chart-${series}`} 
                className="text-sm cursor-pointer flex items-center gap-2"
              >
                <span 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: CHART_SERIES_CONFIG[series].color }}
                />
                {CHART_SERIES_CONFIG[series].label}
              </Label>
            </div>
          ))}
        </div>

        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="label" 
                tick={{ fontSize: 10 }}
                interval={Math.floor(chartData.length / 12)}
              />
              <YAxis tickFormatter={(v) => `${v}k€`} />
              <Tooltip 
                formatter={(value: number, name: string) => {
                  const config = CHART_SERIES_CONFIG[name as ChartSeries];
                  return [`${value.toFixed(0)}k€`, config?.label || name];
                }}
              />
              <ReferenceLine y={0} stroke="hsl(var(--destructive))" strokeDasharray="3 3" />
              
              {visibleSeries.includes('treasury') && (
                <Area
                  type="monotone"
                  dataKey="treasury"
                  name="treasury"
                  fill="hsl(var(--primary))"
                  fillOpacity={0.2}
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                />
              )}
              {visibleSeries.includes('revenue') && (
                <Bar
                  dataKey="revenue"
                  name="revenue"
                  fill="hsl(var(--chart-4))"
                  fillOpacity={0.7}
                />
              )}
              {visibleSeries.includes('cogs') && (
                <Bar
                  dataKey="cogs"
                  name="cogs"
                  fill="hsl(var(--chart-2))"
                  fillOpacity={0.7}
                />
              )}
              {visibleSeries.includes('loans') && (
                <Bar
                  dataKey="loans"
                  name="loans"
                  fill="hsl(var(--destructive))"
                  fillOpacity={0.7}
                />
              )}
              {visibleSeries.includes('capex') && (
                <Bar
                  dataKey="capex"
                  name="capex"
                  fill="hsl(var(--chart-3))"
                  fillOpacity={0.7}
                />
              )}
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </SectionCard>

      {/* Onglets de configuration */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="dashboard">
            <Wallet className="h-4 w-4 mr-2" />
            Tableau
          </TabsTrigger>
          <TabsTrigger value="revenue-seasonality">
            <TrendingUp className="h-4 w-4 mr-2" />
            Saisonnalité CA
          </TabsTrigger>
          <TabsTrigger value="cogs-seasonality">
            <TrendingDown className="h-4 w-4 mr-2" />
            Saisonnalité Achats
          </TabsTrigger>
          <TabsTrigger value="variable-charges">
            <Settings2 className="h-4 w-4 mr-2" />
            Charges Variables
          </TabsTrigger>
          <TabsTrigger value="capex">
            <Package className="h-4 w-4 mr-2" />
            CAPEX
          </TabsTrigger>
          <TabsTrigger value="loans">
            <CalendarDays className="h-4 w-4 mr-2" />
            Prêts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="mt-6">
          <MonthlyTreasuryTable
            months={monthlyTreasuryProjection.months}
            startYear={startYear}
            durationYears={durationYears}
          />
        </TabsContent>

        <TabsContent value="revenue-seasonality" className="mt-6">
          <SectionCard title="Saisonnalité du Chiffre d'Affaires">
            <SeasonalitySliders
              title="Variation mensuelle du CA"
              description="Ajustez la répartition du CA sur l'année. Les valeurs sont normalisées automatiquement."
              value={config.revenueSeasonality}
              onChange={updateRevenueSeasonality}
            />
          </SectionCard>
        </TabsContent>

        <TabsContent value="cogs-seasonality" className="mt-6">
          <SectionCard title="Saisonnalité des Achats (COGS)">
            <SeasonalitySliders
              title="Variation mensuelle des achats"
              description="Ajustez la répartition des achats sur l'année. Peut être différente du CA si vous anticipez ou stockez."
              value={config.cogsSeasonality}
              onChange={updateCogsSeasonality}
            />
          </SectionCard>
        </TabsContent>

        <TabsContent value="variable-charges" className="mt-6">
          <SectionCard title="Charges Variables">
            <VariableChargesEditor
              value={config.variableCharges}
              onChange={updateVariableCharges}
              estimatedAnnualRevenue={estimatedAnnualRevenue}
            />
          </SectionCard>
        </TabsContent>

        <TabsContent value="capex" className="mt-6">
          <SectionCard title="Investissements R&D (CAPEX)">
            <CapexEditor
              value={config.capexPayments || []}
              onChange={updateCapexPayments}
              products={state.products}
              startYear={startYear}
              durationYears={durationYears}
            />
          </SectionCard>
        </TabsContent>

        <TabsContent value="loans" className="mt-6">
          <SectionCard title="Gestion des Prêts">
            <LoansManager
              value={config.loans}
              onChange={updateLoans}
              startYear={startYear}
              durationYears={durationYears}
            />
          </SectionCard>
        </TabsContent>
      </Tabs>


      {/* Résumé */}
      <div id="monthly-treasury-summary" className="grid md:grid-cols-4 gap-4">
        <div className="p-4 border rounded-lg bg-muted/30">
          <h4 className="font-medium mb-2 flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-chart-4" />
            Charges Variables
          </h4>
          <p className="text-2xl font-bold font-mono">
            {formatCurrency(monthlyTreasuryProjection.totalVariableCharges, true)}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Total sur {durationYears} ans
          </p>
        </div>
        <div className="p-4 border rounded-lg bg-muted/30">
          <h4 className="font-medium mb-2 flex items-center gap-2">
            <Package className="h-4 w-4 text-chart-3" />
            CAPEX
          </h4>
          <p className="text-2xl font-bold font-mono">
            {formatCurrency(monthlyTreasuryProjection.totalCapexPayments, true)}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Investissements R&D planifiés
          </p>
        </div>
        <div className="p-4 border rounded-lg bg-muted/30">
          <h4 className="font-medium mb-2 flex items-center gap-2">
            <CalendarDays className="h-4 w-4 text-primary" />
            Échéances Prêts
          </h4>
          <p className="text-2xl font-bold font-mono">
            {formatCurrency(monthlyTreasuryProjection.totalLoanPayments, true)}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Total des remboursements
          </p>
        </div>
        <div className="p-4 border rounded-lg bg-muted/30">
          <h4 className="font-medium mb-2 flex items-center gap-2">
            <Wallet className="h-4 w-4 text-accent" />
            Break-even
          </h4>
          <p className="text-2xl font-bold">
            {breakEvenMonth 
              ? formatMonthYear(breakEvenMonth.year, breakEvenMonth.month)
              : 'N/A'}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Premier mois cash-flow positif
          </p>
        </div>
      </div>
    </div>
  );
}

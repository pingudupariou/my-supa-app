import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Plus, Trash2, Package, AlertTriangle, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatCurrency } from '@/data/financialConfig';
import { Product } from '@/engine/types';
import { CapexPaymentConfig, MonthIndex, MONTHS, getMonthKey, formatMonthYear } from '@/engine/monthlyTreasuryEngine';

interface CapexEditorProps {
  value: CapexPaymentConfig[];
  onChange: (payments: CapexPaymentConfig[]) => void;
  products: Product[];
  startYear: number;
  durationYears: number;
}

export function CapexEditor({
  value,
  onChange,
  products,
  startYear,
  durationYears,
}: CapexEditorProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [selectedYear, setSelectedYear] = useState<number>(startYear);
  const [selectedMonth, setSelectedMonth] = useState<MonthIndex>(0);
  const [percentage, setPercentage] = useState<number>(25);

  // Calculer le total déjà alloué par produit
  const getSpentPercentage = (productId: string): number => {
    return value
      .filter(p => p.productId === productId)
      .reduce((sum, p) => sum + p.percentageOfTotal, 0);
  };

  const getSpentAmount = (productId: string): number => {
    const product = products.find(p => p.id === productId);
    if (!product) return 0;
    return (getSpentPercentage(productId) / 100) * product.devCost;
  };

  const getRemainingPercentage = (productId: string): number => {
    return Math.max(0, 100 - getSpentPercentage(productId));
  };

  // Vérifier si un produit a des CAPEX à allouer
  const productsWithCapex = products.filter(p => p.devCost > 0);

  // Générer les années disponibles
  const years = Array.from({ length: durationYears }, (_, i) => startYear + i);

  const handleAddPayment = () => {
    if (!selectedProductId) return;
    
    const remaining = getRemainingPercentage(selectedProductId);
    if (percentage > remaining) {
      return; // Ne pas permettre de dépasser 100%
    }

    const product = products.find(p => p.id === selectedProductId);
    if (!product) return;

    const newPayment: CapexPaymentConfig = {
      id: `capex-${Date.now()}`,
      productId: selectedProductId,
      productName: product.name,
      year: selectedYear,
      month: selectedMonth,
      percentageOfTotal: percentage,
      amount: (percentage / 100) * product.devCost,
    };

    onChange([...value, newPayment]);
    setIsDialogOpen(false);
    setPercentage(25);
  };

  const handleRemovePayment = (id: string) => {
    onChange(value.filter(p => p.id !== id));
  };

  // Grouper les paiements par produit
  const paymentsByProduct = value.reduce((acc, payment) => {
    if (!acc[payment.productId]) {
      acc[payment.productId] = [];
    }
    acc[payment.productId].push(payment);
    return acc;
  }, {} as Record<string, CapexPaymentConfig[]>);

  // Trier les paiements par date
  const sortedPayments = [...value].sort((a, b) => {
    if (a.year !== b.year) return a.year - b.year;
    return a.month - b.month;
  });

  const selectedProduct = products.find(p => p.id === selectedProductId);
  const maxPercentage = selectedProduct ? getRemainingPercentage(selectedProductId) : 100;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">
            Planifiez les décaissements de vos investissements R&D par produit. 
            Vous pouvez étaler les dépenses sur plusieurs mois sans dépasser le budget total.
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" disabled={productsWithCapex.length === 0}>
              <Plus className="h-4 w-4 mr-2" />
              Ajouter une échéance
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Nouvelle échéance CAPEX</DialogTitle>
              <DialogDescription>
                Planifiez un décaissement lié au développement d'un produit
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {/* Sélection du produit */}
              <div className="space-y-2">
                <Label>Produit</Label>
                <Select value={selectedProductId} onValueChange={setSelectedProductId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner un produit" />
                  </SelectTrigger>
                  <SelectContent>
                    {productsWithCapex.map(product => {
                      const remaining = getRemainingPercentage(product.id);
                      const isComplete = remaining === 0;
                      return (
                        <SelectItem 
                          key={product.id} 
                          value={product.id}
                          disabled={isComplete}
                        >
                          <div className="flex items-center gap-2">
                            <Package className="h-4 w-4" />
                            <span>{product.name}</span>
                            <Badge 
                              variant={isComplete ? "secondary" : "outline"} 
                              className="ml-2"
                            >
                              {isComplete ? (
                                <><Check className="h-3 w-3 mr-1" /> 100%</>
                              ) : (
                                `${remaining}% restant`
                              )}
                            </Badge>
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>

              {/* Info produit sélectionné */}
              {selectedProduct && (
                <div className="p-3 bg-muted/50 rounded-lg space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Budget total R&D</span>
                    <span className="font-mono font-medium">
                      {formatCurrency(selectedProduct.devCost, true)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Déjà alloué</span>
                    <span className="font-mono">
                      {formatCurrency(getSpentAmount(selectedProduct.id), true)} ({getSpentPercentage(selectedProduct.id).toFixed(0)}%)
                    </span>
                  </div>
                  <Progress value={getSpentPercentage(selectedProduct.id)} className="h-2" />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Restant à planifier</span>
                    <span className="font-mono">
                      {formatCurrency(selectedProduct.devCost - getSpentAmount(selectedProduct.id), true)}
                    </span>
                  </div>
                </div>
              )}

              {/* Date */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Année</Label>
                  <Select 
                    value={selectedYear.toString()} 
                    onValueChange={(v) => setSelectedYear(parseInt(v))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {years.map(year => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Mois</Label>
                  <Select 
                    value={selectedMonth.toString()} 
                    onValueChange={(v) => setSelectedMonth(parseInt(v) as MonthIndex)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {MONTHS.map((month, idx) => (
                        <SelectItem key={idx} value={idx.toString()}>
                          {month}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Pourcentage */}
              <div className="space-y-2">
                <Label>Pourcentage du budget total</Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    min={1}
                    max={maxPercentage}
                    value={percentage}
                    onChange={(e) => setPercentage(Math.min(maxPercentage, Math.max(1, parseInt(e.target.value) || 0)))}
                    className="w-24"
                  />
                  <span className="text-muted-foreground">%</span>
                  {selectedProduct && (
                    <span className="text-sm text-muted-foreground ml-2">
                      = {formatCurrency((percentage / 100) * selectedProduct.devCost, true)}
                    </span>
                  )}
                </div>
                {percentage > maxPercentage && (
                  <p className="text-sm text-destructive flex items-center gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    Maximum autorisé : {maxPercentage}%
                  </p>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Annuler
              </Button>
              <Button 
                onClick={handleAddPayment}
                disabled={!selectedProductId || percentage > maxPercentage || percentage <= 0}
              >
                Ajouter
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Résumé par produit */}
      {productsWithCapex.length > 0 && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {productsWithCapex.map(product => {
            const spent = getSpentPercentage(product.id);
            const remaining = getRemainingPercentage(product.id);
            const isComplete = remaining === 0;
            const payments = paymentsByProduct[product.id] || [];
            
            return (
              <div 
                key={product.id}
                className={cn(
                  "p-4 border rounded-lg",
                  isComplete ? "bg-chart-4/10 border-chart-4/30" : "bg-muted/30"
                )}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Package className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium text-sm">{product.name}</span>
                  </div>
                  {isComplete && (
                    <Badge variant="secondary" className="bg-chart-4/20 text-chart-4">
                      <Check className="h-3 w-3 mr-1" />
                      Complet
                    </Badge>
                  )}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Budget R&D</span>
                    <span className="font-mono">{formatCurrency(product.devCost, true)}</span>
                  </div>
                  <Progress value={spent} className="h-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{spent.toFixed(0)}% planifié</span>
                    <span>{payments.length} échéance{payments.length > 1 ? 's' : ''}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Tableau des échéances */}
      {sortedPayments.length > 0 ? (
        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead>Produit</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="text-right">% du budget</TableHead>
                <TableHead className="text-right">Montant</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedPayments.map(payment => (
                <TableRow key={payment.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-muted-foreground" />
                      {payment.productName}
                    </div>
                  </TableCell>
                  <TableCell>
                    {formatMonthYear(payment.year, payment.month)}
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    {payment.percentageOfTotal}%
                  </TableCell>
                  <TableCell className="text-right font-mono font-medium">
                    {formatCurrency(payment.amount, true)}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      onClick={() => handleRemovePayment(payment.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="text-center py-8 text-muted-foreground border rounded-lg bg-muted/20">
          <Package className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p>Aucune échéance CAPEX planifiée</p>
          <p className="text-sm">
            {productsWithCapex.length === 0 
              ? "Ajoutez des produits avec des coûts R&D dans le Plan Produit" 
              : "Cliquez sur \"Ajouter une échéance\" pour planifier vos investissements"
            }
          </p>
        </div>
      )}

      {/* Résumé total */}
      {sortedPayments.length > 0 && (
        <div className="flex justify-between items-center p-4 bg-muted/30 rounded-lg">
          <span className="font-medium">Total CAPEX planifié</span>
          <span className="text-xl font-bold font-mono">
            {formatCurrency(sortedPayments.reduce((sum, p) => sum + p.amount, 0), true)}
          </span>
        </div>
      )}
    </div>
  );
}

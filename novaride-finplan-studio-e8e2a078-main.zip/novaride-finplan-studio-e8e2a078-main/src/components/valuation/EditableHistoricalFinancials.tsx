import { useState } from 'react';
import { SectionCard } from '@/components/ui/KPICard';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { formatCurrency, formatPercent } from '@/data/financialConfig';
import { cn } from '@/lib/utils';
import { Edit2, Check, X, Plus, Trash2 } from 'lucide-react';
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

export interface HistoricalYearData {
  year: number;
  revenue: number;
  grossMargin: number;
  payroll: number;
  externalCosts: number;
  depreciation: number;
  cash: number;
  inventory: number;
}

interface EditableHistoricalFinancialsProps {
  data: HistoricalYearData[];
  onChange: (data: HistoricalYearData[]) => void;
  className?: string;
}

export function EditableHistoricalFinancials({ 
  data, 
  onChange, 
  className 
}: EditableHistoricalFinancialsProps) {
  const [editingYear, setEditingYear] = useState<number | null>(null);
  const [editForm, setEditForm] = useState<Partial<HistoricalYearData>>({});

  // Calcul des indicateurs dérivés
  const historicalMetrics = data.map(d => {
    const grossProfit = d.revenue * d.grossMargin;
    const ebitda = grossProfit - d.payroll - d.externalCosts;
    const ebit = ebitda - d.depreciation;
    const ebitdaMargin = d.revenue > 0 ? ebitda / d.revenue : 0;
    
    return {
      ...d,
      grossProfit,
      ebitda,
      ebitdaMargin,
      ebit,
    };
  });

  // Données pour le graphique
  const chartData = historicalMetrics.map(m => ({
    year: m.year,
    revenue: m.revenue / 1000,
    ebitda: m.ebitda / 1000,
    ebit: m.ebit / 1000,
    margin: m.ebitdaMargin * 100,
  }));

  // CAGR
  const firstYear = historicalMetrics[0];
  const lastYear = historicalMetrics[historicalMetrics.length - 1];
  const years = lastYear ? lastYear.year - firstYear.year : 0;
  const revenueCagr = years > 0 && firstYear.revenue > 0 
    ? Math.pow(lastYear.revenue / firstYear.revenue, 1 / years) - 1 
    : 0;

  const handleEdit = (yearData: HistoricalYearData) => {
    setEditingYear(yearData.year);
    setEditForm(yearData);
  };

  const handleSave = () => {
    if (editingYear && editForm) {
      const updated = data.map(d => 
        d.year === editingYear ? { ...d, ...editForm } as HistoricalYearData : d
      );
      onChange(updated);
      setEditingYear(null);
      setEditForm({});
    }
  };

  const handleCancel = () => {
    setEditingYear(null);
    setEditForm({});
  };

  const handleAddYear = () => {
    const maxYear = Math.max(...data.map(d => d.year), 2024);
    const newYear: HistoricalYearData = {
      year: maxYear + 1,
      revenue: 0,
      grossMargin: 0.70,
      payroll: 0,
      externalCosts: 0,
      depreciation: 0,
      cash: 0,
      inventory: 0,
    };
    onChange([...data, newYear]);
  };

  const handleRemoveYear = (year: number) => {
    onChange(data.filter(d => d.year !== year));
  };

  const updateField = (field: keyof HistoricalYearData, value: number) => {
    setEditForm(prev => ({ ...prev, [field]: value }));
  };

  return (
    <SectionCard 
      title="Historique Financier" 
      className={className}
      action={
        <Button size="sm" variant="outline" onClick={handleAddYear}>
          <Plus className="h-4 w-4 mr-1" />
          Ajouter année
        </Button>
      }
    >
      <div className="flex items-center gap-2 mb-4">
        <Badge variant="outline">Données éditables</Badge>
        <Badge variant="secondary">
          TCAC CA: {formatPercent(revenueCagr)}
        </Badge>
      </div>

      {/* Graphique */}
      <div className="h-64 mb-6">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="year" />
            <YAxis yAxisId="left" tickFormatter={(v) => `${v}k€`} />
            <YAxis yAxisId="right" orientation="right" domain={[-20, 30]} tickFormatter={(v) => `${v}%`} />
            <Tooltip 
              formatter={(value: number, name: string) => 
                name === 'margin' ? `${value.toFixed(1)}%` : `${value.toFixed(0)}k€`
              } 
            />
            <Legend />
            <Bar yAxisId="left" dataKey="revenue" name="CA" fill="hsl(0, 85%, 50%)" />
            <Bar yAxisId="left" dataKey="ebitda" name="EBITDA" fill="hsl(38, 92%, 50%)" />
            <Bar yAxisId="left" dataKey="ebit" name="EBIT" fill="hsl(210, 70%, 50%)" />
            <Line yAxisId="right" type="monotone" dataKey="margin" name="Marge EBITDA" stroke="hsl(150, 60%, 40%)" strokeWidth={2} dot />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Tableau éditable */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-muted/30">
              <th className="text-left py-2 px-3 font-medium">Indicateur</th>
              {historicalMetrics.map(m => (
                <th key={m.year} className="text-right py-2 px-3 font-mono-numbers">
                  <div className="flex items-center justify-end gap-2">
                    {m.year}
                    {editingYear !== m.year && (
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        className="h-6 w-6"
                        onClick={() => handleEdit(data.find(d => d.year === m.year)!)}
                      >
                        <Edit2 className="h-3 w-3" />
                      </Button>
                    )}
                    {editingYear === m.year && (
                      <div className="flex gap-1">
                        <Button size="icon" variant="ghost" className="h-6 w-6" onClick={handleSave}>
                          <Check className="h-3 w-3 text-green-600" />
                        </Button>
                        <Button size="icon" variant="ghost" className="h-6 w-6" onClick={handleCancel}>
                          <X className="h-3 w-3 text-destructive" />
                        </Button>
                      </div>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {/* CA */}
            <tr className="border-b">
              <td className="py-2 px-3 font-medium">Chiffre d'Affaires</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3">
                  {editingYear === m.year ? (
                    <Input
                      type="number"
                      value={editForm.revenue || 0}
                      onChange={(e) => updateField('revenue', Number(e.target.value))}
                      className="h-7 w-28 text-right ml-auto"
                    />
                  ) : (
                    <span className="font-mono-numbers">{formatCurrency(m.revenue, true)}</span>
                  )}
                </td>
              ))}
            </tr>

            {/* Marge Brute % */}
            <tr className="border-b">
              <td className="py-2 px-3">Marge Brute %</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3">
                  {editingYear === m.year ? (
                    <Input
                      type="number"
                      value={((editForm.grossMargin || 0) * 100).toFixed(0)}
                      onChange={(e) => updateField('grossMargin', Number(e.target.value) / 100)}
                      className="h-7 w-20 text-right ml-auto"
                      step="1"
                    />
                  ) : (
                    <span className="font-mono-numbers">{formatPercent(m.grossMargin)}</span>
                  )}
                </td>
              ))}
            </tr>

            {/* Masse Salariale */}
            <tr className="border-b bg-muted/20">
              <td className="py-2 px-3 text-muted-foreground">Masse Salariale</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3">
                  {editingYear === m.year ? (
                    <Input
                      type="number"
                      value={editForm.payroll || 0}
                      onChange={(e) => updateField('payroll', Number(e.target.value))}
                      className="h-7 w-28 text-right ml-auto"
                    />
                  ) : (
                    <span className="font-mono-numbers text-muted-foreground">{formatCurrency(m.payroll, true)}</span>
                  )}
                </td>
              ))}
            </tr>

            {/* Charges Externes */}
            <tr className="border-b bg-muted/20">
              <td className="py-2 px-3 text-muted-foreground">Charges Externes</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3">
                  {editingYear === m.year ? (
                    <Input
                      type="number"
                      value={editForm.externalCosts || 0}
                      onChange={(e) => updateField('externalCosts', Number(e.target.value))}
                      className="h-7 w-28 text-right ml-auto"
                    />
                  ) : (
                    <span className="font-mono-numbers text-muted-foreground">{formatCurrency(m.externalCosts, true)}</span>
                  )}
                </td>
              ))}
            </tr>

            {/* EBITDA (calculé) */}
            <tr className="border-b font-medium">
              <td className="py-2 px-3">EBITDA</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className={cn(
                  "text-right py-2 px-3 font-mono-numbers",
                  m.ebitda < 0 ? "text-destructive" : "text-green-600"
                )}>
                  {formatCurrency(m.ebitda, true)}
                  <span className="text-xs ml-1">({formatPercent(m.ebitdaMargin)})</span>
                </td>
              ))}
            </tr>

            {/* Amortissements */}
            <tr className="border-b bg-muted/20">
              <td className="py-2 px-3 text-muted-foreground">Amortissements</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3">
                  {editingYear === m.year ? (
                    <Input
                      type="number"
                      value={editForm.depreciation || 0}
                      onChange={(e) => updateField('depreciation', Number(e.target.value))}
                      className="h-7 w-28 text-right ml-auto"
                    />
                  ) : (
                    <span className="font-mono-numbers text-muted-foreground">{formatCurrency(m.depreciation, true)}</span>
                  )}
                </td>
              ))}
            </tr>

            {/* EBIT (calculé) */}
            <tr className="border-b font-medium">
              <td className="py-2 px-3">EBIT (Résultat d'Exploitation)</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className={cn(
                  "text-right py-2 px-3 font-mono-numbers",
                  m.ebit < 0 ? "text-destructive" : ""
                )}>
                  {formatCurrency(m.ebit, true)}
                </td>
              ))}
            </tr>

            {/* Trésorerie */}
            <tr className="border-b">
              <td className="py-2 px-3">Trésorerie</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3">
                  {editingYear === m.year ? (
                    <Input
                      type="number"
                      value={editForm.cash || 0}
                      onChange={(e) => updateField('cash', Number(e.target.value))}
                      className="h-7 w-28 text-right ml-auto"
                    />
                  ) : (
                    <span className="font-mono-numbers">{formatCurrency(m.cash, true)}</span>
                  )}
                </td>
              ))}
            </tr>

            {/* Stock */}
            <tr className="border-b">
              <td className="py-2 px-3">Stock</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3">
                  {editingYear === m.year ? (
                    <Input
                      type="number"
                      value={editForm.inventory || 0}
                      onChange={(e) => updateField('inventory', Number(e.target.value))}
                      className="h-7 w-28 text-right ml-auto"
                    />
                  ) : (
                    <span className="font-mono-numbers">{formatCurrency(m.inventory, true)}</span>
                  )}
                </td>
              ))}
            </tr>

            {/* Actions */}
            <tr>
              <td className="py-2 px-3 text-muted-foreground">Actions</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3">
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-6 w-6 text-destructive"
                    onClick={() => handleRemoveYear(m.year)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </SectionCard>
  );
}

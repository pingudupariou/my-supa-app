import { SectionCard, KPICard } from '@/components/ui/KPICard';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { formatCurrency, formatPercent } from '@/data/financialConfig';
import { cn } from '@/lib/utils';
import { Info, Users, TrendingUp } from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';

export interface DilutionConfig {
  // Montant total à lever (synchronisé avec financement)
  totalRaise: number;
  
  // Répartition Equity vs OC (0 = tout equity, 1 = tout OC)
  ocRatio: number;
  
  // Obligations Convertibles
  enableConvertibleBonds: boolean;
  ocDiscount: number;
  ocCap: number;
  ocInterestRate: number;
  ocMaturityYears: number;
  
  // BSPCE / Options
  enableBSPCE: boolean;
  bspcePool: number;
  
  // Valorisation via multiple EBITDA
  ebitdaMultiple: number;
  referenceEBITDA: number;
}

interface DilutionSimulatorProps {
  config: DilutionConfig;
  onConfigChange: (config: DilutionConfig) => void;
}

const COLORS = ['hsl(0, 85%, 50%)', 'hsl(38, 92%, 50%)', 'hsl(150, 60%, 40%)', 'hsl(210, 70%, 50%)'];

export function DilutionSimulator({ config, onConfigChange }: DilutionSimulatorProps) {
  // Calculs dérivés
  const equityAmount = config.totalRaise * (1 - config.ocRatio);
  const ocAmount = config.enableConvertibleBonds ? config.totalRaise * config.ocRatio : 0;
  
  // Valorisation Pre-Money via multiple EBITDA (minimum 200k€)
  const preMoneyValuation = Math.max(200000, config.referenceEBITDA * config.ebitdaMultiple);
  const postMoneyValuation = preMoneyValuation + equityAmount;
  
  // Dilution equity
  const equityDilution = postMoneyValuation > 0 ? equityAmount / postMoneyValuation : 0;
  
  // OC conversion estimation (au prochain tour, estimé à 2x la valo actuelle)
  const nextRoundValuation = postMoneyValuation * 2;
  const ocConversionPrice = Math.min(
    config.ocCap,
    nextRoundValuation * (1 - config.ocDiscount)
  );
  const ocWithInterest = ocAmount * Math.pow(1 + config.ocInterestRate, config.ocMaturityYears);
  const ocDilution = config.enableConvertibleBonds && nextRoundValuation > 0
    ? ocWithInterest / (nextRoundValuation + ocWithInterest)
    : 0;
  
  // BSPCE
  const bspceDilution = config.enableBSPCE ? config.bspcePool : 0;
  
  // Total dilution
  const totalDilution = equityDilution + ocDilution + bspceDilution;
  const foundersRemaining = 1 - totalDilution;
  
  // Cap table data
  const capTableData = [
    { name: 'Fondateurs', value: foundersRemaining * 100, color: COLORS[0] },
    ...(equityAmount > 0 ? [{ name: 'Equity', value: equityDilution * 100, color: COLORS[1] }] : []),
    ...(config.enableConvertibleBonds && ocAmount > 0 ? [{ name: 'OC (estimé)', value: ocDilution * 100, color: COLORS[2] }] : []),
    ...(config.enableBSPCE ? [{ name: 'BSPCE Pool', value: bspceDilution * 100, color: COLORS[3] }] : []),
  ].filter(d => d.value > 0);

  return (
    <SectionCard title="Simulation de Dilution" id="valuation-dilution">
      <div className="space-y-6">
        {/* Montant total à lever (affiché, non modifiable ici) */}
        <div className="p-4 bg-muted/30 rounded-lg border">
          <div className="flex items-center justify-between">
            <div>
              <Label className="font-medium">Montant Total à Lever</Label>
              <p className="text-xs text-muted-foreground">
                Défini dans l'onglet Besoin de Financement
              </p>
            </div>
            <div className="text-2xl font-bold font-mono-numbers text-primary">
              {formatCurrency(config.totalRaise, true)}
            </div>
          </div>
        </div>

        {/* Valorisation via multiple EBITDA */}
        <div className="p-4 bg-muted/30 rounded-lg space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <Label className="font-medium">Valorisation Pre-Money (via multiple EBITDA)</Label>
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>EBITDA de référence</span>
                <span className="font-mono-numbers">{formatCurrency(config.referenceEBITDA, true)}</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Basé sur les données historiques ou projetées
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Multiple EBITDA: {config.ebitdaMultiple.toFixed(1)}x</span>
              </div>
              <Slider
                value={[config.ebitdaMultiple]}
                onValueChange={([v]) => onConfigChange({ ...config, ebitdaMultiple: v })}
                min={2}
                max={20}
                step={0.5}
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>2x</span>
                <span>20x</span>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 pt-4 border-t">
            <div>
              <div className="text-xs text-muted-foreground">Pre-Money Valuation</div>
              <div className="text-xl font-bold font-mono-numbers">
                {formatCurrency(preMoneyValuation, true)}
              </div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Post-Money Valuation</div>
              <div className="text-xl font-bold font-mono-numbers">
                {formatCurrency(postMoneyValuation, true)}
              </div>
            </div>
          </div>
        </div>

        {/* Répartition Equity / OC */}
        <div className="p-4 bg-muted/30 rounded-lg space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="font-medium">Répartition du Financement</Label>
              <p className="text-xs text-muted-foreground">
                Ajuster la part en Equity vs Obligations Convertibles
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Label className="text-xs">Activer OC</Label>
              <Switch
                checked={config.enableConvertibleBonds}
                onCheckedChange={(v) => onConfigChange({ 
                  ...config, 
                  enableConvertibleBonds: v,
                  ocRatio: v ? 0.3 : 0 
                })}
              />
            </div>
          </div>

          {config.enableConvertibleBonds && (
            <>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Equity: {formatPercent(1 - config.ocRatio)}</span>
                  <span>OC: {formatPercent(config.ocRatio)}</span>
                </div>
                <Slider
                  value={[config.ocRatio * 100]}
                  onValueChange={([v]) => onConfigChange({ ...config, ocRatio: v / 100 })}
                  min={0}
                  max={80}
                  step={5}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-background rounded border">
                  <div className="text-xs text-muted-foreground">Montant Equity</div>
                  <div className="text-lg font-bold font-mono-numbers text-amber-600 dark:text-amber-400">
                    {formatCurrency(equityAmount, true)}
                  </div>
                </div>
                <div className="p-3 bg-background rounded border">
                  <div className="text-xs text-muted-foreground">Montant OC</div>
                  <div className="text-lg font-bold font-mono-numbers text-green-600 dark:text-green-400">
                    {formatCurrency(ocAmount, true)}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Paramètres OC */}
        {config.enableConvertibleBonds && (
          <div className="p-4 bg-muted/30 rounded-lg space-y-4">
            <div className="flex items-center gap-2">
              <Info className="h-4 w-4" />
              <Label className="font-medium">Paramètres Obligations Convertibles</Label>
            </div>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm">Décote conversion: {formatPercent(config.ocDiscount)}</Label>
                <Slider
                  value={[config.ocDiscount * 100]}
                  onValueChange={([v]) => onConfigChange({ ...config, ocDiscount: v / 100 })}
                  min={10}
                  max={30}
                  step={1}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm">Taux d'intérêt annuel: {formatPercent(config.ocInterestRate)}</Label>
                <Slider
                  value={[config.ocInterestRate * 100]}
                  onValueChange={([v]) => onConfigChange({ ...config, ocInterestRate: v / 100 })}
                  min={0}
                  max={10}
                  step={0.5}
                />
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm">Cap de valorisation</Label>
                <div className="flex items-center gap-2">
                  <Slider
                    value={[config.ocCap / 1000000]}
                    onValueChange={([v]) => onConfigChange({ ...config, ocCap: v * 1000000 })}
                    min={0.5}
                    max={20}
                    step={0.5}
                  />
                  <span className="w-16 text-right font-mono-numbers text-sm">{formatCurrency(config.ocCap, true)}</span>
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-sm">Maturité: {config.ocMaturityYears} ans</Label>
                <Slider
                  value={[config.ocMaturityYears]}
                  onValueChange={([v]) => onConfigChange({ ...config, ocMaturityYears: v })}
                  min={1}
                  max={5}
                  step={1}
                />
              </div>
            </div>
            
            <div className="p-3 bg-background rounded border">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-xs text-muted-foreground">Prix de conversion estimé</div>
                  <div className="font-mono-numbers">{formatCurrency(ocConversionPrice, true)}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Dilution estimée OC</div>
                  <div className="font-mono-numbers">{formatPercent(ocDilution)}</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* BSPCE */}
        <div className="p-4 bg-muted/30 rounded-lg space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="font-medium">Réserve BSPCE</Label>
              <p className="text-xs text-muted-foreground">Pool d'options pour les salariés</p>
            </div>
            <Switch
              checked={config.enableBSPCE}
              onCheckedChange={(v) => onConfigChange({ ...config, enableBSPCE: v })}
            />
          </div>

          {config.enableBSPCE && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Taille du pool BSPCE</span>
                <span className="font-mono-numbers">{formatPercent(config.bspcePool)}</span>
              </div>
              <Slider
                value={[config.bspcePool * 100]}
                onValueChange={([v]) => onConfigChange({ ...config, bspcePool: v / 100 })}
                min={5}
                max={20}
                step={0.5}
              />
              <p className="text-xs text-muted-foreground">
                Standard: 10-15% pour les startups early-stage
              </p>
            </div>
          )}
        </div>

        {/* Résumé Cap Table */}
        <div className="pt-6 border-t">
          <h4 className="font-semibold mb-4 flex items-center gap-2">
            <Users className="h-5 w-5" />
            Répartition du Capital (Post-Round)
          </h4>
          
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Pie Chart */}
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={capTableData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={90}
                    paddingAngle={2}
                    dataKey="value"
                    label={({ name, value }) => `${name}: ${value.toFixed(1)}%`}
                  >
                    {capTableData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => `${value.toFixed(1)}%`} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Métriques */}
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-muted/30 rounded-lg text-center">
                  <div className="text-xs text-muted-foreground mb-1">Pre-Money</div>
                  <div className="text-lg font-bold font-mono-numbers">
                    {formatCurrency(preMoneyValuation, true)}
                  </div>
                </div>
              <div className="p-3 bg-muted/30 rounded-lg text-center">
                  <div className="text-xs text-muted-foreground mb-1">Dilution Totale</div>
                  <div className={cn(
                    "text-lg font-bold font-mono-numbers",
                    totalDilution > 0.30 ? "text-destructive" : totalDilution > 0.25 ? "text-amber-600 dark:text-amber-400" : "text-green-600 dark:text-green-400"
                  )}>
                    {formatPercent(totalDilution)}
                  </div>
                </div>
              </div>

              <Card className={cn(
                "p-4",
                foundersRemaining < 0.50 ? "border-destructive bg-destructive/5" : ""
              )}>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Part fondateurs restante</span>
                  <span className={cn(
                    "text-2xl font-bold font-mono-numbers",
                    foundersRemaining < 0.50 ? "text-destructive" : ""
                  )}>
                    {formatPercent(foundersRemaining)}
                  </span>
                </div>
                {foundersRemaining < 0.50 && (
                  <p className="text-xs text-destructive mt-2">
                    ⚠️ Attention: les fondateurs passent sous les 50%, perte de contrôle majoritaire
                  </p>
                )}
              </Card>

              <div className="space-y-2 text-sm">
                {equityAmount > 0 && (
                  <div className="flex justify-between p-2 bg-muted/30 rounded">
                    <span>Equity</span>
                    <span className="font-mono-numbers">{formatPercent(equityDilution)}</span>
                  </div>
                )}
                {config.enableConvertibleBonds && ocAmount > 0 && (
                  <div className="flex justify-between p-2 bg-muted/30 rounded">
                    <span>OC (estimé)</span>
                    <span className="font-mono-numbers">{formatPercent(ocDilution)}</span>
                  </div>
                )}
                {config.enableBSPCE && (
                  <div className="flex justify-between p-2 bg-muted/30 rounded">
                    <span>BSPCE Pool</span>
                    <span className="font-mono-numbers">{formatPercent(bspceDilution)}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </SectionCard>
  );
}

export const defaultDilutionConfig: DilutionConfig = {
  totalRaise: 1500000,
  ocRatio: 0,
  enableConvertibleBonds: false,
  ocDiscount: 0.20,
  ocCap: 8000000,
  ocInterestRate: 0.05,
  ocMaturityYears: 2,
  enableBSPCE: true,
  bspcePool: 0.10,
  ebitdaMultiple: 6,
  referenceEBITDA: 500000,
};

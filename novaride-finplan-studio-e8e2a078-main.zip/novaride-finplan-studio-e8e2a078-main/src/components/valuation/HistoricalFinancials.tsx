import { SectionCard } from '@/components/ui/KPICard';
import { Badge } from '@/components/ui/badge';
import { formatCurrency, formatPercent, historicalData } from '@/data/financialConfig';
import { cn } from '@/lib/utils';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  ComposedChart,
  Line,
} from 'recharts';

interface HistoricalFinancialsProps {
  className?: string;
}

export function HistoricalFinancials({ className }: HistoricalFinancialsProps) {
  // Calcul des indicateurs historiques
  const historicalMetrics = historicalData.map(data => {
    const grossProfit = data.revenue * data.grossMargin;
    const ebitda = grossProfit - data.payroll - data.externalCosts;
    const ebit = ebitda - data.depreciation;
    const ebitdaMargin = data.revenue > 0 ? ebitda / data.revenue : 0;
    const ebitMargin = data.revenue > 0 ? ebit / data.revenue : 0;
    
    return {
      year: data.year,
      revenue: data.revenue,
      grossProfit,
      grossMargin: data.grossMargin,
      payroll: data.payroll,
      externalCosts: data.externalCosts,
      depreciation: data.depreciation,
      ebitda,
      ebitdaMargin,
      ebit,
      ebitMargin,
      cash: data.cash,
      inventory: data.inventory,
    };
  });

  // Données pour le graphique
  const chartData = historicalMetrics.map(m => ({
    year: m.year,
    revenue: m.revenue / 1000,
    ebitda: m.ebitda / 1000,
    ebit: m.ebit / 1000,
    margin: m.ebitdaMargin * 100,
  }));

  // Calcul CAGR
  const firstYear = historicalMetrics[0];
  const lastYear = historicalMetrics[historicalMetrics.length - 1];
  const years = lastYear.year - firstYear.year;
  const revenueCagr = years > 0 ? Math.pow(lastYear.revenue / firstYear.revenue, 1 / years) - 1 : 0;

  return (
    <SectionCard title="Historique Financier" className={className}>
      <div className="flex items-center gap-2 mb-4">
        <Badge variant="outline">Données réelles</Badge>
        <Badge variant="secondary">
          TCAC CA: {formatPercent(revenueCagr)}
        </Badge>
      </div>

      {/* Graphique */}
      <div className="h-64 mb-6">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="year" />
            <YAxis yAxisId="left" tickFormatter={(v) => `${v}k€`} />
            <YAxis yAxisId="right" orientation="right" domain={[-20, 30]} tickFormatter={(v) => `${v}%`} />
            <Tooltip 
              formatter={(value: number, name: string) => 
                name === 'margin' ? `${value.toFixed(1)}%` : `${value.toFixed(0)}k€`
              } 
            />
            <Legend />
            <Bar yAxisId="left" dataKey="revenue" name="CA" fill="hsl(0, 85%, 50%)" />
            <Bar yAxisId="left" dataKey="ebitda" name="EBITDA" fill="hsl(38, 92%, 50%)" />
            <Bar yAxisId="left" dataKey="ebit" name="EBIT" fill="hsl(210, 70%, 50%)" />
            <Line yAxisId="right" type="monotone" dataKey="margin" name="Marge EBITDA" stroke="hsl(150, 60%, 40%)" strokeWidth={2} dot />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Tableau détaillé */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-muted/30">
              <th className="text-left py-2 px-3 font-medium">Indicateur</th>
              {historicalMetrics.map(m => (
                <th key={m.year} className="text-right py-2 px-3 font-mono-numbers">{m.year}</th>
              ))}
              <th className="text-right py-2 px-3 text-muted-foreground">Évol.</th>
            </tr>
          </thead>
          <tbody>
            {/* CA */}
            <tr className="border-b">
              <td className="py-2 px-3 font-medium">Chiffre d'Affaires</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3 font-mono-numbers">
                  {formatCurrency(m.revenue, true)}
                </td>
              ))}
              <td className="text-right py-2 px-3 text-green-600 font-mono-numbers">
                +{formatPercent(revenueCagr)}
              </td>
            </tr>
            {/* Marge Brute */}
            <tr className="border-b">
              <td className="py-2 px-3">Marge Brute</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3 font-mono-numbers">
                  {formatCurrency(m.grossProfit, true)}
                  <span className="text-xs text-muted-foreground ml-1">({formatPercent(m.grossMargin)})</span>
                </td>
              ))}
              <td className="text-right py-2 px-3" />
            </tr>
            {/* Masse Salariale */}
            <tr className="border-b bg-muted/20">
              <td className="py-2 px-3 text-muted-foreground">Masse Salariale</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3 font-mono-numbers text-muted-foreground">
                  {formatCurrency(m.payroll, true)}
                </td>
              ))}
              <td className="text-right py-2 px-3" />
            </tr>
            {/* Charges Externes */}
            <tr className="border-b bg-muted/20">
              <td className="py-2 px-3 text-muted-foreground">Charges Externes</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3 font-mono-numbers text-muted-foreground">
                  {formatCurrency(m.externalCosts, true)}
                </td>
              ))}
              <td className="text-right py-2 px-3" />
            </tr>
            {/* EBITDA */}
            <tr className="border-b font-medium">
              <td className="py-2 px-3">EBITDA</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className={cn(
                  "text-right py-2 px-3 font-mono-numbers",
                  m.ebitda < 0 ? "text-destructive" : "text-green-600"
                )}>
                  {formatCurrency(m.ebitda, true)}
                  <span className="text-xs ml-1">({formatPercent(m.ebitdaMargin)})</span>
                </td>
              ))}
              <td className="text-right py-2 px-3" />
            </tr>
            {/* Amortissements */}
            <tr className="border-b bg-muted/20">
              <td className="py-2 px-3 text-muted-foreground">Amortissements</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3 font-mono-numbers text-muted-foreground">
                  {formatCurrency(m.depreciation, true)}
                </td>
              ))}
              <td className="text-right py-2 px-3" />
            </tr>
            {/* EBIT */}
            <tr className="border-b font-medium">
              <td className="py-2 px-3">EBIT (Résultat d'Exploitation)</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className={cn(
                  "text-right py-2 px-3 font-mono-numbers",
                  m.ebit < 0 ? "text-destructive" : ""
                )}>
                  {formatCurrency(m.ebit, true)}
                </td>
              ))}
              <td className="text-right py-2 px-3" />
            </tr>
            {/* Trésorerie */}
            <tr className="border-b">
              <td className="py-2 px-3">Trésorerie</td>
              {historicalMetrics.map(m => (
                <td key={m.year} className="text-right py-2 px-3 font-mono-numbers">
                  {formatCurrency(m.cash, true)}
                </td>
              ))}
              <td className="text-right py-2 px-3" />
            </tr>
          </tbody>
        </table>
      </div>
    </SectionCard>
  );
}

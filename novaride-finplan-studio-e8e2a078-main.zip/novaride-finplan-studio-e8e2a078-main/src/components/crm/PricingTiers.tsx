import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Edit, Save, X, Percent, Award } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { PricingTier } from '@/hooks/useCRMData';
import { cn } from '@/lib/utils';

interface PricingTiersProps {
  tiers: PricingTier[];
  onRefresh: () => void;
}

const tierIcons: Record<string, React.ReactNode> = {
  bronze: <Award className="h-8 w-8 text-orange-600" />,
  silver: <Award className="h-8 w-8 text-slate-400" />,
  gold: <Award className="h-8 w-8 text-yellow-500" />,
};

const tierColors: Record<string, string> = {
  bronze: 'border-orange-300 bg-orange-50 dark:bg-orange-950/30',
  silver: 'border-slate-300 bg-slate-50 dark:bg-slate-950/30',
  gold: 'border-yellow-300 bg-yellow-50 dark:bg-yellow-950/30',
};

const tierLabels: Record<string, string> = {
  bronze: 'Bronze',
  silver: 'Silver',
  gold: 'Gold',
};

export function PricingTiers({ tiers, onRefresh }: PricingTiersProps) {
  const { toast } = useToast();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  const [editDescription, setEditDescription] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);

  const startEdit = (tier: PricingTier) => {
    setEditingId(tier.id);
    setEditValue(tier.discount_percentage.toString());
    setEditDescription(tier.description || '');
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditValue('');
    setEditDescription('');
  };

  const saveEdit = async (tierId: string) => {
    const discount = parseFloat(editValue);
    if (isNaN(discount) || discount < 0 || discount > 100) {
      toast({
        title: 'Erreur',
        description: 'La remise doit être entre 0 et 100%',
        variant: 'destructive',
      });
      return;
    }

    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('pricing_tier_discounts')
        .update({
          discount_percentage: discount,
          description: editDescription.trim() || null,
        })
        .eq('id', tierId);

      if (error) throw error;
      
      toast({ title: 'Niveau tarifaire mis à jour' });
      cancelEdit();
      onRefresh();
    } catch (error: any) {
      console.error('Error updating tier:', error);
      toast({
        title: 'Erreur',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Percent className="h-5 w-5" />
          Grille Tarifaire
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-3">
          {tiers.map((tier) => (
            <div
              key={tier.id}
              className={cn(
                'p-6 rounded-lg border-2 transition-all',
                tierColors[tier.tier]
              )}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  {tierIcons[tier.tier]}
                  <h3 className="text-xl font-bold">{tierLabels[tier.tier]}</h3>
                </div>
                {editingId === tier.id ? (
                  <div className="flex gap-1">
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      onClick={() => saveEdit(tier.id)}
                      disabled={isSaving}
                    >
                      <Save className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      onClick={cancelEdit}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    onClick={() => startEdit(tier)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                )}
              </div>

              {editingId === tier.id ? (
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium">Remise (%)</label>
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      step="0.5"
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Description</label>
                    <Input
                      value={editDescription}
                      onChange={(e) => setEditDescription(e.target.value)}
                      className="mt-1"
                      placeholder="Description du niveau"
                    />
                  </div>
                </div>
              ) : (
                <>
                  <div className="text-center mb-4">
                    <span className="text-4xl font-bold">{tier.discount_percentage}%</span>
                    <span className="text-muted-foreground ml-1">de remise</span>
                  </div>
                  {tier.description && (
                    <p className="text-sm text-muted-foreground text-center">
                      {tier.description}
                    </p>
                  )}
                </>
              )}
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-muted/50 rounded-lg">
          <h4 className="font-medium mb-2">Comment ça marche</h4>
          <p className="text-sm text-muted-foreground">
            Chaque client se voit attribuer un niveau tarifaire (Bronze, Silver, Gold) qui détermine 
            le pourcentage de remise appliqué sur les prix catalogue. Vous pouvez modifier le pourcentage 
            de remise pour chaque niveau selon votre politique commerciale.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Calendar, MapPin, Clock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { CustomerAppointment } from '@/hooks/useCRMData';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface AppointmentListProps {
  customerId: string;
  onRefresh: () => void;
}

export function AppointmentList({ customerId, onRefresh }: AppointmentListProps) {
  const { toast } = useToast();
  const [appointments, setAppointments] = useState<CustomerAppointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    appointment_date: '',
    duration_minutes: '60',
    location: '',
  });

  const fetchAppointments = async () => {
    try {
      const { data, error } = await supabase
        .from('customer_appointments')
        .select('*')
        .eq('customer_id', customerId)
        .order('appointment_date', { ascending: true });

      if (error) throw error;
      setAppointments(data as CustomerAppointment[]);
    } catch (error) {
      console.error('Error fetching appointments:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [customerId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.appointment_date) {
      toast({
        title: 'Erreur',
        description: 'Le titre et la date sont requis',
        variant: 'destructive',
      });
      return;
    }

    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('customer_appointments')
        .insert({
          customer_id: customerId,
          title: formData.title.trim(),
          description: formData.description.trim() || null,
          appointment_date: new Date(formData.appointment_date).toISOString(),
          duration_minutes: parseInt(formData.duration_minutes) || 60,
          location: formData.location.trim() || null,
        });

      if (error) throw error;
      
      toast({ title: 'RDV ajouté' });
      setShowAddDialog(false);
      setFormData({ title: '', description: '', appointment_date: '', duration_minutes: '60', location: '' });
      fetchAppointments();
      onRefresh();
    } catch (error: any) {
      console.error('Error adding appointment:', error);
      toast({
        title: 'Erreur',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const toggleComplete = async (appointment: CustomerAppointment) => {
    try {
      const { error } = await supabase
        .from('customer_appointments')
        .update({ is_completed: !appointment.is_completed })
        .eq('id', appointment.id);

      if (error) throw error;
      fetchAppointments();
      onRefresh();
    } catch (error) {
      console.error('Error updating appointment:', error);
    }
  };

  if (isLoading) {
    return <div className="text-center py-4 text-muted-foreground">Chargement...</div>;
  }

  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <span className="text-sm text-muted-foreground">{appointments.length} RDV</span>
        <Button size="sm" onClick={() => setShowAddDialog(true)}>
          <Plus className="h-4 w-4 mr-1" />
          Ajouter
        </Button>
      </div>

      {appointments.length === 0 ? (
        <p className="text-center text-muted-foreground text-sm py-6">
          Aucun rendez-vous planifié
        </p>
      ) : (
        <div className="space-y-2 max-h-[300px] overflow-y-auto">
          {appointments.map((appointment) => {
            const isPast = new Date(appointment.appointment_date) < new Date();
            return (
              <div
                key={appointment.id}
                className={`p-3 rounded-lg border ${
                  appointment.is_completed 
                    ? 'bg-muted/20 border-muted' 
                    : isPast 
                      ? 'bg-destructive/5 border-destructive/30'
                      : 'bg-muted/30'
                }`}
              >
                <div className="flex items-start gap-3">
                  <Checkbox
                    checked={appointment.is_completed}
                    onCheckedChange={() => toggleComplete(appointment)}
                    className="mt-1"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className={`font-medium text-sm ${appointment.is_completed ? 'line-through text-muted-foreground' : ''}`}>
                        {appointment.title}
                      </span>
                      {!appointment.is_completed && isPast && (
                        <Badge variant="destructive" className="text-xs">En retard</Badge>
                      )}
                      {appointment.is_completed && (
                        <Badge variant="outline" className="text-xs bg-green-100 text-green-800">Terminé</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {format(new Date(appointment.appointment_date), 'dd MMM yyyy HH:mm', { locale: fr })}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {appointment.duration_minutes} min
                      </span>
                      {appointment.location && (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {appointment.location}
                        </span>
                      )}
                    </div>
                    {appointment.description && (
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                        {appointment.description}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nouveau rendez-vous</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>Titre *</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>
            
            <div>
              <Label>Date et heure *</Label>
              <Input
                type="datetime-local"
                value={formData.appointment_date}
                onChange={(e) => setFormData({ ...formData, appointment_date: e.target.value })}
                required
              />
            </div>
            
            <div>
              <Label>Durée (minutes)</Label>
              <Input
                type="number"
                value={formData.duration_minutes}
                onChange={(e) => setFormData({ ...formData, duration_minutes: e.target.value })}
              />
            </div>
            
            <div>
              <Label>Lieu</Label>
              <Input
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              />
            </div>
            
            <div>
              <Label>Description</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
              />
            </div>
            
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                Annuler
              </Button>
              <Button type="submit" disabled={isSaving}>
                {isSaving ? 'Enregistrement...' : 'Ajouter'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Calendar, Clock, MapPin, Building2 } from 'lucide-react';
import { format, isToday, isTomorrow, isThisWeek, isPast } from 'date-fns';
import { fr } from 'date-fns/locale';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { CustomerAppointment, Customer } from '@/hooks/useCRMData';
import { cn } from '@/lib/utils';

interface UpcomingAppointmentsProps {
  appointments: CustomerAppointment[];
  customers: Customer[];
  onRefresh: () => void;
}

export function UpcomingAppointments({ appointments, customers, onRefresh }: UpcomingAppointmentsProps) {
  const { toast } = useToast();

  const getCustomerName = (customerId: string) => {
    const customer = customers.find(c => c.id === customerId);
    return customer?.company_name || 'Client inconnu';
  };

  const toggleComplete = async (appointment: CustomerAppointment) => {
    try {
      const { error } = await supabase
        .from('customer_appointments')
        .update({ is_completed: !appointment.is_completed })
        .eq('id', appointment.id);

      if (error) throw error;
      onRefresh();
    } catch (error: any) {
      toast({
        title: 'Erreur',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  const getDateLabel = (date: Date) => {
    if (isToday(date)) return 'Aujourd\'hui';
    if (isTomorrow(date)) return 'Demain';
    if (isThisWeek(date)) return format(date, 'EEEE', { locale: fr });
    return format(date, 'dd MMMM', { locale: fr });
  };

  // Group appointments by date
  const groupedAppointments = appointments
    .filter(a => !a.is_completed)
    .reduce((groups, appointment) => {
      const date = format(new Date(appointment.appointment_date), 'yyyy-MM-dd');
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(appointment);
      return groups;
    }, {} as Record<string, CustomerAppointment[]>);

  const sortedDates = Object.keys(groupedAppointments).sort();
  const completedAppointments = appointments.filter(a => a.is_completed).slice(0, 5);

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Rendez-vous à venir
            </CardTitle>
          </CardHeader>
          <CardContent>
            {sortedDates.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                Aucun rendez-vous planifié
              </p>
            ) : (
              <div className="space-y-6">
                {sortedDates.map((dateKey) => {
                  const date = new Date(dateKey);
                  const dayAppointments = groupedAppointments[dateKey];
                  const isOverdue = isPast(date) && !isToday(date);
                  
                  return (
                    <div key={dateKey}>
                      <h3 className={cn(
                        "font-semibold mb-3 flex items-center gap-2",
                        isOverdue && "text-destructive"
                      )}>
                        {getDateLabel(date)}
                        {isOverdue && <Badge variant="destructive">En retard</Badge>}
                      </h3>
                      <div className="space-y-2">
                        {dayAppointments.map((appointment) => (
                          <div
                            key={appointment.id}
                            className={cn(
                              "p-4 rounded-lg border bg-card",
                              isOverdue && "border-destructive/50 bg-destructive/5"
                            )}
                          >
                            <div className="flex items-start gap-3">
                              <Checkbox
                                checked={appointment.is_completed}
                                onCheckedChange={() => toggleComplete(appointment)}
                                className="mt-1"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="font-medium">{appointment.title}</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                                  <Building2 className="h-4 w-4" />
                                  {getCustomerName(appointment.customer_id)}
                                </div>
                                <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                                  <span className="flex items-center gap-1">
                                    <Clock className="h-4 w-4" />
                                    {format(new Date(appointment.appointment_date), 'HH:mm')}
                                    {appointment.duration_minutes && ` (${appointment.duration_minutes} min)`}
                                  </span>
                                  {appointment.location && (
                                    <span className="flex items-center gap-1">
                                      <MapPin className="h-4 w-4" />
                                      {appointment.location}
                                    </span>
                                  )}
                                </div>
                                {appointment.description && (
                                  <p className="text-sm text-muted-foreground mt-2">
                                    {appointment.description}
                                  </p>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">RDV terminés récents</CardTitle>
          </CardHeader>
          <CardContent>
            {completedAppointments.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                Aucun RDV terminé
              </p>
            ) : (
              <div className="space-y-3">
                {completedAppointments.map((appointment) => (
                  <div
                    key={appointment.id}
                    className="p-3 rounded-lg bg-muted/30 border"
                  >
                    <div className="flex items-start gap-2">
                      <Checkbox
                        checked={appointment.is_completed}
                        onCheckedChange={() => toggleComplete(appointment)}
                        className="mt-0.5"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium line-through text-muted-foreground">
                          {appointment.title}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {getCustomerName(appointment.customer_id)}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(appointment.appointment_date), 'dd MMM yyyy', { locale: fr })}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

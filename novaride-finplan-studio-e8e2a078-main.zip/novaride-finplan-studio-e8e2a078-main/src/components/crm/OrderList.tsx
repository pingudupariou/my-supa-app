import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Package } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { CustomerOrder } from '@/hooks/useCRMData';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface OrderListProps {
  customerId: string;
  orders: CustomerOrder[];
  onRefresh: () => void;
}

const statusColors: Record<string, string> = {
  draft: 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300',
  confirmed: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
  in_progress: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
  delivered: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  cancelled: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
};

const statusLabels: Record<string, string> = {
  draft: 'Brouillon',
  confirmed: 'Confirmée',
  in_progress: 'En cours',
  delivered: 'Livrée',
  cancelled: 'Annulée',
};

export function OrderList({ customerId, orders, onRefresh }: OrderListProps) {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({
    order_reference: '',
    order_date: new Date().toISOString().split('T')[0],
    expected_delivery_date: '',
    total_amount: '',
    status: 'draft',
    product_category: '',
    notes: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.order_reference.trim()) {
      toast({
        title: 'Erreur',
        description: 'La référence de commande est requise',
        variant: 'destructive',
      });
      return;
    }

    setIsSaving(true);
    try {
      const orderStatus = formData.status as 'draft' | 'confirmed' | 'in_progress' | 'delivered' | 'cancelled';
      
      const insertData: {
        customer_id: string;
        order_reference: string;
        order_date: string;
        expected_delivery_date: string | null;
        total_amount: number;
        status: 'draft' | 'confirmed' | 'in_progress' | 'delivered' | 'cancelled';
        product_category: string | null;
        notes: string | null;
      } = {
        customer_id: customerId,
        order_reference: formData.order_reference.trim(),
        order_date: formData.order_date,
        expected_delivery_date: formData.expected_delivery_date || null,
        total_amount: parseFloat(formData.total_amount) || 0,
        status: orderStatus,
        product_category: formData.product_category.trim() || null,
        notes: formData.notes.trim() || null,
      };
      
      const { error } = await supabase
        .from('customer_orders')
        .insert(insertData);

      if (error) throw error;
      
      toast({ title: 'Commande ajoutée' });
      setShowAddDialog(false);
      setFormData({
        order_reference: '',
        order_date: new Date().toISOString().split('T')[0],
        expected_delivery_date: '',
        total_amount: '',
        status: 'draft',
        product_category: '',
        notes: '',
      });
      onRefresh();
    } catch (error: any) {
      console.error('Error adding order:', error);
      toast({
        title: 'Erreur',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      const statusValue = newStatus as 'draft' | 'confirmed' | 'in_progress' | 'delivered' | 'cancelled';
      
      const { error } = await supabase
        .from('customer_orders')
        .update({ status: statusValue })
        .eq('id', orderId);

      if (error) throw error;
      toast({ title: 'Statut mis à jour' });
      onRefresh();
    } catch (error: any) {
      toast({
        title: 'Erreur',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <span className="text-sm text-muted-foreground">{orders.length} commande(s)</span>
        <Button size="sm" onClick={() => setShowAddDialog(true)}>
          <Plus className="h-4 w-4 mr-1" />
          Ajouter
        </Button>
      </div>

      {orders.length === 0 ? (
        <p className="text-center text-muted-foreground text-sm py-6">
          Aucune commande
        </p>
      ) : (
        <div className="space-y-2 max-h-[300px] overflow-y-auto">
          {orders.map((order) => (
            <div
              key={order.id}
              className="p-3 bg-muted/30 rounded-lg border"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <Package className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium text-sm">{order.order_reference}</span>
                    <Badge variant="outline" className={statusColors[order.status]}>
                      {statusLabels[order.status]}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground space-y-0.5">
                    <p>Date: {format(new Date(order.order_date), 'dd MMM yyyy', { locale: fr })}</p>
                    {order.expected_delivery_date && (
                      <p>Livraison prévue: {format(new Date(order.expected_delivery_date), 'dd MMM yyyy', { locale: fr })}</p>
                    )}
                    {order.product_category && (
                      <p>Catégorie: {order.product_category}</p>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold">{order.total_amount.toLocaleString('fr-FR')} €</p>
                  <Select
                    value={order.status}
                    onValueChange={(value) => updateOrderStatus(order.id, value)}
                  >
                    <SelectTrigger className="h-7 text-xs w-28 mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Brouillon</SelectItem>
                      <SelectItem value="confirmed">Confirmée</SelectItem>
                      <SelectItem value="in_progress">En cours</SelectItem>
                      <SelectItem value="delivered">Livrée</SelectItem>
                      <SelectItem value="cancelled">Annulée</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nouvelle commande</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>Référence *</Label>
              <Input
                value={formData.order_reference}
                onChange={(e) => setFormData({ ...formData, order_reference: e.target.value })}
                placeholder="CMD-001"
                required
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Date de commande</Label>
                <Input
                  type="date"
                  value={formData.order_date}
                  onChange={(e) => setFormData({ ...formData, order_date: e.target.value })}
                />
              </div>
              
              <div>
                <Label>Livraison prévue</Label>
                <Input
                  type="date"
                  value={formData.expected_delivery_date}
                  onChange={(e) => setFormData({ ...formData, expected_delivery_date: e.target.value })}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Montant (€)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.total_amount}
                  onChange={(e) => setFormData({ ...formData, total_amount: e.target.value })}
                />
              </div>
              
              <div>
                <Label>Statut</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData({ ...formData, status: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Brouillon</SelectItem>
                    <SelectItem value="confirmed">Confirmée</SelectItem>
                    <SelectItem value="in_progress">En cours</SelectItem>
                    <SelectItem value="delivered">Livrée</SelectItem>
                    <SelectItem value="cancelled">Annulée</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <Label>Catégorie produit</Label>
              <Input
                value={formData.product_category}
                onChange={(e) => setFormData({ ...formData, product_category: e.target.value })}
                placeholder="Ex: CCD EVO, Transmission..."
              />
            </div>
            
            <div>
              <Label>Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={2}
              />
            </div>
            
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                Annuler
              </Button>
              <Button type="submit" disabled={isSaving}>
                {isSaving ? 'Enregistrement...' : 'Ajouter'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Phone, Mail, Users, FileText } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { CustomerInteraction } from '@/hooks/useCRMData';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface InteractionListProps {
  customerId: string;
  onRefresh: () => void;
}

const typeIcons: Record<string, React.ReactNode> = {
  call: <Phone className="h-4 w-4" />,
  email: <Mail className="h-4 w-4" />,
  meeting: <Users className="h-4 w-4" />,
  note: <FileText className="h-4 w-4" />,
};

const typeLabels: Record<string, string> = {
  call: 'Appel',
  email: 'Email',
  meeting: 'Réunion',
  note: 'Note',
};

export function InteractionList({ customerId, onRefresh }: InteractionListProps) {
  const { toast } = useToast();
  const [interactions, setInteractions] = useState<CustomerInteraction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({
    interaction_type: 'note',
    subject: '',
    content: '',
  });

  const fetchInteractions = async () => {
    try {
      const { data, error } = await supabase
        .from('customer_interactions')
        .select('*')
        .eq('customer_id', customerId)
        .order('interaction_date', { ascending: false });

      if (error) throw error;
      setInteractions(data as CustomerInteraction[]);
    } catch (error) {
      console.error('Error fetching interactions:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchInteractions();
  }, [customerId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.subject.trim()) {
      toast({
        title: 'Erreur',
        description: 'Le sujet est requis',
        variant: 'destructive',
      });
      return;
    }

    setIsSaving(true);
    try {
      const interactionType = formData.interaction_type as 'call' | 'email' | 'meeting' | 'note';
      
      const insertData: {
        customer_id: string;
        interaction_type: 'call' | 'email' | 'meeting' | 'note';
        subject: string;
        content: string | null;
        interaction_date: string;
      } = {
        customer_id: customerId,
        interaction_type: interactionType,
        subject: formData.subject.trim(),
        content: formData.content.trim() || null,
        interaction_date: new Date().toISOString(),
      };
      
      const { error } = await supabase
        .from('customer_interactions')
        .insert(insertData);

      if (error) throw error;
      
      toast({ title: 'Échange ajouté' });
      setShowAddDialog(false);
      setFormData({ interaction_type: 'note', subject: '', content: '' });
      fetchInteractions();
      onRefresh();
    } catch (error: any) {
      console.error('Error adding interaction:', error);
      toast({
        title: 'Erreur',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return <div className="text-center py-4 text-muted-foreground">Chargement...</div>;
  }

  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <span className="text-sm text-muted-foreground">{interactions.length} échange(s)</span>
        <Button size="sm" onClick={() => setShowAddDialog(true)}>
          <Plus className="h-4 w-4 mr-1" />
          Ajouter
        </Button>
      </div>

      {interactions.length === 0 ? (
        <p className="text-center text-muted-foreground text-sm py-6">
          Aucun échange enregistré
        </p>
      ) : (
        <div className="space-y-2 max-h-[300px] overflow-y-auto">
          {interactions.map((interaction) => (
            <div
              key={interaction.id}
              className="p-3 bg-muted/30 rounded-lg border"
            >
              <div className="flex items-start gap-3">
                <div className="p-2 bg-background rounded">
                  {typeIcons[interaction.interaction_type]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className="text-xs">
                      {typeLabels[interaction.interaction_type]}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {format(new Date(interaction.interaction_date), 'dd MMM yyyy HH:mm', { locale: fr })}
                    </span>
                  </div>
                  <p className="font-medium text-sm">{interaction.subject}</p>
                  {interaction.content && (
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                      {interaction.content}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Nouvel échange</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>Type</Label>
              <Select
                value={formData.interaction_type}
                onValueChange={(value) => setFormData({ ...formData, interaction_type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="call">Appel</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="meeting">Réunion</SelectItem>
                  <SelectItem value="note">Note</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Sujet *</Label>
              <Input
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                required
              />
            </div>
            
            <div>
              <Label>Contenu</Label>
              <Textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                rows={4}
              />
            </div>
            
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                Annuler
              </Button>
              <Button type="submit" disabled={isSaving}>
                {isSaving ? 'Enregistrement...' : 'Ajouter'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

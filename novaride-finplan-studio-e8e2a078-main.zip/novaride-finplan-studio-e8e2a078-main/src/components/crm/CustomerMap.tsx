import { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Customer } from '@/hooks/useCRMData';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

// Fix for default marker icons in Leaflet with Vite
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

interface CustomerMapProps {
  customers: Customer[];
  selectedId: string | null;
  onSelectCustomer: (id: string | null) => void;
}

// Custom marker icons by tier
const createCustomIcon = (tier: string, isSelected: boolean) => {
  const colors: Record<string, string> = {
    bronze: '#CD7F32',
    silver: '#C0C0C0',
    gold: '#FFD700',
  };
  
  const color = colors[tier] || '#3B82F6';
  const size = isSelected ? 40 : 30;
  
  return L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="
        width: ${size}px;
        height: ${size}px;
        background: ${color};
        border: 3px solid ${isSelected ? '#1e40af' : '#fff'};
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        box-shadow: 0 2px 6px rgba(0,0,0,0.3);
      "></div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size],
    popupAnchor: [0, -size],
  });
};

// Component to handle map view changes
function MapUpdater({ customers, selectedId }: { customers: Customer[]; selectedId: string | null }) {
  const map = useMap();
  
  useEffect(() => {
    const customersWithCoords = customers.filter(c => c.latitude && c.longitude);
    
    if (selectedId) {
      const selected = customers.find(c => c.id === selectedId);
      if (selected?.latitude && selected?.longitude) {
        map.setView([selected.latitude, selected.longitude], 12);
        return;
      }
    }
    
    if (customersWithCoords.length > 0) {
      const bounds = L.latLngBounds(
        customersWithCoords.map(c => [c.latitude!, c.longitude!] as [number, number])
      );
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [customers, selectedId, map]);
  
  return null;
}

const tierColors: Record<string, string> = {
  bronze: 'bg-orange-100 text-orange-800',
  silver: 'bg-slate-100 text-slate-800',
  gold: 'bg-yellow-100 text-yellow-800',
};

export function CustomerMap({ customers, selectedId, onSelectCustomer }: CustomerMapProps) {
  const customersWithCoords = customers.filter(c => c.latitude && c.longitude);
  
  if (customersWithCoords.length === 0) {
    return (
      <div className="h-[500px] flex items-center justify-center bg-muted/30 rounded-lg border">
        <div className="text-center text-muted-foreground">
          <p className="font-medium">Aucun client avec coordonnées</p>
          <p className="text-sm">Ajoutez latitude et longitude aux fiches clients pour les voir sur la carte</p>
        </div>
      </div>
    );
  }
  
  // Default center on France
  const defaultCenter: [number, number] = [46.603354, 1.888334];
  
  return (
    <div className="h-[500px] rounded-lg overflow-hidden border">
      <MapContainer
        center={defaultCenter}
        zoom={6}
        className="h-full w-full"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapUpdater customers={customers} selectedId={selectedId} />
        
        {customersWithCoords.map((customer) => (
          <Marker
            key={customer.id}
            position={[customer.latitude!, customer.longitude!]}
            icon={createCustomIcon(customer.pricing_tier, customer.id === selectedId)}
            eventHandlers={{
              click: () => onSelectCustomer(customer.id),
            }}
          >
            <Popup>
              <div className="min-w-[200px]">
                <h3 className="font-bold text-base mb-1">{customer.company_name}</h3>
                {customer.contact_name && (
                  <p className="text-sm text-gray-600">{customer.contact_name}</p>
                )}
                <div className="flex gap-1 my-2">
                  <Badge variant="outline" className={cn('text-xs', tierColors[customer.pricing_tier])}>
                    {customer.pricing_tier}
                  </Badge>
                </div>
                {customer.city && (
                  <p className="text-xs text-gray-500">
                    {[customer.address, customer.postal_code, customer.city].filter(Boolean).join(', ')}
                  </p>
                )}
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, Building2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Customer } from '@/hooks/useCRMData';
import { CustomerFormDialog } from './CustomerFormDialog';

interface CustomerListProps {
  customers: Customer[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onRefresh: () => void;
}

const statusColors: Record<string, string> = {
  prospect: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
  active: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  inactive: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300',
};

const tierColors: Record<string, string> = {
  bronze: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
  silver: 'bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-300',
  gold: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
};

export function CustomerList({ customers, selectedId, onSelect, onRefresh }: CustomerListProps) {
  const [search, setSearch] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);

  const filteredCustomers = customers.filter(c =>
    c.company_name.toLowerCase().includes(search.toLowerCase()) ||
    c.contact_name?.toLowerCase().includes(search.toLowerCase()) ||
    c.city?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <Card className="h-full">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Clients ({customers.length})</CardTitle>
            <Button size="sm" onClick={() => setShowAddDialog(true)}>
              <Plus className="h-4 w-4 mr-1" />
              Nouveau
            </Button>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Rechercher..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="max-h-[500px] overflow-y-auto">
            {filteredCustomers.length === 0 ? (
              <div className="p-6 text-center text-muted-foreground">
                <Building2 className="h-8 w-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Aucun client trouvé</p>
              </div>
            ) : (
              <ul className="divide-y divide-border">
                {filteredCustomers.map((customer) => (
                  <li
                    key={customer.id}
                    className={cn(
                      'px-4 py-3 cursor-pointer transition-colors hover:bg-muted/50',
                      selectedId === customer.id && 'bg-muted'
                    )}
                    onClick={() => onSelect(customer.id)}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <p className="font-medium truncate">{customer.company_name}</p>
                        {customer.contact_name && (
                          <p className="text-sm text-muted-foreground truncate">
                            {customer.contact_name}
                          </p>
                        )}
                        {customer.city && (
                          <p className="text-xs text-muted-foreground">
                            {customer.city}
                          </p>
                        )}
                      </div>
                      <div className="flex flex-col gap-1 items-end">
                        <Badge variant="outline" className={cn('text-xs', statusColors[customer.status])}>
                          {customer.status}
                        </Badge>
                        <Badge variant="outline" className={cn('text-xs', tierColors[customer.pricing_tier])}>
                          {customer.pricing_tier}
                        </Badge>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </CardContent>
      </Card>

      <CustomerFormDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        onSuccess={() => {
          setShowAddDialog(false);
          onRefresh();
        }}
      />
    </>
  );
}

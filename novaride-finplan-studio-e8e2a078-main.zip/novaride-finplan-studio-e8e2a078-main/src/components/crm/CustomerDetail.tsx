import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Building2, 
  Mail, 
  Phone, 
  MapPin, 
  Edit, 
  MessageSquare, 
  Calendar, 
  ShoppingCart,
  Plus
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Customer, CustomerOrder } from '@/hooks/useCRMData';
import { CustomerFormDialog } from './CustomerFormDialog';
import { InteractionList } from './InteractionList';
import { AppointmentList } from './AppointmentList';
import { OrderList } from './OrderList';

interface CustomerDetailProps {
  customer: Customer;
  orders: CustomerOrder[];
  onRefresh: () => void;
}

const statusColors: Record<string, string> = {
  prospect: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
  active: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  inactive: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300',
};

const tierColors: Record<string, string> = {
  bronze: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
  silver: 'bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-300',
  gold: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
};

export function CustomerDetail({ customer, orders, onRefresh }: CustomerDetailProps) {
  const [showEditDialog, setShowEditDialog] = useState(false);
  
  const totalRevenue = orders.reduce((sum, o) => sum + (o.total_amount || 0), 0);

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <CardTitle className="text-xl flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                {customer.company_name}
              </CardTitle>
              <div className="flex gap-2">
                <Badge variant="outline" className={cn(statusColors[customer.status])}>
                  {customer.status}
                </Badge>
                <Badge variant="outline" className={cn(tierColors[customer.pricing_tier])}>
                  {customer.pricing_tier}
                </Badge>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={() => setShowEditDialog(true)}>
              <Edit className="h-4 w-4 mr-1" />
              Modifier
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Contact info */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            {customer.contact_name && (
              <div className="flex items-center gap-2">
                <span className="font-medium">Contact:</span>
                <span>{customer.contact_name}</span>
              </div>
            )}
            {customer.email && (
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <a href={`mailto:${customer.email}`} className="text-primary hover:underline">
                  {customer.email}
                </a>
              </div>
            )}
            {customer.phone && (
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <a href={`tel:${customer.phone}`} className="text-primary hover:underline">
                  {customer.phone}
                </a>
              </div>
            )}
            {(customer.address || customer.city) && (
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <span>
                  {[customer.address, customer.postal_code, customer.city].filter(Boolean).join(', ')}
                </span>
              </div>
            )}
          </div>

          {/* Revenue summary */}
          <div className="bg-muted/50 rounded-lg p-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">CA Total</p>
                <p className="text-2xl font-bold">{totalRevenue.toLocaleString('fr-FR')} €</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Commandes</p>
                <p className="text-2xl font-bold">{orders.length}</p>
              </div>
            </div>
          </div>

          {/* Notes */}
          {customer.notes && (
            <div>
              <p className="text-sm font-medium mb-1">Notes</p>
              <p className="text-sm text-muted-foreground bg-muted/50 rounded p-3">
                {customer.notes}
              </p>
            </div>
          )}

          {/* Tabs for interactions, appointments, orders */}
          <Tabs defaultValue="interactions" className="mt-4">
            <TabsList className="grid grid-cols-3">
              <TabsTrigger value="interactions" className="gap-1">
                <MessageSquare className="h-4 w-4" />
                <span className="hidden sm:inline">Échanges</span>
              </TabsTrigger>
              <TabsTrigger value="appointments" className="gap-1">
                <Calendar className="h-4 w-4" />
                <span className="hidden sm:inline">RDV</span>
              </TabsTrigger>
              <TabsTrigger value="orders" className="gap-1">
                <ShoppingCart className="h-4 w-4" />
                <span className="hidden sm:inline">Commandes</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="interactions" className="mt-4">
              <InteractionList customerId={customer.id} onRefresh={onRefresh} />
            </TabsContent>
            
            <TabsContent value="appointments" className="mt-4">
              <AppointmentList customerId={customer.id} onRefresh={onRefresh} />
            </TabsContent>
            
            <TabsContent value="orders" className="mt-4">
              <OrderList customerId={customer.id} orders={orders} onRefresh={onRefresh} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <CustomerFormDialog
        open={showEditDialog}
        onOpenChange={setShowEditDialog}
        customer={customer}
        onSuccess={() => {
          setShowEditDialog(false);
          onRefresh();
        }}
      />
    </>
  );
}

// ============================================
// UserRolesManager - Admin interface for user role management
// ============================================

import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import { Loader2, Users, Search, UserCog, Mail, Calendar } from 'lucide-react';
import { AppRole } from '@/context/AuthContext';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

const ROLES: AppRole[] = ['admin', 'finance', 'board', 'investisseur', 'lecteur'];

const roleLabels: Record<AppRole, string> = {
  admin: 'Admin',
  finance: 'Finance',
  board: 'Board',
  investisseur: 'Investisseur',
  lecteur: 'Lecteur',
};

const roleColors: Record<AppRole, string> = {
  admin: 'bg-red-100 text-red-800 border-red-200',
  finance: 'bg-blue-100 text-blue-800 border-blue-200',
  board: 'bg-purple-100 text-purple-800 border-purple-200',
  investisseur: 'bg-amber-100 text-amber-800 border-amber-200',
  lecteur: 'bg-gray-100 text-gray-800 border-gray-200',
};

interface UserWithRole {
  user_id: string;
  email: string | null;
  display_name: string | null;
  role: AppRole;
  created_at: string;
}

export function UserRolesManager() {
  const [users, setUsers] = useState<UserWithRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [updatingUser, setUpdatingUser] = useState<string | null>(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      // Join profiles with user_roles
      const { data: rolesData, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role, created_at');

      if (rolesError) throw rolesError;

      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('user_id, email, display_name');

      if (profilesError) throw profilesError;

      // Merge data
      const userMap = new Map<string, UserWithRole>();
      
      rolesData?.forEach(r => {
        const profile = profilesData?.find(p => p.user_id === r.user_id);
        userMap.set(r.user_id, {
          user_id: r.user_id,
          email: profile?.email || null,
          display_name: profile?.display_name || null,
          role: r.role as AppRole,
          created_at: r.created_at,
        });
      });

      // Add profiles without roles (shouldn't happen but just in case)
      profilesData?.forEach(p => {
        if (!userMap.has(p.user_id)) {
          userMap.set(p.user_id, {
            user_id: p.user_id,
            email: p.email,
            display_name: p.display_name,
            role: 'lecteur',
            created_at: new Date().toISOString(),
          });
        }
      });

      setUsers(Array.from(userMap.values()));
    } catch (e) {
      console.error('Error fetching users:', e);
      toast({
        title: "Erreur",
        description: "Impossible de charger les utilisateurs.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateUserRole = async (userId: string, newRole: AppRole) => {
    setUpdatingUser(userId);

    try {
      // Check if user already has a role entry
      const { data: existing } = await supabase
        .from('user_roles')
        .select('id')
        .eq('user_id', userId)
        .maybeSingle();

      if (existing) {
        // Update existing role
        const { error } = await supabase
          .from('user_roles')
          .update({ role: newRole })
          .eq('user_id', userId);

        if (error) throw error;
      } else {
        // Insert new role
        const { error } = await supabase
          .from('user_roles')
          .insert({ user_id: userId, role: newRole });

        if (error) throw error;
      }

      // Update local state
      setUsers(prev => prev.map(u => 
        u.user_id === userId ? { ...u, role: newRole } : u
      ));

      const user = users.find(u => u.user_id === userId);
      toast({
        title: "Rôle mis à jour",
        description: `${user?.display_name || user?.email} est maintenant ${roleLabels[newRole]}`,
      });
    } catch (e) {
      console.error('Error updating role:', e);
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour le rôle.",
        variant: "destructive",
      });
    } finally {
      setUpdatingUser(null);
    }
  };

  const filteredUsers = users.filter(user => {
    const query = searchQuery.toLowerCase();
    return (
      user.email?.toLowerCase().includes(query) ||
      user.display_name?.toLowerCase().includes(query) ||
      roleLabels[user.role].toLowerCase().includes(query)
    );
  });

  const roleStats = ROLES.reduce((acc, role) => {
    acc[role] = users.filter(u => u.role === role).length;
    return acc;
  }, {} as Record<AppRole, number>);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {ROLES.map(role => (
          <Card key={role} className="p-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${roleColors[role]}`}>
                <UserCog className="h-4 w-4" />
              </div>
              <div>
                <p className="text-2xl font-bold">{roleStats[role]}</p>
                <p className="text-xs text-muted-foreground">{roleLabels[role]}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Users Table */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-3">
              <Users className="h-5 w-5 text-primary" />
              <div>
                <CardTitle>Utilisateurs</CardTitle>
                <CardDescription>{users.length} utilisateur(s) enregistré(s)</CardDescription>
              </div>
            </div>
            <div className="relative w-full md:w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Rechercher..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Utilisateur</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Rôle actuel</TableHead>
                  <TableHead>Inscrit le</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      Aucun utilisateur trouvé
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map(user => {
                    const isUpdating = updatingUser === user.user_id;
                    return (
                      <TableRow key={user.user_id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <span className="text-sm font-medium text-primary">
                                {(user.display_name || user.email || '?')[0].toUpperCase()}
                              </span>
                            </div>
                            <span className="font-medium">
                              {user.display_name || 'Sans nom'}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Mail className="h-3 w-3" />
                            <span className="text-sm">{user.email || 'N/A'}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={roleColors[user.role]}>
                            {roleLabels[user.role]}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2 text-muted-foreground text-sm">
                            <Calendar className="h-3 w-3" />
                            {format(new Date(user.created_at), 'dd MMM yyyy', { locale: fr })}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Select
                            value={user.role}
                            onValueChange={(val) => updateUserRole(user.user_id, val as AppRole)}
                            disabled={isUpdating}
                          >
                            <SelectTrigger className={`w-36 ${isUpdating ? 'opacity-50' : ''}`}>
                              {isUpdating ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <SelectValue />
                              )}
                            </SelectTrigger>
                            <SelectContent>
                              {ROLES.map(role => (
                                <SelectItem key={role} value={role}>
                                  <div className="flex items-center gap-2">
                                    <div className={`h-2 w-2 rounded-full ${roleColors[role].split(' ')[0]}`} />
                                    {roleLabels[role]}
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { useFinancial } from '@/context/FinancialContext';
import { SectionCard, KPICard } from '@/components/ui/KPICard';
import { formatCurrency, formatPercent } from '@/data/financialConfig';
import { Badge } from '@/components/ui/badge';
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { PiggyBank, Users, TrendingUp, Building } from 'lucide-react';

export function SectionFunding() {
  const { state, computed } = useFinancial();
  
  const settings = state.scenarioSettings;
  const years = Array.from(
    { length: settings.durationYears },
    (_, i) => settings.startYear + i
  );

  // Données CA et EBITDA par année avec besoin de financement
  const fundingData = years.map(year => {
    const rev = computed.revenueByYear.find(r => r.year === year) || { revenue: 0, cogs: 0 };
    const pay = computed.payrollByYear.find(p => p.year === year) || { payroll: 0 };
    const op = computed.opexByYear.find(o => o.year === year) || { opex: 0 };
    const cap = computed.capexByYear.find(c => c.year === year) || { capex: 0 };
    
    const grossMargin = rev.revenue - rev.cogs;
    const ebitda = grossMargin - pay.payroll - op.opex;
    const need = computed.fundingNeedsByYear.find(f => f.year === year)?.need || 0;
    
    return {
      year,
      'Chiffre d\'Affaires': rev.revenue / 1000,
      'EBITDA': ebitda / 1000,
      'Besoin': need > 0 ? need / 1000 : 0,
    };
  });

  // Tours de financement
  const totalRaised = state.fundingRounds.reduce((sum, r) => sum + r.amount, 0);
  const latestRound = state.fundingRounds[state.fundingRounds.length - 1];
  
  // Use of funds
  const useOfFundsTotal = Object.values(state.useOfFunds).reduce((a, b) => a + b, 0);
  const useOfFundsData = [
    { name: 'R&D', value: state.useOfFunds.rd, color: 'hsl(var(--primary))' },
    { name: 'Recrutement', value: state.useOfFunds.hiring, color: 'hsl(38, 92%, 50%)' },
    { name: 'Marketing', value: state.useOfFunds.marketing, color: 'hsl(210, 70%, 50%)' },
    { name: 'Stock & Buffer', value: state.useOfFunds.inventory + state.useOfFunds.buffer, color: 'hsl(150, 60%, 40%)' },
  ];

  // Calcul du surplus/déficit
  const surplus = totalRaised - computed.totalFundingNeed;
  const coverageRatio = computed.totalFundingNeed > 0 ? totalRaised / computed.totalFundingNeed : 1;

  return (
    <SectionCard title="Financement & Besoins" id="section-funding">
      {/* Alerte si déficit */}
      {surplus < 0 && (
        <div className="mb-4 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg flex items-center gap-3">
          <Building className="h-5 w-5 text-amber-500" />
          <div>
            <span className="font-medium text-amber-600 dark:text-amber-400">Financement insuffisant</span>
            <span className="text-sm text-muted-foreground ml-2">
              Déficit de {formatCurrency(Math.abs(surplus), true)} - Ajustez le montant à lever dans l'onglet Financement
            </span>
          </div>
        </div>
      )}

      <div className="grid md:grid-cols-4 gap-4 mb-6">
        <KPICard
          label="Total Levé"
          value={formatCurrency(totalRaised, true)}
          subValue={`${state.fundingRounds.length} tour(s)`}
        />
        <KPICard
          label="Besoin Calculé"
          value={formatCurrency(computed.totalFundingNeed, true)}
          subValue={`${state.fundingPeriod.start}-${state.fundingPeriod.end}`}
          trend={surplus < 0 ? 'down' : undefined}
        />
        <KPICard
          label="Surplus / Déficit"
          value={formatCurrency(surplus, true)}
          subValue={`Couverture: ${formatPercent(coverageRatio)}`}
          trend={surplus >= 0 ? 'up' : 'down'}
        />
        <KPICard
          label="Dilution"
          value={formatPercent(computed.equityDilution)}
          subValue="Part investisseurs"
        />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Graphique CA/EBITDA vs Besoin */}
        <div>
          <h4 className="font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Trajectoire Financière & Besoins
          </h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={fundingData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis tickFormatter={(v) => `${v}k€`} />
                <Tooltip formatter={(value: number) => `${value.toFixed(0)}k€`} />
                <Legend />
                <Bar dataKey="Besoin" fill="hsl(0, 0%, 70%)" opacity={0.5} />
                <Line 
                  type="monotone" 
                  dataKey="Chiffre d'Affaires" 
                  stroke="hsl(0, 85%, 50%)" 
                  strokeWidth={2}
                  dot={{ r: 3 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="EBITDA" 
                  stroke="hsl(150, 60%, 40%)" 
                  strokeWidth={2}
                  dot={{ r: 3 }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Use of Funds */}
        <div>
          <h4 className="font-semibold mb-4 flex items-center gap-2">
            <PiggyBank className="h-4 w-4" />
            Utilisation des Fonds
          </h4>
          
          <div className="space-y-3">
            {useOfFundsData.map(item => (
              <div key={item.name}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm font-medium">{item.name}</span>
                  <span className="text-sm font-mono-numbers">{formatCurrency(item.value, true)}</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full transition-all"
                    style={{ 
                      width: `${(item.value / useOfFundsTotal) * 100}%`,
                      backgroundColor: item.color,
                    }}
                  />
                </div>
                <div className="text-xs text-muted-foreground text-right">
                  {((item.value / useOfFundsTotal) * 100).toFixed(0)}%
                </div>
              </div>
            ))}
            
            <div className="pt-3 border-t flex justify-between font-semibold">
              <span>Total</span>
              <span className="font-mono-numbers">{formatCurrency(useOfFundsTotal, true)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tours de financement et Cap Table */}
      <div className="grid lg:grid-cols-2 gap-6 mt-6">
        {/* Tours */}
        <div>
          <h4 className="font-semibold mb-3 flex items-center gap-2">
            <Building className="h-4 w-4" />
            Tours de Financement
          </h4>
          <div className="space-y-3">
            {state.fundingRounds.map(round => (
              <div key={round.id} className="p-3 bg-muted/30 rounded-lg border flex justify-between items-center">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{round.name}</span>
                    <Badge variant="outline" className="text-xs">{round.year}</Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Pre-money: {formatCurrency(round.preMoneyValuation, true)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold font-mono-numbers">{formatCurrency(round.amount, true)}</div>
                  <div className="text-xs text-muted-foreground">
                    {formatPercent(round.amount / (round.preMoneyValuation + round.amount))} dilution
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cap Table */}
        <div>
          <h4 className="font-semibold mb-3 flex items-center gap-2">
            <Users className="h-4 w-4" />
            Table de Capitalisation
          </h4>
          <div className="space-y-2">
            {state.capTable.map((entry, i) => (
              <div key={i} className="flex justify-between items-center p-2 rounded hover:bg-muted/30">
                <span>{entry.shareholder}</span>
                <div className="flex items-center gap-3">
                  <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary rounded-full"
                      style={{ width: `${entry.sharesPercentage}%` }}
                    />
                  </div>
                  <span className="font-mono-numbers font-medium w-12 text-right">
                    {entry.sharesPercentage.toFixed(1)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-4 p-3 bg-primary/10 rounded-lg border border-primary/20">
            <div className="text-sm text-muted-foreground mb-1">Valorisation Post-Money</div>
            <div className="text-2xl font-bold font-mono-numbers">
              {formatCurrency(computed.postMoneyValuation, true)}
            </div>
          </div>
        </div>
      </div>
    </SectionCard>
  );
}

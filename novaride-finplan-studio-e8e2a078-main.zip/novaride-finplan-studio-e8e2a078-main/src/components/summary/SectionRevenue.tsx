import { useFinancial } from '@/context/FinancialContext';
import { SectionCard, KPICard } from '@/components/ui/KPICard';
import { formatCurrency, formatPercent } from '@/data/financialConfig';
import { Badge } from '@/components/ui/badge';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
} from 'recharts';
import { TrendingUp, Package, Euro } from 'lucide-react';

const COLORS = ['hsl(0, 85%, 50%)', 'hsl(0, 0%, 30%)', 'hsl(38, 92%, 50%)', 'hsl(210, 70%, 50%)', 'hsl(150, 60%, 40%)'];

export function SectionRevenue() {
  const { state, computed } = useFinancial();
  
  const settings = state.scenarioSettings;
  const years = Array.from(
    { length: settings.durationYears },
    (_, i) => settings.startYear + i
  );

  // Données CA et marge par année
  const revenueData = years.map(year => {
    const rev = computed.revenueByYear.find(r => r.year === year) || { revenue: 0, cogs: 0 };
    const grossMargin = rev.revenue - rev.cogs;
    const marginRate = rev.revenue > 0 ? (grossMargin / rev.revenue) * 100 : 0;
    
    return {
      year,
      'Chiffre d\'Affaires': rev.revenue / 1000,
      'Marge Brute': grossMargin / 1000,
      marginRate,
    };
  });

  // CA par produit (dernière année)
  const lastYear = years[years.length - 1];
  const firstYear = years[0];
  
  const revenueByProduct = state.products
    .map(product => ({
      name: product.name,
      category: product.category,
      revenue: (product.volumesByYear[lastYear] || 0) * product.priceHT,
      volume: product.volumesByYear[lastYear] || 0,
    }))
    .filter(p => p.revenue > 0)
    .sort((a, b) => b.revenue - a.revenue);

  // CA par catégorie
  const revenueByCategory = state.products.reduce((acc, product) => {
    const category = product.category;
    const revenue = (product.volumesByYear[lastYear] || 0) * product.priceHT;
    acc[category] = (acc[category] || 0) + revenue;
    return acc;
  }, {} as Record<string, number>);

  const categoryData = Object.entries(revenueByCategory)
    .map(([name, value], i) => ({
      name,
      value: value / 1000,
      color: COLORS[i % COLORS.length],
    }))
    .sort((a, b) => b.value - a.value);

  // KPIs
  const totalRevenueFirst = computed.revenueByYear.find(r => r.year === firstYear)?.revenue || 0;
  const totalRevenueLast = computed.revenueByYear.find(r => r.year === lastYear)?.revenue || 0;
  const cagr = totalRevenueLast > 0 && totalRevenueFirst > 0 
    ? Math.pow(totalRevenueLast / totalRevenueFirst, 1 / (settings.durationYears - 1)) - 1 
    : 0;
  
  const lastRevData = revenueData[revenueData.length - 1];
  const avgMargin = revenueData.reduce((sum, r) => sum + r.marginRate, 0) / revenueData.length;

  return (
    <SectionCard title="Chiffre d'Affaires & Revenus" id="section-revenue">
      <div className="grid md:grid-cols-4 gap-4 mb-6">
        <KPICard
          label={`CA ${lastYear}`}
          value={formatCurrency(totalRevenueLast, true)}
          subValue={`TCAM: ${formatPercent(cagr)}`}
          trend="up"
        />
        <KPICard
          label={`CA ${firstYear}`}
          value={formatCurrency(totalRevenueFirst, true)}
          subValue="Année de départ"
        />
        <KPICard
          label="Marge Brute Moyenne"
          value={`${avgMargin.toFixed(1)}%`}
          subValue="Sur la période"
        />
        <KPICard
          label="Produits Actifs"
          value={revenueByProduct.length.toString()}
          subValue={`en ${lastYear}`}
        />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Évolution CA */}
        <div>
          <h4 className="font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Évolution du Chiffre d'Affaires
          </h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis tickFormatter={(v) => `${v}k€`} />
                <Tooltip formatter={(value: number, name: string) => 
                  name === 'marginRate' ? `${value.toFixed(1)}%` : `${value.toFixed(0)}k€`
                } />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="Chiffre d'Affaires" 
                  fill="hsl(0, 85%, 50%)" 
                  stroke="hsl(0, 85%, 50%)" 
                  fillOpacity={0.2} 
                />
                <Area 
                  type="monotone" 
                  dataKey="Marge Brute" 
                  fill="hsl(150, 60%, 40%)" 
                  stroke="hsl(150, 60%, 40%)" 
                  fillOpacity={0.3} 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* CA par catégorie */}
        <div>
          <h4 className="font-semibold mb-4 flex items-center gap-2">
            <Package className="h-4 w-4" />
            CA par Catégorie ({lastYear})
          </h4>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" tickFormatter={(v) => `${v}k€`} />
                <YAxis type="category" dataKey="name" width={100} />
                <Tooltip formatter={(value: number) => `${value.toFixed(0)}k€`} />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-4 space-y-2">
            {categoryData.map((cat, i) => (
              <div key={cat.name} className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded" style={{ backgroundColor: cat.color }} />
                  <span>{cat.name}</span>
                </div>
                <span className="font-mono-numbers font-medium">{formatCurrency(cat.value * 1000, true)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top produits */}
      <div className="mt-6">
        <h4 className="font-semibold mb-3 flex items-center gap-2">
          <Euro className="h-4 w-4" />
          Top Produits ({lastYear})
        </h4>
        <div className="grid md:grid-cols-5 gap-3">
          {revenueByProduct.slice(0, 5).map((product, i) => (
            <div key={product.name} className="p-3 bg-muted/30 rounded-lg border">
              <div className="flex items-center gap-2 mb-1">
                <Badge variant="outline" className="text-xs">{i + 1}</Badge>
                <span className="text-xs text-muted-foreground truncate">{product.category}</span>
              </div>
              <div className="font-medium text-sm truncate">{product.name}</div>
              <div className="font-mono-numbers text-primary font-bold">
                {formatCurrency(product.revenue, true)}
              </div>
              <div className="text-xs text-muted-foreground">
                {product.volume.toLocaleString()} unités
              </div>
            </div>
          ))}
        </div>
      </div>
    </SectionCard>
  );
}

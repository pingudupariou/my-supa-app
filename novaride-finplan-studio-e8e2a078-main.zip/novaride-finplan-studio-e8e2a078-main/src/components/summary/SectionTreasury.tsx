import { useFinancial } from '@/context/FinancialContext';
import { SectionCard, KPICard } from '@/components/ui/KPICard';
import { formatCurrency } from '@/data/financialConfig';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import { Wallet, TrendingUp, AlertTriangle } from 'lucide-react';

export function SectionTreasury() {
  const { state, computed } = useFinancial();
  
  // Utiliser la projection unifiée (source unique de vérité)
  const { treasuryProjection } = computed;
  const { initialCash } = state.scenarioSettings;
  const amountRaised = treasuryProjection.totalFundingRaised;
  const startingCash = initialCash + amountRaised;
  
  // Données depuis le moteur unifié
  const treasuryData = treasuryProjection.years.map(yp => ({
    year: yp.year,
    revenue: yp.revenue / 1000,
    grossMargin: yp.grossMargin / 1000,
    ebitda: yp.ebitda / 1000,
    depreciation: yp.depreciation / 1000,
    capex: yp.capex / 1000,
    cashFlow: yp.cashFlow / 1000,
    treasury: yp.treasuryEnd / 1000,
    isNegative: yp.treasuryEnd < 0,
  }));

  // Indicateurs depuis le moteur unifié
  const minTreasury = treasuryProjection.minTreasury / 1000;
  const breakEvenYear = treasuryProjection.breakEvenYear || 'N/A';
  const maxBurn = treasuryProjection.maxBurn;
  const avgMonthlyBurn = maxBurn / 12 / 1000;
  const runway = treasuryProjection.runway;

  // Alertes trésorerie
  const hasNegativeTreasury = treasuryProjection.minTreasury < 0;
  const criticalYear = treasuryProjection.years.find(y => y.treasuryEnd < 0)?.year;

  return (
    <SectionCard title="Trésorerie & Cash Flow" id="section-treasury">
      {hasNegativeTreasury && (
        <div className="mb-4 p-3 bg-destructive/10 border border-destructive/30 rounded-lg flex items-center gap-3">
          <AlertTriangle className="h-5 w-5 text-destructive" />
          <div>
            <span className="font-medium text-destructive">Alerte Trésorerie</span>
            <span className="text-sm text-muted-foreground ml-2">
              Solde négatif prévu en {criticalYear} - Financement additionnel requis
            </span>
          </div>
        </div>
      )}

      <div className="grid md:grid-cols-4 gap-4 mb-6">
        <div className="financial-card p-4">
          <p className="kpi-label mb-1">Trésorerie Initiale</p>
          <p className="kpi-value">{formatCurrency(startingCash, true)}</p>
          <p className="text-xs text-muted-foreground mt-1">
            Cash T0: {formatCurrency(initialCash, true)} + Levée: {formatCurrency(amountRaised, true)}
          </p>
          <div className="mt-2 text-xs space-y-0.5">
            {state.fundingRounds.map(r => (
              <div key={r.id} className="flex justify-between text-muted-foreground">
                <span>{r.name}</span>
                <span className="font-mono-numbers">{formatCurrency(r.amount, true)}</span>
              </div>
            ))}
          </div>
        </div>
        <KPICard
          label="Point Bas"
          value={formatCurrency(minTreasury * 1000, true)}
          subValue="Sur la période"
          trend={minTreasury < 0 ? 'down' : undefined}
        />
        <KPICard
          label="Break-even"
          value={breakEvenYear.toString()}
          subValue="Cash flow positif"
        />
        <KPICard
          label="Runway"
          value={`${runway} mois`}
          subValue={`Burn: ${formatCurrency(avgMonthlyBurn * 1000, true)}/mois`}
        />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Graphique Cash Flow vs Trésorerie */}
        <div>
          <h4 className="font-semibold mb-4 flex items-center gap-2">
            <Wallet className="h-4 w-4" />
            Évolution Trésorerie
          </h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={treasuryData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis tickFormatter={(v) => `${v}k€`} />
                <Tooltip formatter={(value: number) => `${value.toFixed(0)}k€`} />
                <Legend />
                <Bar 
                  dataKey="cashFlow" 
                  name="Cash Flow" 
                  fill="hsl(var(--accent))" 
                />
                <Line 
                  type="monotone" 
                  dataKey="treasury" 
                  name="Trésorerie" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={3}
                  dot={{ r: 4 }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Graphique P&L simplifié */}
        <div>
          <h4 className="font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            CA → Marge → EBITDA
          </h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={treasuryData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis tickFormatter={(v) => `${v}k€`} />
                <Tooltip formatter={(value: number) => `${value.toFixed(0)}k€`} />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="revenue" 
                  name="CA" 
                  fill="hsl(var(--chart-1))" 
                  stroke="hsl(var(--chart-1))" 
                  fillOpacity={0.1} 
                />
                <Area 
                  type="monotone" 
                  dataKey="grossMargin" 
                  name="Marge Brute" 
                  fill="hsl(var(--accent))" 
                  stroke="hsl(var(--accent))" 
                  fillOpacity={0.2} 
                />
                <Area 
                  type="monotone" 
                  dataKey="ebitda" 
                  name="EBITDA" 
                  fill="hsl(var(--chart-4))" 
                  stroke="hsl(var(--chart-4))" 
                  fillOpacity={0.3} 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Tableau détaillé */}
      <div className="mt-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b">
              <th className="text-left py-2 px-3">Année</th>
              <th className="text-right py-2 px-3">CA</th>
              <th className="text-right py-2 px-3">Marge Brute</th>
              <th className="text-right py-2 px-3">EBITDA</th>
              <th className="text-right py-2 px-3">Amort.</th>
              <th className="text-right py-2 px-3">CAPEX</th>
              <th className="text-right py-2 px-3">Cash Flow</th>
              <th className="text-right py-2 px-3">Trésorerie</th>
            </tr>
          </thead>
          <tbody>
            {treasuryData.map((row) => (
              <tr key={row.year} className={cn(
                "border-b",
                row.isNegative && "bg-destructive/5"
              )}>
                <td className="py-2 px-3 font-medium">{row.year}</td>
                <td className="py-2 px-3 text-right font-mono-numbers">
                  {formatCurrency(row.revenue * 1000, true)}
                </td>
                <td className="py-2 px-3 text-right font-mono-numbers">
                  {formatCurrency(row.grossMargin * 1000, true)}
                </td>
                <td className={cn(
                  "py-2 px-3 text-right font-mono-numbers font-medium",
                  row.ebitda >= 0 ? "text-chart-4" : "text-destructive"
                )}>
                  {formatCurrency(row.ebitda * 1000, true)}
                </td>
                <td className="py-2 px-3 text-right font-mono-numbers text-muted-foreground">
                  {formatCurrency(row.depreciation * 1000, true)}
                </td>
                <td className="py-2 px-3 text-right font-mono-numbers text-muted-foreground">
                  {formatCurrency(row.capex * 1000, true)}
                </td>
                <td className={cn(
                  "py-2 px-3 text-right font-mono-numbers",
                  row.cashFlow >= 0 ? "text-chart-4" : "text-accent"
                )}>
                  {row.cashFlow >= 0 ? '+' : ''}{formatCurrency(row.cashFlow * 1000, true)}
                </td>
                <td className={cn(
                  "py-2 px-3 text-right font-mono-numbers font-bold",
                  row.isNegative ? "text-destructive" : ""
                )}>
                  {formatCurrency(row.treasury * 1000, true)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </SectionCard>
  );
}
import { useFinancial } from '@/context/FinancialContext';
import { SectionCard, KPICard } from '@/components/ui/KPICard';
import { formatCurrency, formatPercent } from '@/data/financialConfig';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { TrendingUp, Target, Calculator } from 'lucide-react';

export function SectionValuation() {
  const { state, computed } = useFinancial();
  
  const settings = state.scenarioSettings;
  const years = Array.from(
    { length: settings.durationYears },
    (_, i) => settings.startYear + i
  );
  const lastYear = years[years.length - 1];
  const firstYear = years[0];

  // Scénarios d'entrée et sortie
  const exitScenarios = [
    { 
      scenario: 'Prudent', 
      entryYear: firstYear, 
      exitYear: lastYear + 1, 
      exitMultiple: 3, 
      probability: 0.25,
    },
    { 
      scenario: 'Base', 
      entryYear: firstYear, 
      exitYear: lastYear, 
      exitMultiple: 5, 
      probability: 0.50,
    },
    { 
      scenario: 'Ambitieux', 
      entryYear: firstYear, 
      exitYear: lastYear - 1, 
      exitMultiple: 8, 
      probability: 0.25,
    },
  ].map(s => {
    const revAtExit = computed.revenueByYear.find(r => r.year === s.exitYear)?.revenue || 
                      computed.revenueByYear.slice(-1)[0]?.revenue || 0;
    const exitValuation = revAtExit * s.exitMultiple;
    const investorShare = computed.equityDilution;
    const investorReturn = exitValuation * investorShare;
    const holdingPeriod = s.exitYear - s.entryYear;
    const investment = state.fundingRounds[state.fundingRounds.length - 1]?.amount || 0;
    const multiple = investment > 0 ? investorReturn / investment : 0;
    const irr = investment > 0 && holdingPeriod > 0 
      ? Math.pow(investorReturn / investment, 1 / holdingPeriod) - 1 
      : 0;
    
    return { ...s, revAtExit, exitValuation, investorReturn, multiple, irr };
  });

  // TRI pondéré
  const weightedIRR = exitScenarios.reduce((sum, e) => sum + e.irr * e.probability, 0);
  const weightedMultiple = exitScenarios.reduce((sum, e) => sum + e.multiple * e.probability, 0);

  // Métriques de valorisation
  const revenueLastYear = computed.revenueByYear.find(r => r.year === lastYear)?.revenue || 0;
  const ebitdaLastYear = (() => {
    const rev = computed.revenueByYear.find(r => r.year === lastYear) || { revenue: 0, cogs: 0 };
    const pay = computed.payrollByYear.find(p => p.year === lastYear) || { payroll: 0 };
    const op = computed.opexByYear.find(o => o.year === lastYear) || { opex: 0 };
    return (rev.revenue - rev.cogs) - pay.payroll - op.opex;
  })();

  return (
    <SectionCard title="Valorisation & Scénarios de Sortie" id="section-valuation">
      <div className="grid md:grid-cols-4 gap-4 mb-6">
        <KPICard
          label={`CA ${lastYear}`}
          value={formatCurrency(revenueLastYear, true)}
          subValue="Base de valorisation"
        />
        <KPICard
          label={`EBITDA ${lastYear}`}
          value={formatCurrency(ebitdaLastYear, true)}
          subValue="Profitabilité opérationnelle"
        />
        <KPICard
          label="TRI Pondéré"
          value={formatPercent(weightedIRR)}
          subValue="Par probabilité"
          trend="up"
        />
        <KPICard
          label="Multiple Moyen"
          value={`${weightedMultiple.toFixed(1)}x`}
          subValue="Retour investisseur"
        />
      </div>

      {/* Scénarios de sortie */}
      <h4 className="font-semibold mb-4 flex items-center gap-2">
        <Target className="h-4 w-4" />
        Scénarios d'Entrée & Sortie
      </h4>
      
      <div className="grid md:grid-cols-3 gap-4 mb-6">
        {exitScenarios.map((exit) => (
          <div key={exit.scenario} className={cn(
            "p-4 rounded-lg border-2",
            exit.scenario === 'Base' ? "border-primary bg-primary/5" : "border-muted bg-muted/30"
          )}>
            <div className="flex justify-between items-center mb-3">
              <Badge variant={exit.scenario === 'Base' ? 'default' : 'outline'}>
                {exit.scenario}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {exit.entryYear} → {exit.exitYear}
              </span>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>CA à la sortie</span>
                <span className="font-mono-numbers">{formatCurrency(exit.revAtExit, true)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Multiple sortie</span>
                <span className="font-mono-numbers font-medium">{exit.exitMultiple}x CA</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Valorisation sortie</span>
                <span className="font-bold font-mono-numbers">{formatCurrency(exit.exitValuation, true)}</span>
              </div>
              <div className="flex justify-between text-sm border-t pt-2">
                <span>Retour investisseur</span>
                <span className="font-bold font-mono-numbers">{formatCurrency(exit.investorReturn, true)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Multiple</span>
                <span className={cn(
                  "font-bold font-mono-numbers",
                  exit.multiple >= 5 ? "text-green-600 dark:text-green-400" : 
                  exit.multiple >= 3 ? "text-amber-600 dark:text-amber-400" : ""
                )}>
                  {exit.multiple.toFixed(1)}x
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span>TRI</span>
                <span className={cn(
                  "font-bold font-mono-numbers",
                  exit.irr >= 0.30 ? "text-green-600 dark:text-green-400" : 
                  exit.irr >= 0.20 ? "text-amber-600 dark:text-amber-400" : ""
                )}>
                  {formatPercent(exit.irr)}
                </span>
              </div>
              <div className="text-xs text-center text-muted-foreground pt-2 border-t">
                Probabilité: {(exit.probability * 100).toFixed(0)}%
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Synthèse pondérée */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-4 bg-primary/10 rounded-lg border border-primary/20">
          <div className="flex items-center gap-2 mb-2">
            <Calculator className="h-5 w-5 text-primary" />
            <span className="font-medium">TRI Pondéré par Probabilité</span>
          </div>
          <div className="text-3xl font-bold font-mono-numbers">
            {formatPercent(weightedIRR)}
          </div>
          <div className="text-sm text-muted-foreground mt-1">
            Rendement annuel attendu
          </div>
        </div>
        
        <div className="p-4 bg-green-500/10 rounded-lg border border-green-500/20">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-5 w-5 text-green-600 dark:text-green-400" />
            <span className="font-medium">Multiple Moyen Pondéré</span>
          </div>
          <div className="text-3xl font-bold font-mono-numbers text-green-600 dark:text-green-400">
            {weightedMultiple.toFixed(1)}x
          </div>
          <div className="text-sm text-muted-foreground mt-1">
            Retour sur investissement
          </div>
        </div>
      </div>
    </SectionCard>
  );
}

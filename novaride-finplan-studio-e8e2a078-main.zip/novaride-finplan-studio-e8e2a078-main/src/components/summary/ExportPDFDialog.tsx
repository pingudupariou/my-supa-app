import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Download, FileText, Loader2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { toast } from '@/hooks/use-toast';

export interface ExportSection {
  id: string;
  label: string;
  elementId: string;
}

const SECTIONS: ExportSection[] = [
  { id: 'scenario', label: 'Configuration du Scénario', elementId: 'section-scenario' },
  { id: 'costs', label: 'Structure des Coûts (OPEX/CAPEX)', elementId: 'section-costs' },
  { id: 'revenue', label: 'Chiffre d\'Affaires & Revenus', elementId: 'section-revenue' },
  { id: 'treasury', label: 'Trésorerie & Cash Flow', elementId: 'section-treasury' },
  { id: 'funding', label: 'Financement & Besoins', elementId: 'section-funding' },
  { id: 'valuation', label: 'Valorisation & Scénarios de Sortie', elementId: 'section-valuation' },
];

export function ExportPDFDialog() {
  const [open, setOpen] = useState(false);
  const [selectedSections, setSelectedSections] = useState<string[]>(SECTIONS.map(s => s.id));
  const [isExporting, setIsExporting] = useState(false);

  const toggleSection = (sectionId: string) => {
    setSelectedSections(prev =>
      prev.includes(sectionId)
        ? prev.filter(id => id !== sectionId)
        : [...prev, sectionId]
    );
  };

  const selectAll = () => {
    setSelectedSections(SECTIONS.map(s => s.id));
  };

  const deselectAll = () => {
    setSelectedSections([]);
  };

  const handleExport = async () => {
    if (selectedSections.length === 0) {
      toast({
        title: 'Aucune section sélectionnée',
        description: 'Veuillez sélectionner au moins une section à exporter.',
        variant: 'destructive',
      });
      return;
    }

    setIsExporting(true);

    try {
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 10;
      let yPosition = margin;
      let isFirstPage = true;

      // Titre
      pdf.setFontSize(20);
      pdf.setFont('helvetica', 'bold');
      pdf.text('Synthèse Investisseur', pageWidth / 2, yPosition + 10, { align: 'center' });
      pdf.setFontSize(10);
      pdf.setFont('helvetica', 'normal');
      pdf.text(`Généré le ${new Date().toLocaleDateString('fr-FR')}`, pageWidth / 2, yPosition + 18, { align: 'center' });
      yPosition += 30;

      const sectionsToExport = SECTIONS.filter(s => selectedSections.includes(s.id));

      for (const section of sectionsToExport) {
        const element = document.getElementById(section.elementId);
        if (!element) continue;

        // Capturer la section
        const canvas = await html2canvas(element, {
          scale: 2,
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff',
        });

        const imgData = canvas.toDataURL('image/png');
        const imgWidth = pageWidth - (margin * 2);
        const imgHeight = (canvas.height * imgWidth) / canvas.width;

        // Vérifier si on doit ajouter une nouvelle page
        if (!isFirstPage && yPosition + imgHeight > pageHeight - margin) {
          pdf.addPage();
          yPosition = margin;
        }

        // Si l'image est trop haute pour une page, la redimensionner
        const maxHeight = pageHeight - margin * 2 - (isFirstPage ? 30 : 0);
        let finalHeight = imgHeight;
        let finalWidth = imgWidth;

        if (finalHeight > maxHeight) {
          finalHeight = maxHeight;
          finalWidth = (canvas.width * finalHeight) / canvas.height;
        }

        pdf.addImage(imgData, 'PNG', margin, yPosition, finalWidth, finalHeight);
        yPosition += finalHeight + 10;
        isFirstPage = false;

        // Si on déborde, nouvelle page
        if (yPosition > pageHeight - margin) {
          pdf.addPage();
          yPosition = margin;
        }
      }

      // Pied de page
      const pageCount = pdf.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        pdf.setPage(i);
        pdf.setFontSize(8);
        pdf.setFont('helvetica', 'normal');
        pdf.text(
          `Page ${i} / ${pageCount}`,
          pageWidth / 2,
          pageHeight - 5,
          { align: 'center' }
        );
      }

      pdf.save(`Synthese_Investisseur_${new Date().toISOString().split('T')[0]}.pdf`);

      toast({
        title: 'Export réussi',
        description: `${selectedSections.length} section(s) exportée(s) en PDF.`,
      });

      setOpen(false);
    } catch (error) {
      console.error('Export error:', error);
      toast({
        title: 'Erreur d\'export',
        description: 'Une erreur est survenue lors de la génération du PDF.',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="default" className="gap-2">
          <Download className="h-4 w-4" />
          Exporter en PDF
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Exporter la Synthèse
          </DialogTitle>
          <DialogDescription>
            Sélectionnez les sections à inclure dans votre PDF.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={selectAll}>
              Tout sélectionner
            </Button>
            <Button variant="outline" size="sm" onClick={deselectAll}>
              Tout désélectionner
            </Button>
          </div>

          <div className="space-y-3">
            {SECTIONS.map(section => (
              <div key={section.id} className="flex items-center space-x-3">
                <Checkbox
                  id={section.id}
                  checked={selectedSections.includes(section.id)}
                  onCheckedChange={() => toggleSection(section.id)}
                />
                <Label
                  htmlFor={section.id}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  {section.label}
                </Label>
              </div>
            ))}
          </div>

          <div className="text-sm text-muted-foreground">
            {selectedSections.length} section(s) sélectionnée(s)
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Annuler
          </Button>
          <Button 
            onClick={handleExport} 
            disabled={isExporting || selectedSections.length === 0}
            className="gap-2"
          >
            {isExporting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Génération...
              </>
            ) : (
              <>
                <Download className="h-4 w-4" />
                Télécharger
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

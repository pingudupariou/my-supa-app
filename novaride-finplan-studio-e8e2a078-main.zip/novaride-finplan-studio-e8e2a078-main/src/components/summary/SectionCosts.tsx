import { useFinancial } from '@/context/FinancialContext';
import { SectionCard } from '@/components/ui/KPICard';
import { formatCurrency } from '@/data/financialConfig';
import { Badge } from '@/components/ui/badge';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { Users, Building2, Wrench, Package } from 'lucide-react';

const COLORS = ['hsl(0, 85%, 50%)', 'hsl(38, 92%, 50%)', 'hsl(210, 70%, 50%)', 'hsl(150, 60%, 40%)', 'hsl(280, 60%, 50%)'];

export function SectionCosts() {
  const { state, computed } = useFinancial();
  
  const settings = state.scenarioSettings;
  const years = Array.from(
    { length: settings.durationYears },
    (_, i) => settings.startYear + i
  );

  // Données pour le graphique empilé des coûts
  const costBreakdownData = years.map(year => {
    const payroll = computed.payrollByYear.find(p => p.year === year)?.payroll || 0;
    const opex = computed.opexByYear.find(o => o.year === year)?.opex || 0;
    const capex = computed.capexByYear.find(c => c.year === year)?.capex || 0;
    const cogs = computed.revenueByYear.find(r => r.year === year)?.cogs || 0;
    
    return {
      year,
      'Masse Salariale': payroll / 1000,
      'OPEX': opex / 1000,
      'CAPEX (R&D)': capex / 1000,
      'COGS': cogs / 1000,
    };
  });

  // Catégories OPEX pour le pie chart (dernière année)
  const lastYear = years[years.length - 1];
  const opexCategories = computed.opexByYear.find(o => o.year === lastYear)?.byCategory || {};
  const opexPieData = Object.entries(opexCategories).map(([name, value], i) => ({
    name,
    value,
    color: COLORS[i % COLORS.length],
  }));

  // Totaux cumulés
  const totalPayroll = computed.payrollByYear.reduce((sum, p) => sum + p.payroll, 0);
  const totalOpex = computed.opexByYear.reduce((sum, o) => sum + o.opex, 0);
  const totalCapex = computed.capexByYear.reduce((sum, c) => sum + c.capex, 0);
  const totalCogs = computed.revenueByYear.reduce((sum, r) => sum + r.cogs, 0);

  // Top 5 dépenses OPEX
  const topExpenses = state.expenses
    .map(e => ({
      ...e,
      totalCost: years.reduce((sum, year) => {
        if (e.startYear > year) return sum;
        const yearsSinceStart = year - e.startYear;
        let cost = e.baseAnnualCost;
        if (e.evolutionType === 'growth_rate') {
          cost = e.baseAnnualCost * Math.pow(1 + (e.growthRate || 0), yearsSinceStart);
        }
        return sum + cost;
      }, 0),
    }))
    .sort((a, b) => b.totalCost - a.totalCost)
    .slice(0, 5);

  return (
    <SectionCard title="Structure des Coûts" id="section-costs">
      <div className="grid md:grid-cols-4 gap-4 mb-6">
        <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
          <div className="flex items-center gap-2 mb-2">
            <Users className="h-5 w-5 text-primary" />
            <span className="text-sm font-medium">Masse Salariale</span>
          </div>
          <div className="text-2xl font-bold font-mono-numbers text-primary">
            {formatCurrency(totalPayroll, true)}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            {computed.payrollByYear.slice(-1)[0]?.headcount || 0} collaborateurs cible
          </div>
        </div>
        
        <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
          <div className="flex items-center gap-2 mb-2">
            <Building2 className="h-5 w-5 text-amber-500" />
            <span className="text-sm font-medium">OPEX</span>
          </div>
          <div className="text-2xl font-bold font-mono-numbers text-amber-600 dark:text-amber-400">
            {formatCurrency(totalOpex, true)}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            {state.expenses.length} postes de charges
          </div>
        </div>
        
        <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
          <div className="flex items-center gap-2 mb-2">
            <Wrench className="h-5 w-5 text-blue-500" />
            <span className="text-sm font-medium">CAPEX (R&D)</span>
          </div>
          <div className="text-2xl font-bold font-mono-numbers text-blue-600 dark:text-blue-400">
            {formatCurrency(totalCapex, true)}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            {state.products.filter(p => p.devCost > 0).length} produits en développement
          </div>
        </div>
        
        <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
          <div className="flex items-center gap-2 mb-2">
            <Package className="h-5 w-5 text-green-500" />
            <span className="text-sm font-medium">COGS</span>
          </div>
          <div className="text-2xl font-bold font-mono-numbers text-green-600 dark:text-green-400">
            {formatCurrency(totalCogs, true)}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Coût des ventes cumulé
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Graphique empilé par année */}
        <div>
          <h4 className="font-semibold mb-4">Évolution des Coûts par Année</h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={costBreakdownData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" />
                <YAxis tickFormatter={(v) => `${v}k€`} />
                <Tooltip formatter={(value: number) => `${value.toFixed(0)}k€`} />
                <Legend />
                <Bar dataKey="Masse Salariale" stackId="a" fill="hsl(0, 85%, 50%)" />
                <Bar dataKey="OPEX" stackId="a" fill="hsl(38, 92%, 50%)" />
                <Bar dataKey="CAPEX (R&D)" stackId="a" fill="hsl(210, 70%, 50%)" />
                <Bar dataKey="COGS" stackId="a" fill="hsl(150, 60%, 40%)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Répartition OPEX */}
        <div>
          <h4 className="font-semibold mb-4">Répartition OPEX en {lastYear}</h4>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={opexPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={70}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {opexPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div className="space-y-2 mt-4">
            {opexPieData.slice(0, 4).map((cat, i) => (
              <div key={cat.name} className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded" style={{ backgroundColor: cat.color }} />
                  <span>{cat.name}</span>
                </div>
                <span className="font-mono-numbers">{formatCurrency(cat.value, true)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top 5 postes OPEX */}
      <div className="mt-6">
        <h4 className="font-semibold mb-3">Top 5 Postes de Charges</h4>
        <div className="grid md:grid-cols-5 gap-3">
          {topExpenses.map((expense, i) => (
            <div key={expense.id} className="p-3 bg-muted/30 rounded-lg border">
              <div className="flex items-center gap-2 mb-1">
                <Badge variant="outline" className="text-xs">{i + 1}</Badge>
                <span className="text-xs text-muted-foreground truncate">{expense.category}</span>
              </div>
              <div className="font-medium text-sm truncate">{expense.name}</div>
              <div className="font-mono-numbers text-primary font-bold">
                {formatCurrency(expense.totalCost, true)}
              </div>
              <div className="text-xs text-muted-foreground">
                {expense.evolutionType === 'fixed' && 'Fixe'}
                {expense.evolutionType === 'growth_rate' && `+${((expense.growthRate || 0) * 100).toFixed(0)}%/an`}
                {expense.evolutionType === 'linked_to_revenue' && `${((expense.revenueRatio || 0) * 100).toFixed(1)}% CA`}
              </div>
            </div>
          ))}
        </div>
      </div>
    </SectionCard>
  );
}

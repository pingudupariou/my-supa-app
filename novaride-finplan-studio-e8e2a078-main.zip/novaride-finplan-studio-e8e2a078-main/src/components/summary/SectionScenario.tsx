import { useFinancial } from '@/context/FinancialContext';
import { SectionCard, KPICard } from '@/components/ui/KPICard';
import { Badge } from '@/components/ui/badge';
import { formatCurrency, formatPercent } from '@/data/financialConfig';
import { Settings, Calendar, TrendingUp, TrendingDown } from 'lucide-react';

export function SectionScenario() {
  const { state, computed } = useFinancial();
  
  const scenarioLabels = {
    conservative: 'Prudent',
    base: 'Base',
    ambitious: 'Ambitieux',
  };
  
  const config = state.scenarioConfigs[state.activeScenarioId];
  const settings = state.scenarioSettings;
  const years = Array.from(
    { length: settings.durationYears },
    (_, i) => settings.startYear + i
  );

  return (
    <SectionCard title="Configuration du Scénario" id="section-scenario">
      <div className="flex items-center gap-3 mb-6">
        <Settings className="h-5 w-5 text-muted-foreground" />
        <Badge variant="default" className="text-sm">
          {scenarioLabels[state.activeScenarioId]}
        </Badge>
        <span className="text-sm text-muted-foreground">
          {settings.startYear} → {settings.startYear + settings.durationYears - 1}
        </span>
        <Badge variant="outline" className="text-xs">
          {settings.durationYears} ans
        </Badge>
      </div>

      <div className="grid md:grid-cols-4 gap-4 mb-6">
        <div className="p-4 rounded-lg bg-muted/30 border">
          <div className="flex items-center gap-2 mb-2">
            {config.volumeAdjustment >= 0 ? (
              <TrendingUp className="h-4 w-4 text-green-500" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-500" />
            )}
            <span className="text-sm text-muted-foreground">Volumes</span>
          </div>
          <div className="text-xl font-bold font-mono-numbers">
            {config.volumeAdjustment >= 0 ? '+' : ''}{formatPercent(config.volumeAdjustment)}
          </div>
        </div>
        
        <div className="p-4 rounded-lg bg-muted/30 border">
          <div className="flex items-center gap-2 mb-2">
            {config.priceAdjustment >= 0 ? (
              <TrendingUp className="h-4 w-4 text-green-500" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-500" />
            )}
            <span className="text-sm text-muted-foreground">Prix</span>
          </div>
          <div className="text-xl font-bold font-mono-numbers">
            {config.priceAdjustment >= 0 ? '+' : ''}{formatPercent(config.priceAdjustment)}
          </div>
        </div>
        
        <div className="p-4 rounded-lg bg-muted/30 border">
          <div className="flex items-center gap-2 mb-2">
            {config.opexAdjustment <= 0 ? (
              <TrendingUp className="h-4 w-4 text-green-500" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-500" />
            )}
            <span className="text-sm text-muted-foreground">OPEX</span>
          </div>
          <div className="text-xl font-bold font-mono-numbers">
            {config.opexAdjustment >= 0 ? '+' : ''}{formatPercent(config.opexAdjustment)}
          </div>
        </div>
        
        <div className="p-4 rounded-lg bg-muted/30 border">
          <div className="flex items-center gap-2 mb-2">
            {config.marginAdjustment >= 0 ? (
              <TrendingUp className="h-4 w-4 text-green-500" />
            ) : (
              <TrendingDown className="h-4 w-4 text-red-500" />
            )}
            <span className="text-sm text-muted-foreground">Marge</span>
          </div>
          <div className="text-xl font-bold font-mono-numbers">
            {config.marginAdjustment >= 0 ? '+' : ''}{formatPercent(config.marginAdjustment)}
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        <KPICard
          label="Produits"
          value={state.products.length.toString()}
          subValue="en portefeuille"
        />
        <KPICard
          label="Effectif cible"
          value={computed.payrollByYear.slice(-1)[0]?.headcount.toString() || '0'}
          subValue={`en ${years[years.length - 1]}`}
        />
        <KPICard
          label="Postes OPEX"
          value={state.expenses.length.toString()}
          subValue="catégories"
        />
        <KPICard
          label="Tours de table"
          value={state.fundingRounds.length.toString()}
          subValue="prévus"
        />
      </div>
    </SectionCard>
  );
}

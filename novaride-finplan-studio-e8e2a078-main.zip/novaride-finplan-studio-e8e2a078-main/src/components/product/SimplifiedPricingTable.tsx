import { useState } from 'react';
import { Product, VolumesByChannel } from '@/engine/types';
import { SectionCard } from '@/components/ui/KPICard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { formatCurrency, formatPercent } from '@/data/financialConfig';
import { cn } from '@/lib/utils';
import { Plus, Edit2, Trash2, AlertTriangle, Check, Calculator } from 'lucide-react';
import { ChannelVolumesEditor, createDefaultVolumesByChannel, migrateVolumesToChannels } from './ChannelVolumesEditor';

interface SimplifiedPricingTableProps {
  products: Product[];
  onUpdateProduct: (product: Product) => void;
  onAddProduct: (product: Product) => void;
  onRemoveProduct: (id: string) => void;
}

// Valeurs par défaut pour les coefficients (migration de données anciennes)
const DEFAULT_COEF_SHOP = 1.6;
const DEFAULT_COEF_DIST = 1.3;
const DEFAULT_COEF_OEM = 1.4;
const DEFAULT_VAT_RATE = 0.20;

// Calculs automatiques des prix avec valeurs par défaut sécurisées
function calculatePrices(product: Partial<Product>) {
  // Extraction avec valeurs par défaut pour éviter les undefined
  const priceTTC_B2C = product.priceTTC_B2C ?? (product.priceHT ? product.priceHT * (1 + DEFAULT_VAT_RATE) : 500);
  const vatRate = product.vatRate ?? DEFAULT_VAT_RATE;
  const unitCost = product.unitCost ?? 200;
  const coef_shop = product.coef_shop ?? DEFAULT_COEF_SHOP;
  const coef_dist = product.coef_dist ?? DEFAULT_COEF_DIST;
  const coef_oem = product.coef_oem ?? DEFAULT_COEF_OEM;
  
  // Prix public HT B2C
  const priceHT_B2C = priceTTC_B2C / (1 + vatRate);
  
  // B2B: Prix shop → Prix distributeur → Prix marque
  const priceAchatShop_HT = coef_shop > 0 ? priceHT_B2C / coef_shop : 0;
  const priceMarqueB2B_HT = coef_dist > 0 ? priceAchatShop_HT / coef_dist : 0;
  const margeB2B_EUR = priceMarqueB2B_HT - unitCost;
  const margeB2B_PCT = priceMarqueB2B_HT > 0 ? margeB2B_EUR / priceMarqueB2B_HT : 0;
  
  // OEM: Prix = Coût × coefficient
  const priceOEM_HT = unitCost * coef_oem;
  const margeOEM_EUR = priceOEM_HT - unitCost;
  const margeOEM_PCT = priceOEM_HT > 0 ? margeOEM_EUR / priceOEM_HT : 0;
  
  // B2C: Marge directe
  const margeB2C_EUR = priceHT_B2C - unitCost;
  const margeB2C_PCT = priceHT_B2C > 0 ? margeB2C_EUR / priceHT_B2C : 0;
  
  return {
    priceHT_B2C,
    priceAchatShop_HT,
    priceMarqueB2B_HT,
    margeB2B_EUR,
    margeB2B_PCT,
    priceOEM_HT,
    margeOEM_EUR,
    margeOEM_PCT,
    margeB2C_EUR,
    margeB2C_PCT,
  };
}

interface ProductFormState {
  name: string;
  launchYear: number;
  unitCost: number;
  priceTTC_B2C: number;
  vatRate: number;
  coef_shop: number;
  coef_dist: number;
  coef_oem: number;
  devCost: number;
  devAmortizationYears: number;
  volumesByChannel: VolumesByChannel;
}

const defaultFormState: ProductFormState = {
  name: '',
  launchYear: 2026,
  unitCost: 200,
  priceTTC_B2C: 500,
  vatRate: 0.20,
  coef_shop: 1.6,
  coef_dist: 1.3,
  coef_oem: 1.4,
  devCost: 50000,
  devAmortizationYears: 5,
  volumesByChannel: createDefaultVolumesByChannel(2026),
};

export function SimplifiedPricingTable({
  products,
  onUpdateProduct,
  onAddProduct,
  onRemoveProduct,
}: SimplifiedPricingTableProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [formState, setFormState] = useState<ProductFormState>(defaultFormState);

  const handleOpenAdd = () => {
    const newDefaultState = {
      ...defaultFormState,
      volumesByChannel: createDefaultVolumesByChannel(defaultFormState.launchYear),
    };
    setFormState(newDefaultState);
    setIsAddDialogOpen(true);
  };

  const handleOpenEdit = (product: Product) => {
    // Migrer les anciens volumes si nécessaire
    const volumesByChannel = migrateVolumesToChannels(
      product.volumesByYear,
      product.volumesByChannel
    );
    
    setFormState({
      name: product.name,
      launchYear: product.launchYear,
      unitCost: product.unitCost ?? 200,
      priceTTC_B2C: product.priceTTC_B2C ?? (product.priceHT ? product.priceHT * (1 + DEFAULT_VAT_RATE) : 500),
      vatRate: product.vatRate ?? DEFAULT_VAT_RATE,
      coef_shop: product.coef_shop ?? DEFAULT_COEF_SHOP,
      coef_dist: product.coef_dist ?? DEFAULT_COEF_DIST,
      coef_oem: product.coef_oem ?? DEFAULT_COEF_OEM,
      devCost: product.devCost,
      devAmortizationYears: product.devAmortizationYears || 5,
      volumesByChannel,
    });
    setEditingProductId(product.id);
  };

  const handleSave = () => {
    const priceHT = formState.priceTTC_B2C / (1 + formState.vatRate);
    
    // Calculer volumesByYear comme somme des canaux
    const volumesByYear: Record<number, number> = {};
    const years = Object.keys(formState.volumesByChannel.B2C).map(Number);
    years.forEach(year => {
      volumesByYear[year] = 
        (formState.volumesByChannel.B2C[year] || 0) +
        (formState.volumesByChannel.B2B[year] || 0) +
        (formState.volumesByChannel.OEM[year] || 0);
    });
    
    if (editingProductId) {
      // Édition
      const existingProduct = products.find(p => p.id === editingProductId);
      if (existingProduct) {
        onUpdateProduct({
          ...existingProduct,
          name: formState.name,
          launchYear: formState.launchYear,
          unitCost: formState.unitCost,
          priceTTC_B2C: formState.priceTTC_B2C,
          priceHT,
          vatRate: formState.vatRate,
          coef_shop: formState.coef_shop,
          coef_dist: formState.coef_dist,
          coef_oem: formState.coef_oem,
          devCost: formState.devCost,
          devAmortizationYears: formState.devAmortizationYears,
          volumesByYear,
          volumesByChannel: formState.volumesByChannel,
        });
      }
      setEditingProductId(null);
    } else {
      // Ajout
      const newProduct: Product = {
        id: `product-${Date.now()}`,
        name: formState.name,
        category: 'B2C',
        launchYear: formState.launchYear,
        unitCost: formState.unitCost,
        priceTTC_B2C: formState.priceTTC_B2C,
        priceHT,
        vatRate: formState.vatRate,
        coef_shop: formState.coef_shop,
        coef_dist: formState.coef_dist,
        coef_oem: formState.coef_oem,
        devCost: formState.devCost,
        devAmortizationYears: formState.devAmortizationYears,
        volumesByYear,
        volumesByChannel: formState.volumesByChannel,
      };
      onAddProduct(newProduct);
      setIsAddDialogOpen(false);
    }
  };

  // Calcul des prix pour la prévisualisation - utiliser uniquement formState
  const previewPrices = calculatePrices({
    priceTTC_B2C: formState.priceTTC_B2C,
    vatRate: formState.vatRate,
    unitCost: formState.unitCost,
    coef_shop: formState.coef_shop,
    coef_dist: formState.coef_dist,
    coef_oem: formState.coef_oem,
  });

  const hasNegativeMargin = previewPrices.margeB2B_PCT < 0 || previewPrices.margeOEM_PCT < 0;

  const ProductForm = () => (
    <div className="space-y-6">
      {/* Infos de base */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Nom du produit</Label>
          <Input
            value={formState.name}
            onChange={(e) => setFormState({ ...formState, name: e.target.value })}
            placeholder="CCD EVO Pro"
          />
        </div>
        <div className="space-y-2">
          <Label>Année de lancement</Label>
          <Input
            type="number"
            value={formState.launchYear}
            onChange={(e) => setFormState({ ...formState, launchYear: Number(e.target.value) })}
            min={2024}
            max={2035}
          />
        </div>
      </div>

      {/* Coût et prix de base */}
      <div className="grid grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>Coût de production (€)</Label>
          <Input
            type="number"
            value={formState.unitCost}
            onChange={(e) => setFormState({ ...formState, unitCost: Number(e.target.value) })}
          />
        </div>
        <div className="space-y-2">
          <Label>Prix public TTC B2C (€)</Label>
          <Input
            type="number"
            value={formState.priceTTC_B2C}
            onChange={(e) => setFormState({ ...formState, priceTTC_B2C: Number(e.target.value) })}
          />
        </div>
        <div className="space-y-2">
          <Label>TVA</Label>
          <div className="flex gap-1">
            {[0.055, 0.10, 0.20].map(rate => (
              <Button
                key={rate}
                type="button"
                size="sm"
                variant={formState.vatRate === rate ? 'default' : 'outline'}
                onClick={() => setFormState({ ...formState, vatRate: rate })}
              >
                {(rate * 100).toFixed(1)}%
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Investissement R&D */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Investissement R&D (€)</Label>
          <Input
            type="number"
            value={formState.devCost}
            onChange={(e) => setFormState({ ...formState, devCost: Number(e.target.value) })}
          />
        </div>
        <div className="space-y-2">
          <Label>Durée amortissement (ans)</Label>
          <Input
            type="number"
            value={formState.devAmortizationYears}
            onChange={(e) => setFormState({ ...formState, devAmortizationYears: Number(e.target.value) })}
            min={1}
            max={10}
          />
        </div>
      </div>

      {/* Coefficients B2B */}
      <div className="p-4 bg-muted/30 rounded-lg space-y-4">
        <h4 className="font-semibold flex items-center gap-2">
          <Badge>B2B</Badge>
          Coefficients distributeur
        </h4>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <Label>Coef. Shop</Label>
              <span className="font-mono-numbers">{formState.coef_shop.toFixed(2)}</span>
            </div>
            <Slider
              value={[formState.coef_shop * 100]}
              onValueChange={([v]) => setFormState({ ...formState, coef_shop: v / 100 })}
              min={110}
              max={250}
              step={5}
            />
            <p className="text-xs text-muted-foreground">Prix public HT / Prix shop = {formState.coef_shop}</p>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <Label>Coef. Distributeur</Label>
              <span className="font-mono-numbers">{formState.coef_dist.toFixed(2)}</span>
            </div>
            <Slider
              value={[formState.coef_dist * 100]}
              onValueChange={([v]) => setFormState({ ...formState, coef_dist: v / 100 })}
              min={110}
              max={200}
              step={5}
            />
            <p className="text-xs text-muted-foreground">Prix shop / Prix distrib = {formState.coef_dist}</p>
          </div>
        </div>
        <div className="pt-2 border-t text-sm">
          <div className="flex justify-between">
            <span>Prix marque → distributeur HT:</span>
            <span className="font-bold font-mono-numbers">{formatCurrency(previewPrices.priceMarqueB2B_HT)}</span>
          </div>
          <div className="flex justify-between">
            <span>Marge B2B:</span>
            <span className={cn(
              "font-bold font-mono-numbers",
              previewPrices.margeB2B_PCT < 0 ? "text-destructive" : previewPrices.margeB2B_PCT < 0.20 ? "text-amber-600" : "text-green-600"
            )}>
              {formatCurrency(previewPrices.margeB2B_EUR)} ({formatPercent(previewPrices.margeB2B_PCT)})
            </span>
          </div>
        </div>
      </div>

      {/* Coefficient OEM */}
      <div className="p-4 bg-muted/30 rounded-lg space-y-4">
        <h4 className="font-semibold flex items-center gap-2">
          <Badge variant="secondary">OEM</Badge>
          Coefficient grands comptes
        </h4>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <Label>Coef. OEM (sur coût de production)</Label>
            <span className="font-mono-numbers">{formState.coef_oem.toFixed(2)}</span>
          </div>
          <Slider
            value={[formState.coef_oem * 100]}
            onValueChange={([v]) => setFormState({ ...formState, coef_oem: v / 100 })}
            min={105}
            max={200}
            step={5}
          />
          <p className="text-xs text-muted-foreground">Prix OEM = Coût production × {formState.coef_oem}</p>
        </div>
        <div className="pt-2 border-t text-sm">
          <div className="flex justify-between">
            <span>Prix OEM HT:</span>
            <span className="font-bold font-mono-numbers">{formatCurrency(previewPrices.priceOEM_HT)}</span>
          </div>
          <div className="flex justify-between">
            <span>Marge OEM:</span>
            <span className={cn(
              "font-bold font-mono-numbers",
              previewPrices.margeOEM_PCT < 0 ? "text-destructive" : previewPrices.margeOEM_PCT < 0.15 ? "text-amber-600" : "text-green-600"
            )}>
              {formatCurrency(previewPrices.margeOEM_EUR)} ({formatPercent(previewPrices.margeOEM_PCT)})
            </span>
          </div>
        </div>
      </div>

      {/* Alerte marge négative */}
      {hasNegativeMargin && (
        <div className="flex items-center gap-2 p-3 bg-destructive/10 border border-destructive/30 rounded-lg">
          <AlertTriangle className="h-5 w-5 text-destructive" />
          <span className="text-sm text-destructive font-medium">
            Attention : une ou plusieurs marges sont négatives !
          </span>
        </div>
      )}

      {/* Résumé des prix */}
      <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
        <h4 className="font-semibold mb-3 flex items-center gap-2">
          <Calculator className="h-4 w-4" />
          Récapitulatif des prix
        </h4>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="p-3 bg-background rounded-lg">
            <div className="text-xs text-muted-foreground mb-1">B2C (TTC)</div>
            <div className="text-lg font-bold font-mono-numbers">{formatCurrency(formState.priceTTC_B2C)}</div>
            <div className="text-xs text-muted-foreground">HT: {formatCurrency(previewPrices.priceHT_B2C)}</div>
            <div className={cn(
              "text-xs font-medium",
              previewPrices.margeB2C_PCT >= 0.5 ? "text-green-600" : "text-amber-600"
            )}>
              Marge: {formatPercent(previewPrices.margeB2C_PCT)}
            </div>
          </div>
          <div className="p-3 bg-background rounded-lg">
            <div className="text-xs text-muted-foreground mb-1">B2B (HT)</div>
            <div className="text-lg font-bold font-mono-numbers">{formatCurrency(previewPrices.priceMarqueB2B_HT)}</div>
            <div className="text-xs text-muted-foreground">Shop: {formatCurrency(previewPrices.priceAchatShop_HT)}</div>
            <div className={cn(
              "text-xs font-medium",
              previewPrices.margeB2B_PCT < 0 ? "text-destructive" : previewPrices.margeB2B_PCT >= 0.25 ? "text-green-600" : "text-amber-600"
            )}>
              Marge: {formatPercent(previewPrices.margeB2B_PCT)}
            </div>
          </div>
          <div className="p-3 bg-background rounded-lg">
            <div className="text-xs text-muted-foreground mb-1">OEM (HT)</div>
            <div className="text-lg font-bold font-mono-numbers">{formatCurrency(previewPrices.priceOEM_HT)}</div>
            <div className="text-xs text-muted-foreground">×{formState.coef_oem} coût</div>
            <div className={cn(
              "text-xs font-medium",
              previewPrices.margeOEM_PCT < 0 ? "text-destructive" : previewPrices.margeOEM_PCT >= 0.20 ? "text-green-600" : "text-amber-600"
            )}>
              Marge: {formatPercent(previewPrices.margeOEM_PCT)}
            </div>
          </div>
        </div>
      </div>

      {/* Volumes par canal */}
      <ChannelVolumesEditor
        launchYear={formState.launchYear}
        volumesByChannel={formState.volumesByChannel}
        onChange={(volumes) => setFormState({ ...formState, volumesByChannel: volumes })}
        projectionYears={5}
      />
    </div>
  );

  return (
    <SectionCard 
      title="Pricing Simplifié"
      action={
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" onClick={handleOpenAdd}>
              <Plus className="h-4 w-4 mr-1" />
              Nouveau Produit
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Ajouter un produit</DialogTitle>
              <DialogDescription>
                Configurez le produit et ses coefficients de distribution
              </DialogDescription>
            </DialogHeader>
            <ProductForm />
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Annuler</Button>
              <Button onClick={handleSave} disabled={!formState.name}>
                <Check className="h-4 w-4 mr-1" />
                Créer le produit
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      }
    >
      <p className="text-sm text-muted-foreground mb-4">
        Un produit = une ligne. Les prix B2B et OEM sont calculés automatiquement à partir du prix public TTC B2C et des coefficients.
      </p>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Produit</TableHead>
              <TableHead className="text-right">Coût Prod.</TableHead>
              <TableHead className="text-right">Prix B2C TTC</TableHead>
              <TableHead className="text-right">Marge B2C</TableHead>
              <TableHead className="text-right">Prix B2B HT</TableHead>
              <TableHead className="text-right">Marge B2B</TableHead>
              <TableHead className="text-right">Prix OEM HT</TableHead>
              <TableHead className="text-right">Marge OEM</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {products.map((product) => {
              const prices = calculatePrices(product);
              const hasIssue = prices.margeB2B_PCT < 0 || prices.margeOEM_PCT < 0;
              
              return (
                <TableRow key={product.id} className={hasIssue ? "bg-destructive/5" : ""}>
                  <TableCell>
                    <div className="font-medium">{product.name}</div>
                    <div className="text-xs text-muted-foreground">
                      Lancement: {product.launchYear} • R&D: {formatCurrency(product.devCost, true)}
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-mono-numbers">
                    {formatCurrency(product.unitCost)}
                  </TableCell>
                  <TableCell className="text-right font-mono-numbers font-medium">
                    {formatCurrency(product.priceTTC_B2C)}
                  </TableCell>
                  <TableCell className={cn(
                    "text-right font-mono-numbers",
                    prices.margeB2C_PCT >= 0.5 ? "text-green-600 dark:text-green-400" : "text-amber-600 dark:text-amber-400"
                  )}>
                    {formatPercent(prices.margeB2C_PCT)}
                  </TableCell>
                  <TableCell className="text-right font-mono-numbers">
                    {formatCurrency(prices.priceMarqueB2B_HT)}
                  </TableCell>
                  <TableCell className={cn(
                    "text-right font-mono-numbers",
                    prices.margeB2B_PCT < 0 ? "text-destructive" : 
                    prices.margeB2B_PCT >= 0.25 ? "text-green-600 dark:text-green-400" : "text-amber-600 dark:text-amber-400"
                  )}>
                    {prices.margeB2B_PCT < 0 && <AlertTriangle className="h-3 w-3 inline mr-1" />}
                    {formatPercent(prices.margeB2B_PCT)}
                  </TableCell>
                  <TableCell className="text-right font-mono-numbers">
                    {formatCurrency(prices.priceOEM_HT)}
                  </TableCell>
                  <TableCell className={cn(
                    "text-right font-mono-numbers",
                    prices.margeOEM_PCT < 0 ? "text-destructive" : 
                    prices.margeOEM_PCT >= 0.20 ? "text-green-600 dark:text-green-400" : "text-amber-600 dark:text-amber-400"
                  )}>
                    {prices.margeOEM_PCT < 0 && <AlertTriangle className="h-3 w-3 inline mr-1" />}
                    {formatPercent(prices.margeOEM_PCT)}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Dialog open={editingProductId === product.id} onOpenChange={(open) => !open && setEditingProductId(null)}>
                        <DialogTrigger asChild>
                          <Button size="icon" variant="ghost" onClick={() => handleOpenEdit(product)}>
                            <Edit2 className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle>Modifier {product.name}</DialogTitle>
                            <DialogDescription>
                              Ajustez les paramètres et coefficients de distribution
                            </DialogDescription>
                          </DialogHeader>
                          <ProductForm />
                          <DialogFooter>
                            <Button variant="outline" onClick={() => setEditingProductId(null)}>Annuler</Button>
                            <Button onClick={handleSave}>
                              <Check className="h-4 w-4 mr-1" />
                              Enregistrer
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        onClick={() => onRemoveProduct(product.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {/* Explication des calculs */}
      <div className="mt-6 p-4 bg-muted/30 rounded-lg text-sm">
        <h4 className="font-semibold mb-2">Logique de calcul</h4>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <p className="font-medium text-primary">B2B:</p>
            <ol className="list-decimal list-inside text-muted-foreground space-y-1">
              <li>Prix public HT = Prix TTC ÷ (1 + TVA)</li>
              <li>Prix shop HT = Prix public HT ÷ Coef. shop</li>
              <li>Prix marque HT = Prix shop HT ÷ Coef. distrib</li>
              <li>Marge = Prix marque - Coût production</li>
            </ol>
          </div>
          <div>
            <p className="font-medium text-primary">OEM:</p>
            <ol className="list-decimal list-inside text-muted-foreground space-y-1">
              <li>Prix OEM HT = Coût production × Coef. OEM</li>
              <li>Marge = Prix OEM - Coût production</li>
            </ol>
          </div>
        </div>
      </div>
    </SectionCard>
  );
}

export { calculatePrices };

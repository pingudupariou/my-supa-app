import { useState, useEffect, useRef } from 'react';
import { VolumesByChannel } from '@/engine/types';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { TrendingUp, Store, Factory, Sparkles } from 'lucide-react';

// Taux de croissance disponibles
const GROWTH_RATES = [
  { value: '0', label: '0%' },
  { value: '5', label: '+5%' },
  { value: '10', label: '+10%' },
  { value: '15', label: '+15%' },
  { value: '20', label: '+20%' },
  { value: '25', label: '+25%' },
  { value: '30', label: '+30%' },
  { value: '50', label: '+50%' },
  { value: '75', label: '+75%' },
  { value: '100', label: '+100%' },
];

// Input spécialisé qui garde le focus pendant la saisie
interface VolumeInputProps {
  value: number;
  onChange: (value: number) => void;
  className?: string;
}

function VolumeInput({ value, onChange, className }: VolumeInputProps) {
  const [localValue, setLocalValue] = useState(value.toString());
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync local value when external value changes (but not during editing)
  useEffect(() => {
    if (document.activeElement !== inputRef.current) {
      setLocalValue(value.toString());
    }
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocalValue(e.target.value);
  };

  const handleBlur = () => {
    const num = parseInt(localValue, 10);
    const finalValue = isNaN(num) ? 0 : Math.max(0, num);
    setLocalValue(finalValue.toString());
    onChange(finalValue);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      inputRef.current?.blur();
    }
  };

  return (
    <Input
      ref={inputRef}
      type="text"
      inputMode="numeric"
      value={localValue}
      onChange={handleChange}
      onBlur={handleBlur}
      onKeyDown={handleKeyDown}
      className={className}
      min={0}
    />
  );
}

// Type pour les taux de croissance par canal
type GrowthRates = {
  B2C: number;
  B2B: number;
  OEM: number;
};

interface ChannelVolumesEditorProps {
  launchYear: number;
  volumesByChannel: VolumesByChannel;
  onChange: (volumes: VolumesByChannel) => void;
  projectionYears?: number;
}

const CHANNELS = [
  { id: 'B2C' as const, label: 'B2C Direct', icon: TrendingUp, color: 'bg-primary text-primary-foreground' },
  { id: 'B2B' as const, label: 'B2B Réseau', icon: Store, color: 'bg-secondary text-secondary-foreground' },
  { id: 'OEM' as const, label: 'OEM', icon: Factory, color: 'bg-muted text-muted-foreground' },
];

export function ChannelVolumesEditor({
  launchYear,
  volumesByChannel,
  onChange,
  projectionYears = 5,
}: ChannelVolumesEditorProps) {
  const years = Array.from({ length: projectionYears }, (_, i) => launchYear + i);
  
  // État local pour les taux de croissance par canal
  const [growthRates, setGrowthRates] = useState<GrowthRates>({
    B2C: 10,
    B2B: 15,
    OEM: 20,
  });
  
  // État local pour les volumes de départ (évite les re-renders pendant la saisie)
  const [startVolumes, setStartVolumes] = useState<GrowthRates>(() => ({
    B2C: volumesByChannel.B2C[launchYear] || 0,
    B2B: volumesByChannel.B2B[launchYear] || 0,
    OEM: volumesByChannel.OEM[launchYear] || 0,
  }));
  
  // Sync start volumes when external data changes (but keep local during editing)
  useEffect(() => {
    setStartVolumes({
      B2C: volumesByChannel.B2C[launchYear] || 0,
      B2B: volumesByChannel.B2B[launchYear] || 0,
      OEM: volumesByChannel.OEM[launchYear] || 0,
    });
  }, [launchYear, volumesByChannel.B2C[launchYear], volumesByChannel.B2B[launchYear], volumesByChannel.OEM[launchYear]]);

  const handleVolumeChange = (channel: keyof VolumesByChannel, year: number, value: number) => {
    const newVolumes = {
      ...volumesByChannel,
      [channel]: {
        ...volumesByChannel[channel],
        [year]: Math.max(0, value),
      },
    };
    onChange(newVolumes);
  };

  const handleGrowthRateChange = (channel: keyof VolumesByChannel, rate: number) => {
    setGrowthRates(prev => ({ ...prev, [channel]: rate }));
  };
  
  const handleStartVolumeChange = (channel: keyof VolumesByChannel, value: number) => {
    setStartVolumes(prev => ({ ...prev, [channel]: value }));
  };

  // Appliquer la croissance automatique pour un canal
  const applyGrowthForChannel = (channel: keyof VolumesByChannel) => {
    const rate = growthRates[channel];
    const firstYear = years[0];
    const startVolume = volumesByChannel[channel][firstYear] || 0;
    
    const newChannelVolumes: Record<number, number> = { [firstYear]: startVolume };
    
    for (let i = 1; i < years.length; i++) {
      const prevYear = years[i - 1];
      const currentYear = years[i];
      const prevVolume = newChannelVolumes[prevYear];
      newChannelVolumes[currentYear] = Math.round(prevVolume * (1 + rate / 100));
    }
    
    const newVolumes = {
      ...volumesByChannel,
      [channel]: newChannelVolumes,
    };
    onChange(newVolumes);
  };

  // Appliquer la croissance à tous les canaux (utilise startVolumes local)
  const applyGrowthAll = () => {
    const newVolumes: VolumesByChannel = { B2C: {}, B2B: {}, OEM: {} };
    
    for (const channel of ['B2C', 'B2B', 'OEM'] as const) {
      const rate = growthRates[channel];
      const firstYear = years[0];
      const startVol = startVolumes[channel];
      
      newVolumes[channel][firstYear] = startVol;
      
      for (let i = 1; i < years.length; i++) {
        const prevYear = years[i - 1];
        const currentYear = years[i];
        const prevVolume = newVolumes[channel][prevYear];
        newVolumes[channel][currentYear] = Math.round(prevVolume * (1 + rate / 100));
      }
    }
    
    onChange(newVolumes);
  };

  // Calculer les totaux par année et par canal
  const getTotalByYear = (year: number) => {
    return (volumesByChannel.B2C[year] || 0) + 
           (volumesByChannel.B2B[year] || 0) + 
           (volumesByChannel.OEM[year] || 0);
  };

  const getTotalByChannel = (channel: keyof VolumesByChannel) => {
    return years.reduce((sum, year) => sum + (volumesByChannel[channel][year] || 0), 0);
  };

  const grandTotal = years.reduce((sum, year) => sum + getTotalByYear(year), 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label className="text-base font-semibold">Volumes par canal et par année</Label>
        <Badge variant="outline" className="font-mono-numbers">
          Total: {grandTotal.toLocaleString()} unités
        </Badge>
      </div>

      {/* Section croissance rapide */}
      <Card className="border-dashed border-primary/30 bg-primary/5">
        <CardHeader className="py-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            Croissance automatique
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
            {CHANNELS.map(channel => (
              <div key={channel.id} className="space-y-1">
                <Label className="text-xs text-muted-foreground">{channel.label}</Label>
                <div className="flex gap-1">
                  <VolumeInput
                    value={startVolumes[channel.id]}
                    onChange={(val) => handleStartVolumeChange(channel.id, val)}
                    className="h-9 w-20 font-mono-numbers text-sm"
                  />
                  <Select
                    value={growthRates[channel.id].toString()}
                    onValueChange={(v) => handleGrowthRateChange(channel.id, Number(v))}
                  >
                    <SelectTrigger className="h-9 w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {GROWTH_RATES.map(rate => (
                        <SelectItem key={rate.value} value={rate.value}>
                          {rate.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            ))}
            <Button 
              onClick={applyGrowthAll} 
              size="sm" 
              className="h-9"
            >
              <Sparkles className="h-4 w-4 mr-1" />
              Appliquer
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Entrez le volume de départ ({years[0]}) et le taux de croissance annuel, puis cliquez "Appliquer".
          </p>
        </CardContent>
      </Card>

      <Tabs defaultValue="table" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="table">Tableau</TabsTrigger>
          <TabsTrigger value="channels">Par canal</TabsTrigger>
        </TabsList>

        <TabsContent value="table" className="mt-4">
          <div className="overflow-x-auto border rounded-lg">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/50">
                  <th className="p-2 text-left font-medium">Canal</th>
                  {years.map(year => (
                    <th key={year} className="p-2 text-center font-medium font-mono-numbers">
                      {year}
                    </th>
                  ))}
                  <th className="p-2 text-center font-medium bg-muted">Total</th>
                </tr>
              </thead>
              <tbody>
                {CHANNELS.map(channel => (
                  <tr key={channel.id} className="border-t">
                    <td className="p-2">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={cn("text-xs", channel.id === 'B2C' && "border-primary text-primary")}>
                          {channel.label}
                        </Badge>
                      </div>
                    </td>
                    {years.map(year => (
                      <td key={year} className="p-1">
                        <VolumeInput
                          value={volumesByChannel[channel.id][year] || 0}
                          onChange={(val) => handleVolumeChange(channel.id, year, val)}
                          className="w-20 h-8 text-center font-mono-numbers text-xs"
                        />
                      </td>
                    ))}
                    <td className="p-2 text-center font-mono-numbers font-medium bg-muted/30">
                      {getTotalByChannel(channel.id).toLocaleString()}
                    </td>
                  </tr>
                ))}
                <tr className="border-t bg-muted/30 font-medium">
                  <td className="p-2">Total</td>
                  {years.map(year => (
                    <td key={year} className="p-2 text-center font-mono-numbers">
                      {getTotalByYear(year).toLocaleString()}
                    </td>
                  ))}
                  <td className="p-2 text-center font-mono-numbers font-bold bg-primary/10">
                    {grandTotal.toLocaleString()}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </TabsContent>

        <TabsContent value="channels" className="mt-4">
          <div className="grid gap-4">
            {CHANNELS.map(channel => {
              const ChannelIcon = channel.icon;
              const channelTotal = getTotalByChannel(channel.id);
              const channelPct = grandTotal > 0 ? (channelTotal / grandTotal * 100).toFixed(1) : '0';
              
              return (
                <Card key={channel.id}>
                  <CardHeader className="py-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <ChannelIcon className="h-4 w-4" />
                        {channel.label}
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="font-mono-numbers">
                          {channelTotal.toLocaleString()} unités
                        </Badge>
                        <Badge variant="outline" className="font-mono-numbers">
                          {channelPct}%
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="grid grid-cols-5 gap-2">
                      {years.map(year => (
                        <div key={year} className="space-y-1">
                          <Label className="text-xs text-muted-foreground">{year}</Label>
                          <VolumeInput
                            value={volumesByChannel[channel.id][year] || 0}
                            onChange={(val) => handleVolumeChange(channel.id, year, val)}
                            className="h-9 font-mono-numbers"
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>

      <p className="text-xs text-muted-foreground">
        💡 Les prix et marges diffèrent selon le canal : B2C (prix public), B2B (via coefficients distributeur), OEM (sur coût de production).
      </p>
    </div>
  );
}

// Helper pour créer des volumes par défaut
export function createDefaultVolumesByChannel(launchYear: number): VolumesByChannel {
  const years = [launchYear, launchYear + 1, launchYear + 2, launchYear + 3, launchYear + 4];
  
  return {
    B2C: Object.fromEntries(years.map((y, i) => [y, 20 + i * 15])),
    B2B: Object.fromEntries(years.map((y, i) => [y, 30 + i * 25])),
    OEM: Object.fromEntries(years.map((y, i) => [y, 10 + i * 10])),
  };
}

// Helper pour migrer les anciens volumes (single) vers le nouveau format (par canal)
export function migrateVolumesToChannels(
  volumesByYear: Record<number, number>,
  volumesByChannel?: VolumesByChannel
): VolumesByChannel {
  // Si déjà migré, retourner tel quel
  if (volumesByChannel && Object.keys(volumesByChannel.B2C).length > 0) {
    return volumesByChannel;
  }
  
  // Sinon, répartir les anciens volumes: 30% B2C, 50% B2B, 20% OEM
  const B2C: Record<number, number> = {};
  const B2B: Record<number, number> = {};
  const OEM: Record<number, number> = {};
  
  Object.entries(volumesByYear).forEach(([year, total]) => {
    const y = Number(year);
    B2C[y] = Math.round(total * 0.3);
    B2B[y] = Math.round(total * 0.5);
    OEM[y] = Math.round(total * 0.2);
  });
  
  return { B2C, B2B, OEM };
}

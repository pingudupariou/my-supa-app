import { useState, useMemo } from 'react';
import { Product, ProductCategory } from '@/engine/types';
import { SectionCard } from '@/components/ui/KPICard';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  LineChart,
  Line,
} from 'recharts';
import { Settings2, TrendingUp, Store, Factory, Package } from 'lucide-react';
import { formatCurrency } from '@/data/financialConfig';

interface RevenueVisualizationProps {
  products: Product[];
  years: number[];
}

type ViewMode = 'by-product' | 'by-channel' | 'evolution';

const CHANNEL_COLORS = {
  B2C: 'hsl(var(--primary))',
  B2B: 'hsl(var(--secondary))',
  OEM: 'hsl(var(--accent))',
};

const PRODUCT_COLORS = [
  'hsl(var(--primary))',
  'hsl(220, 70%, 50%)',
  'hsl(150, 60%, 40%)',
  'hsl(45, 80%, 50%)',
  'hsl(280, 60%, 50%)',
  'hsl(0, 70%, 50%)',
  'hsl(180, 60%, 40%)',
];

export function RevenueVisualization({ products, years }: RevenueVisualizationProps) {
  const [selectedYear, setSelectedYear] = useState<number | 'all'>(years[years.length - 1] || 'all');
  const [viewMode, setViewMode] = useState<ViewMode>('by-product');
  
  // Indicateurs à afficher
  const [visibleIndicators, setVisibleIndicators] = useState({
    pieChart: true,
    barChart: true,
    evolutionChart: true,
    details: true,
    channelBreakdown: true,
    productBreakdown: true,
  });

  // Calcul du CA par produit, canal et année
  const revenueData = useMemo(() => {
    const byProductAndYear: Record<string, Record<number, number>> = {};
    const byChannelAndYear: Record<ProductCategory, Record<number, number>> = {
      B2C: {},
      B2B: {},
      OEM: {},
    };
    const byProductAndChannel: Record<string, Record<ProductCategory, number>> = {};

    products.forEach(product => {
      byProductAndYear[product.id] = {};
      byProductAndChannel[product.id] = { B2C: 0, B2B: 0, OEM: 0 };

      years.forEach(year => {
        if (year < product.launchYear) {
          byProductAndYear[product.id][year] = 0;
          return;
        }

        const volB2C = product.volumesByChannel?.B2C[year] || 0;
        const volB2B = product.volumesByChannel?.B2B[year] || 0;
        const volOEM = product.volumesByChannel?.OEM[year] || 0;

        // Prix par canal
        const priceB2C = product.priceHT;
        const priceB2B = product.priceHT / (product.coef_shop || 1) / (product.coef_dist || 1);
        const priceOEM = product.unitCost * (product.coef_oem || 1);

        const revB2C = volB2C * priceB2C;
        const revB2B = volB2B * priceB2B;
        const revOEM = volOEM * priceOEM;
        const totalRev = revB2C + revB2B + revOEM;

        byProductAndYear[product.id][year] = totalRev;
        
        byChannelAndYear.B2C[year] = (byChannelAndYear.B2C[year] || 0) + revB2C;
        byChannelAndYear.B2B[year] = (byChannelAndYear.B2B[year] || 0) + revB2B;
        byChannelAndYear.OEM[year] = (byChannelAndYear.OEM[year] || 0) + revOEM;

        byProductAndChannel[product.id].B2C += revB2C;
        byProductAndChannel[product.id].B2B += revB2B;
        byProductAndChannel[product.id].OEM += revOEM;
      });
    });

    return { byProductAndYear, byChannelAndYear, byProductAndChannel };
  }, [products, years]);

  // Données pour le graphique camembert par produit
  const pieDataByProduct = useMemo(() => {
    return products.map((product, index) => {
      let revenue = 0;
      if (selectedYear === 'all') {
        revenue = years.reduce((sum, y) => sum + (revenueData.byProductAndYear[product.id]?.[y] || 0), 0);
      } else {
        revenue = revenueData.byProductAndYear[product.id]?.[selectedYear] || 0;
      }
      return {
        name: product.name,
        value: revenue,
        color: PRODUCT_COLORS[index % PRODUCT_COLORS.length],
      };
    }).filter(d => d.value > 0);
  }, [products, revenueData, selectedYear, years]);

  // Données pour le graphique camembert par canal
  const pieDataByChannel = useMemo(() => {
    const channels: ProductCategory[] = ['B2C', 'B2B', 'OEM'];
    return channels.map(channel => {
      let revenue = 0;
      if (selectedYear === 'all') {
        revenue = years.reduce((sum, y) => sum + (revenueData.byChannelAndYear[channel]?.[y] || 0), 0);
      } else {
        revenue = revenueData.byChannelAndYear[channel]?.[selectedYear] || 0;
      }
      return {
        name: channel,
        value: revenue,
        color: CHANNEL_COLORS[channel],
      };
    }).filter(d => d.value > 0);
  }, [revenueData, selectedYear, years]);

  // Données pour l'évolution
  const evolutionData = useMemo(() => {
    return years.map(year => {
      const entry: Record<string, number | string> = { year };
      
      products.forEach((product, index) => {
        entry[product.name] = revenueData.byProductAndYear[product.id]?.[year] || 0;
      });
      
      entry.B2C = revenueData.byChannelAndYear.B2C[year] || 0;
      entry.B2B = revenueData.byChannelAndYear.B2B[year] || 0;
      entry.OEM = revenueData.byChannelAndYear.OEM[year] || 0;
      entry.total = (entry.B2C as number) + (entry.B2B as number) + (entry.OEM as number);
      
      return entry;
    });
  }, [products, years, revenueData]);

  // Total CA
  const totalRevenue = useMemo(() => {
    if (selectedYear === 'all') {
      return years.reduce((sum, year) => {
        const yearTotal = (revenueData.byChannelAndYear.B2C[year] || 0) +
                          (revenueData.byChannelAndYear.B2B[year] || 0) +
                          (revenueData.byChannelAndYear.OEM[year] || 0);
        return sum + yearTotal;
      }, 0);
    }
    return (revenueData.byChannelAndYear.B2C[selectedYear] || 0) +
           (revenueData.byChannelAndYear.B2B[selectedYear] || 0) +
           (revenueData.byChannelAndYear.OEM[selectedYear] || 0);
  }, [revenueData, selectedYear, years]);

  const toggleIndicator = (key: keyof typeof visibleIndicators) => {
    setVisibleIndicators(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border rounded-lg p-3 shadow-lg">
          <p className="font-medium mb-1">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {entry.name}: {formatCurrency(entry.value, true)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const PieTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0];
      const percentage = totalRevenue > 0 ? ((data.value / totalRevenue) * 100).toFixed(1) : 0;
      return (
        <div className="bg-background border rounded-lg p-3 shadow-lg">
          <p className="font-medium">{data.name}</p>
          <p className="text-sm text-muted-foreground">
            {formatCurrency(data.value, true)} ({percentage}%)
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <SectionCard 
      title="Visualisation du Chiffre d'Affaires"
      action={
        <div className="flex items-center gap-2">
          <Select 
            value={selectedYear.toString()} 
            onValueChange={(v) => setSelectedYear(v === 'all' ? 'all' : Number(v))}
          >
            <SelectTrigger className="w-28 h-8">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Période</SelectItem>
              {years.map(year => (
                <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm">
                <Settings2 className="h-4 w-4 mr-1" />
                Affichage
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-64" align="end">
              <div className="space-y-3">
                <h4 className="font-medium text-sm">Éléments à afficher</h4>
                <div className="space-y-2">
                  {[
                    { key: 'pieChart', label: 'Graphique circulaire' },
                    { key: 'barChart', label: 'Barres empilées' },
                    { key: 'evolutionChart', label: 'Courbe d\'évolution' },
                    { key: 'details', label: 'Détails CA HT' },
                    { key: 'channelBreakdown', label: 'Répartition par canal' },
                    { key: 'productBreakdown', label: 'Répartition par produit' },
                  ].map(item => (
                    <div key={item.key} className="flex items-center gap-2">
                      <Checkbox
                        id={item.key}
                        checked={visibleIndicators[item.key as keyof typeof visibleIndicators]}
                        onCheckedChange={() => toggleIndicator(item.key as keyof typeof visibleIndicators)}
                      />
                      <Label htmlFor={item.key} className="text-sm cursor-pointer">
                        {item.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      }
    >
      <div className="space-y-6">
        {/* KPI Total */}
        <div className="flex items-center justify-between p-4 bg-primary/5 rounded-lg border border-primary/20">
          <div>
            <p className="text-sm text-muted-foreground">
              CA HT Total {selectedYear === 'all' ? '(période)' : selectedYear}
            </p>
            <p className="text-2xl font-bold font-mono-numbers">{formatCurrency(totalRevenue, true)}</p>
          </div>
          <div className="flex gap-4">
            <Button
              variant={viewMode === 'by-product' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('by-product')}
            >
              <Package className="h-4 w-4 mr-1" />
              Produits
            </Button>
            <Button
              variant={viewMode === 'by-channel' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('by-channel')}
            >
              <Store className="h-4 w-4 mr-1" />
              Canaux
            </Button>
            <Button
              variant={viewMode === 'evolution' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('evolution')}
            >
              <TrendingUp className="h-4 w-4 mr-1" />
              Évolution
            </Button>
          </div>
        </div>

        {/* Vue par Produit */}
        {viewMode === 'by-product' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {visibleIndicators.pieChart && pieDataByProduct.length > 0 && (
              <div className="h-64">
                <h4 className="text-sm font-medium mb-2">Répartition CA par Produit</h4>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieDataByProduct}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                      label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                      labelLine={false}
                    >
                      {pieDataByProduct.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<PieTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}

            {visibleIndicators.productBreakdown && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium mb-2">Détail CA HT par Produit</h4>
                {pieDataByProduct.map((item, index) => {
                  const pct = totalRevenue > 0 ? ((item.value / totalRevenue) * 100).toFixed(1) : 0;
                  return (
                    <div key={item.name} className="flex items-center justify-between p-2 bg-muted/30 rounded">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: item.color }}
                        />
                        <span className="text-sm">{item.name}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-mono-numbers text-sm">{formatCurrency(item.value, true)}</span>
                        <Badge variant="outline" className="font-mono-numbers">{pct}%</Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Vue par Canal */}
        {viewMode === 'by-channel' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {visibleIndicators.pieChart && pieDataByChannel.length > 0 && (
              <div className="h-64">
                <h4 className="text-sm font-medium mb-2">Répartition CA par Canal</h4>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieDataByChannel}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                      label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                      labelLine={false}
                    >
                      {pieDataByChannel.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<PieTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}

            {visibleIndicators.channelBreakdown && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium mb-2">Détail CA HT par Canal</h4>
                {pieDataByChannel.map((item) => {
                  const pct = totalRevenue > 0 ? ((item.value / totalRevenue) * 100).toFixed(1) : 0;
                  const Icon = item.name === 'B2C' ? TrendingUp : item.name === 'B2B' ? Store : Factory;
                  return (
                    <div key={item.name} className="flex items-center justify-between p-2 bg-muted/30 rounded">
                      <div className="flex items-center gap-2">
                        <Icon className="h-4 w-4" style={{ color: item.color }} />
                        <span className="text-sm">{item.name}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-mono-numbers text-sm">{formatCurrency(item.value, true)}</span>
                        <Badge variant="outline" className="font-mono-numbers">{pct}%</Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {visibleIndicators.barChart && (
              <div className="h-64 lg:col-span-2">
                <h4 className="text-sm font-medium mb-2">CA par Canal et Année</h4>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={evolutionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis tickFormatter={(v) => `${(v / 1000).toFixed(0)}k€`} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar dataKey="B2C" name="B2C" stackId="a" fill={CHANNEL_COLORS.B2C} />
                    <Bar dataKey="B2B" name="B2B" stackId="a" fill={CHANNEL_COLORS.B2B} />
                    <Bar dataKey="OEM" name="OEM" stackId="a" fill={CHANNEL_COLORS.OEM} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        )}

        {/* Vue Évolution */}
        {viewMode === 'evolution' && visibleIndicators.evolutionChart && (
          <div className="space-y-6">
            <div className="h-64">
              <h4 className="text-sm font-medium mb-2">Évolution du CA par Produit</h4>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={evolutionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="year" />
                  <YAxis tickFormatter={(v) => `${(v / 1000).toFixed(0)}k€`} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  {products.map((product, index) => (
                    <Line
                      key={product.id}
                      type="monotone"
                      dataKey={product.name}
                      stroke={PRODUCT_COLORS[index % PRODUCT_COLORS.length]}
                      strokeWidth={2}
                      dot={{ r: 4 }}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="h-64">
              <h4 className="text-sm font-medium mb-2">Évolution du CA par Canal</h4>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={evolutionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="year" />
                  <YAxis tickFormatter={(v) => `${(v / 1000).toFixed(0)}k€`} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Line type="monotone" dataKey="B2C" stroke={CHANNEL_COLORS.B2C} strokeWidth={2} dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="B2B" stroke={CHANNEL_COLORS.B2B} strokeWidth={2} dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="OEM" stroke={CHANNEL_COLORS.OEM} strokeWidth={2} dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="total" name="Total" stroke="hsl(var(--foreground))" strokeWidth={3} dot={{ r: 5 }} strokeDasharray="5 5" />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {visibleIndicators.details && (
              <div className="overflow-x-auto border rounded-lg">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-muted/50">
                      <th className="p-2 text-left font-medium">Année</th>
                      <th className="p-2 text-right font-medium">B2C</th>
                      <th className="p-2 text-right font-medium">B2B</th>
                      <th className="p-2 text-right font-medium">OEM</th>
                      <th className="p-2 text-right font-medium bg-primary/10">Total HT</th>
                    </tr>
                  </thead>
                  <tbody>
                    {evolutionData.map((row, idx) => (
                      <tr key={row.year as number} className="border-t">
                        <td className="p-2 font-medium">{row.year}</td>
                        <td className="p-2 text-right font-mono-numbers">{formatCurrency(row.B2C as number, true)}</td>
                        <td className="p-2 text-right font-mono-numbers">{formatCurrency(row.B2B as number, true)}</td>
                        <td className="p-2 text-right font-mono-numbers">{formatCurrency(row.OEM as number, true)}</td>
                        <td className="p-2 text-right font-mono-numbers font-bold bg-primary/5">
                          {formatCurrency(row.total as number, true)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </SectionCard>
  );
}

import { useState, useRef, useEffect } from 'react';
import { GlobalRevenueConfig } from '@/context/FinancialContext';
import { SectionCard } from '@/components/ui/KPICard';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { TrendingUp, Store, Factory } from 'lucide-react';
import { formatCurrency } from '@/data/financialConfig';

interface GlobalRevenueEditorProps {
  config: GlobalRevenueConfig;
  onChange: (config: Partial<GlobalRevenueConfig>) => void;
  years: number[];
}

const GROWTH_RATES = [
  { value: '0', label: '0%' },
  { value: '0.05', label: '+5%' },
  { value: '0.10', label: '+10%' },
  { value: '0.15', label: '+15%' },
  { value: '0.20', label: '+20%' },
  { value: '0.25', label: '+25%' },
  { value: '0.30', label: '+30%' },
  { value: '0.40', label: '+40%' },
  { value: '0.50', label: '+50%' },
];

// Générer les options de marge de 0% à 99%
const MARGIN_RATES = Array.from({ length: 100 }, (_, i) => ({
  value: (i / 100).toString(),
  label: `${i}%`,
}));

// Input qui garde le focus
function AmountInput({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  const [localValue, setLocalValue] = useState(value.toString());
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (document.activeElement !== inputRef.current) {
      setLocalValue(value.toString());
    }
  }, [value]);

  const handleBlur = () => {
    const num = parseInt(localValue, 10);
    const finalValue = isNaN(num) ? 0 : Math.max(0, num);
    setLocalValue(finalValue.toString());
    onChange(finalValue);
  };

  return (
    <Input
      ref={inputRef}
      type="text"
      inputMode="numeric"
      value={localValue}
      onChange={(e) => setLocalValue(e.target.value)}
      onBlur={handleBlur}
      onKeyDown={(e) => e.key === 'Enter' && inputRef.current?.blur()}
      className="h-9 w-32 font-mono-numbers text-right"
    />
  );
}

export function GlobalRevenueEditor({ config, onChange, years }: GlobalRevenueEditorProps) {
  const channels = [
    { id: 'B2C' as const, label: 'B2C Direct', icon: TrendingUp, color: 'text-primary' },
    { id: 'B2B' as const, label: 'B2B Réseau', icon: Store, color: 'text-secondary-foreground' },
    { id: 'OEM' as const, label: 'OEM', icon: Factory, color: 'text-muted-foreground' },
  ];

  // Calcul du CA projeté par année et canal avec marges
  const projectedRevenue = years.map((year, yearIndex) => {
    const b2c = config.B2C.baseAmount * Math.pow(1 + config.B2C.growthRate, yearIndex);
    const b2b = config.B2B.baseAmount * Math.pow(1 + config.B2B.growthRate, yearIndex);
    const oem = config.OEM.baseAmount * Math.pow(1 + config.OEM.growthRate, yearIndex);
    const total = b2c + b2b + oem;
    
    // Calcul marge pondérée
    const marginB2C = b2c * config.B2C.marginRate;
    const marginB2B = b2b * config.B2B.marginRate;
    const marginOEM = oem * config.OEM.marginRate;
    const totalMargin = marginB2C + marginB2B + marginOEM;
    const avgMarginRate = total > 0 ? totalMargin / total : 0;
    
    return { year, B2C: b2c, B2B: b2b, OEM: oem, total, margin: totalMargin, avgMarginRate };
  });

  const totalPeriod = projectedRevenue.reduce((sum, y) => sum + y.total, 0);
  const totalMarginPeriod = projectedRevenue.reduce((sum, y) => sum + y.margin, 0);

  const handleChannelChange = (
    channel: 'B2C' | 'B2B' | 'OEM',
    field: 'baseAmount' | 'growthRate' | 'marginRate',
    value: number
  ) => {
    onChange({
      [channel]: { ...config[channel], [field]: value },
    });
  };

  return (
    <SectionCard title="CA Global par Canal">
      <p className="text-sm text-muted-foreground mb-4">
        Définissez le CA HT de base (année {years[0]}) et le taux de croissance annuel pour chaque canal.
        Les montants sont automatiquement projetés sur la période.
      </p>

      {/* Configuration par canal */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {channels.map(channel => {
          const Icon = channel.icon;
          return (
            <div key={channel.id} className="p-4 border rounded-lg bg-muted/20">
              <div className="flex items-center gap-2 mb-3">
                <Icon className={`h-4 w-4 ${channel.color}`} />
                <span className="font-medium">{channel.label}</span>
              </div>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground">CA Base {years[0]} (€ HT)</Label>
                  <AmountInput
                    value={config[channel.id].baseAmount}
                    onChange={(v) => handleChannelChange(channel.id, 'baseAmount', v)}
                  />
                </div>
                
                <div>
                  <Label className="text-xs text-muted-foreground">Croissance annuelle</Label>
                  <Select
                    value={config[channel.id].growthRate.toString()}
                    onValueChange={(v) => handleChannelChange(channel.id, 'growthRate', parseFloat(v))}
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {GROWTH_RATES.map(rate => (
                        <SelectItem key={rate.value} value={rate.value}>
                          {rate.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-xs text-muted-foreground">Marge brute</Label>
                  <Select
                    value={(config[channel.id].marginRate || 0.35).toString()}
                    onValueChange={(v) => handleChannelChange(channel.id, 'marginRate', parseFloat(v))}
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {MARGIN_RATES.map(rate => (
                        <SelectItem key={rate.value} value={rate.value}>
                          {rate.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Tableau de projection */}
      <div className="overflow-x-auto border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Année</TableHead>
              <TableHead className="text-right">B2C</TableHead>
              <TableHead className="text-right">B2B</TableHead>
              <TableHead className="text-right">OEM</TableHead>
              <TableHead className="text-right bg-primary/10">Total HT</TableHead>
              <TableHead className="text-right bg-green-500/10">Marge Brute</TableHead>
              <TableHead className="text-right">Taux MB</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {projectedRevenue.map((row) => (
              <TableRow key={row.year}>
                <TableCell className="font-medium">{row.year}</TableCell>
                <TableCell className="text-right font-mono-numbers">
                  {formatCurrency(row.B2C, true)}
                </TableCell>
                <TableCell className="text-right font-mono-numbers">
                  {formatCurrency(row.B2B, true)}
                </TableCell>
                <TableCell className="text-right font-mono-numbers">
                  {formatCurrency(row.OEM, true)}
                </TableCell>
                <TableCell className="text-right font-mono-numbers font-bold bg-primary/5">
                  {formatCurrency(row.total, true)}
                </TableCell>
                <TableCell className="text-right font-mono-numbers text-green-600 bg-green-500/5">
                  {formatCurrency(row.margin, true)}
                </TableCell>
                <TableCell className="text-right font-mono-numbers text-muted-foreground">
                  {(row.avgMarginRate * 100).toFixed(1)}%
                </TableCell>
              </TableRow>
            ))}
            <TableRow className="bg-muted/30 font-bold">
              <TableCell>Total Période</TableCell>
              <TableCell className="text-right font-mono-numbers">
                {formatCurrency(projectedRevenue.reduce((s, r) => s + r.B2C, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono-numbers">
                {formatCurrency(projectedRevenue.reduce((s, r) => s + r.B2B, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono-numbers">
                {formatCurrency(projectedRevenue.reduce((s, r) => s + r.OEM, 0), true)}
              </TableCell>
              <TableCell className="text-right font-mono-numbers bg-primary/10">
                {formatCurrency(totalPeriod, true)}
              </TableCell>
              <TableCell className="text-right font-mono-numbers text-green-600 bg-green-500/10">
                {formatCurrency(totalMarginPeriod, true)}
              </TableCell>
              <TableCell className="text-right font-mono-numbers">
                {totalPeriod > 0 ? ((totalMarginPeriod / totalPeriod) * 100).toFixed(1) : 0}%
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </div>

      <p className="text-xs text-muted-foreground mt-3">
        💡 En mode "CA Global", les revenus et marges sont définis par canal. 
        Les COGS sont calculés automatiquement selon les taux de marge brute spécifiés pour chaque canal.
      </p>
    </SectionCard>
  );
}

// Helper pour calculer le CA depuis la config globale avec marges par canal
export function calculateGlobalRevenue(
  config: GlobalRevenueConfig,
  years: number[]
): { year: number; revenue: number; cogs: number }[] {
  return years.map((year, yearIndex) => {
    const b2c = config.B2C.baseAmount * Math.pow(1 + config.B2C.growthRate, yearIndex);
    const b2b = config.B2B.baseAmount * Math.pow(1 + config.B2B.growthRate, yearIndex);
    const oem = config.OEM.baseAmount * Math.pow(1 + config.OEM.growthRate, yearIndex);
    const revenue = b2c + b2b + oem;
    
    // COGS calculé à partir des marges spécifiques par canal
    const cogsB2C = b2c * (1 - (config.B2C.marginRate || 0.65));
    const cogsB2B = b2b * (1 - (config.B2B.marginRate || 0.45));
    const cogsOEM = oem * (1 - (config.OEM.marginRate || 0.25));
    const cogs = cogsB2C + cogsB2B + cogsOEM;
    
    return { year, revenue, cogs };
  });
}

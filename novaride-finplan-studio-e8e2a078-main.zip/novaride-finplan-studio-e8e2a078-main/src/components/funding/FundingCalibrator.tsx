import { useState } from 'react';
import { SectionCard, KPICard } from '@/components/ui/KPICard';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { formatCurrency, formatPercent } from '@/data/financialConfig';
import { cn } from '@/lib/utils';

interface FundingCalibratorProps {
  calculatedNeed: number;
  fundingNeedsByYear: { year: number; need: number; cumulative: number }[];
  currentRaiseAmount: number;
  preMoneyValuation: number;
  onUpdateRaiseAmount: (amount: number) => void;
  onUpdateValuation: (valuation: number) => void;
}

export function FundingCalibrator({
  calculatedNeed,
  fundingNeedsByYear,
  currentRaiseAmount,
  preMoneyValuation,
  onUpdateRaiseAmount,
  onUpdateValuation,
}: FundingCalibratorProps) {
  const [targetRaise, setTargetRaise] = useState(currentRaiseAmount);
  const [targetValuation, setTargetValuation] = useState(preMoneyValuation);
  
  const postMoneyValuation = targetValuation + targetRaise;
  const dilution = targetRaise / postMoneyValuation;
  const surplus = targetRaise - calculatedNeed;
  const runwayMonths = calculatedNeed > 0 ? Math.round((targetRaise / calculatedNeed) * 36) : 0;
  
  const handleRaiseChange = (value: number) => {
    setTargetRaise(value);
    onUpdateRaiseAmount(value);
  };
  
  const handleValuationChange = (value: number) => {
    setTargetValuation(value);
    onUpdateValuation(value);
  };
  
  // Calcul du gap par rapport au besoin calculé
  const coverageRatio = calculatedNeed > 0 ? targetRaise / calculatedNeed : 1;
  
  return (
    <SectionCard title="Calibrage de la Levée">
      <div className="grid md:grid-cols-2 gap-6">
        {/* Besoin calculé vs Montant cible */}
        <div className="space-y-6">
          <div className="p-4 bg-muted/30 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Besoin calculé (hypothèses)</span>
              <Badge variant="secondary">Auto</Badge>
            </div>
            <div className="text-3xl font-bold font-mono-numbers">
              {formatCurrency(calculatedNeed, true)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Basé sur CAPEX + RH + OPEX - CA sur la période
            </p>
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Montant à lever</span>
              <span className="text-lg font-bold font-mono-numbers">{formatCurrency(targetRaise, true)}</span>
            </div>
            <Slider
              value={[targetRaise / 1000]}
              onValueChange={([v]) => handleRaiseChange(v * 1000)}
              min={100}
              max={5000}
              step={50}
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>100k€</span>
              <span>5M€</span>
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Valorisation Pre-Money</span>
              <span className="text-lg font-bold font-mono-numbers">{formatCurrency(targetValuation, true)}</span>
            </div>
            <Slider
              value={[targetValuation / 1000000]}
              onValueChange={([v]) => handleValuationChange(v * 1000000)}
              min={1}
              max={20}
              step={0.5}
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>1M€</span>
              <span>20M€</span>
            </div>
          </div>
        </div>
        
        {/* Indicateurs résultants */}
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-muted/30 rounded-lg text-center">
              <div className="text-xs text-muted-foreground mb-1">Post-Money</div>
              <div className="text-lg font-bold font-mono-numbers">{formatCurrency(postMoneyValuation, true)}</div>
            </div>
            <div className="p-3 bg-muted/30 rounded-lg text-center">
              <div className="text-xs text-muted-foreground mb-1">Dilution</div>
              <div className={cn(
                "text-lg font-bold font-mono-numbers",
                dilution > 0.25 ? "text-destructive" : dilution > 0.20 ? "text-amber-600" : "text-green-600"
              )}>
                {formatPercent(dilution)}
              </div>
            </div>
          </div>
          
          <div className={cn(
            "p-4 rounded-lg border-2",
            surplus >= 0 ? "bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800" : 
                          "bg-red-50 border-red-200 dark:bg-red-950 dark:border-red-800"
          )}>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">
                {surplus >= 0 ? "Surplus / Réserve" : "Déficit de financement"}
              </span>
              <span className={cn(
                "text-lg font-bold font-mono-numbers",
                surplus >= 0 ? "text-green-600" : "text-destructive"
              )}>
                {surplus >= 0 ? '+' : ''}{formatCurrency(surplus, true)}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {surplus >= 0 
                ? `Marge de sécurité de ${formatPercent(surplus / targetRaise)}`
                : "Ajustez le montant ou réduisez les coûts"
              }
            </p>
          </div>
          
          <div className="p-4 bg-muted/30 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Couverture du besoin</span>
              <span className="font-mono-numbers">{formatPercent(coverageRatio)}</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className={cn(
                  "h-2 rounded-full transition-all",
                  coverageRatio >= 1 ? "bg-green-500" : coverageRatio >= 0.8 ? "bg-amber-500" : "bg-destructive"
                )}
                style={{ width: `${Math.min(coverageRatio * 100, 100)}%` }}
              />
            </div>
          </div>
          
          <div className="p-3 bg-muted/30 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-sm">Runway estimé</span>
              <span className={cn(
                "font-bold",
                runwayMonths >= 24 ? "text-green-600" : runwayMonths >= 18 ? "text-amber-600" : "text-destructive"
              )}>
                {runwayMonths} mois
              </span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Détail par année */}
      <div className="mt-6 pt-6 border-t">
        <h4 className="font-semibold mb-3">Besoins par Année</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {fundingNeedsByYear.map(({ year, need, cumulative }) => (
            <div key={year} className={cn(
              "p-3 rounded-lg text-center",
              need > 0 ? "bg-destructive/10" : "bg-muted/30"
            )}>
              <div className="font-medium">{year}</div>
              <div className={cn(
                "text-lg font-bold font-mono-numbers",
                need > 0 && "text-destructive"
              )}>
                {formatCurrency(need, true)}
              </div>
              <div className="text-xs text-muted-foreground">
                Σ {formatCurrency(cumulative, true)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </SectionCard>
  );
}

import { useFinancial } from '@/context/FinancialContext';
import { SectionCard } from '@/components/ui/KPICard';
import { formatCurrency } from '@/data/financialConfig';
import { cn } from '@/lib/utils';
import { Users, Wrench, TrendingUp, Building2, Megaphone, Computer, Package, DollarSign } from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from 'recharts';

const OPEX_COLORS: Record<string, string> = {
  'R&D': 'hsl(210, 70%, 50%)',
  'Production': 'hsl(150, 60%, 40%)',
  'Sales & Marketing': 'hsl(38, 92%, 50%)',
  'G&A': 'hsl(270, 50%, 50%)',
  'Logistics': 'hsl(180, 60%, 40%)',
  'IT & Tools': 'hsl(320, 60%, 50%)',
};

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  'R&D': <Wrench className="h-4 w-4" />,
  'Production': <Building2 className="h-4 w-4" />,
  'Sales & Marketing': <Megaphone className="h-4 w-4" />,
  'G&A': <TrendingUp className="h-4 w-4" />,
  'Logistics': <Package className="h-4 w-4" />,
  'IT & Tools': <Computer className="h-4 w-4" />,
};

export function FundsAllocationDisplay() {
  const { state, computed } = useFinancial();
  const { startYear, durationYears } = state.scenarioSettings;

  // Calculer les totaux sur la période
  const totalPayroll = computed.payrollByYear.reduce((sum, y) => sum + y.payroll, 0);
  const totalCapex = computed.capexByYear.reduce((sum, y) => sum + y.capex, 0);
  const totalOpex = computed.opexByYear.reduce((sum, y) => sum + y.opex, 0);

  // Agréger les OPEX par catégorie sur toute la période
  const opexByCategory: Record<string, number> = {};
  computed.opexByYear.forEach(yearData => {
    Object.entries(yearData.byCategory).forEach(([cat, val]) => {
      opexByCategory[cat] = (opexByCategory[cat] || 0) + val;
    });
  });

  // Agréger les CAPEX par produit
  const capexByProduct: Record<string, number> = {};
  state.products.forEach(product => {
    if (product.launchYear >= startYear && product.launchYear < startYear + durationYears) {
      capexByProduct[product.name] = product.devCost;
    }
  });

  // Données pour le pie chart principal
  const mainPieData = [
    { name: 'Masse Salariale', value: totalPayroll, color: 'hsl(0, 85%, 50%)' },
    { name: 'CAPEX (R&D)', value: totalCapex, color: 'hsl(210, 70%, 50%)' },
    { name: 'OPEX', value: totalOpex, color: 'hsl(38, 92%, 50%)' },
  ].filter(d => d.value > 0);

  const grandTotal = totalPayroll + totalCapex + totalOpex;

  // Données pour le pie chart OPEX détaillé
  const opexPieData = Object.entries(opexByCategory)
    .filter(([, val]) => val > 0)
    .map(([name, value]) => ({
      name,
      value,
      color: OPEX_COLORS[name] || 'hsl(0, 0%, 50%)',
    }));

  return (
    <SectionCard title="Allocation des Fonds (Projeté)">
      <div className="grid md:grid-cols-2 gap-6">
        {/* Pie Chart principal */}
        <div>
          <div className="h-48 mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={mainPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={70}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {mainPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => formatCurrency(value, true)} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Total général */}
          <div className="p-3 bg-muted/30 rounded-lg text-center mb-4">
            <div className="text-xs text-muted-foreground mb-1">Total sur {durationYears} ans</div>
            <div className="text-2xl font-bold font-mono-numbers">{formatCurrency(grandTotal, true)}</div>
          </div>

          {/* Résumé des 3 postes */}
          <div className="space-y-2">
            <div className="flex items-center justify-between p-2 rounded bg-destructive/10">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-destructive" />
                <span className="text-sm font-medium">Masse Salariale</span>
              </div>
              <span className="font-mono-numbers font-medium">{formatCurrency(totalPayroll, true)}</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded bg-primary/10">
              <div className="flex items-center gap-2">
                <Wrench className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium">CAPEX (R&D Produits)</span>
              </div>
              <span className="font-mono-numbers font-medium">{formatCurrency(totalCapex, true)}</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded bg-accent/10">
              <div className="flex items-center gap-2">
                <DollarSign className="h-4 w-4 text-accent" />
                <span className="text-sm font-medium">OPEX</span>
              </div>
              <span className="font-mono-numbers font-medium">{formatCurrency(totalOpex, true)}</span>
            </div>
          </div>
        </div>

        {/* Détails par catégorie */}
        <div className="space-y-4">
          {/* OPEX par catégorie */}
          <div>
            <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Détail OPEX par catégorie
            </h4>
            <div className="space-y-2">
              {Object.entries(opexByCategory)
                .sort(([, a], [, b]) => b - a)
                .map(([category, amount]) => (
                  <div key={category} className="flex items-center justify-between p-2 rounded bg-muted/30">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: OPEX_COLORS[category] }}
                      />
                      {CATEGORY_ICONS[category]}
                      <span className="text-sm">{category}</span>
                    </div>
                    <span className="font-mono-numbers text-sm">{formatCurrency(amount, true)}</span>
                  </div>
                ))}
            </div>
          </div>

          {/* CAPEX par produit */}
          {Object.keys(capexByProduct).length > 0 && (
            <div>
              <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Wrench className="h-4 w-4" />
                Détail CAPEX par produit
              </h4>
              <div className="space-y-2">
                {Object.entries(capexByProduct)
                  .sort(([, a], [, b]) => b - a)
                  .map(([product, amount]) => (
                    <div key={product} className="flex items-center justify-between p-2 rounded bg-muted/30">
                      <span className="text-sm">{product}</span>
                      <span className="font-mono-numbers text-sm">{formatCurrency(amount, true)}</span>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* Effectifs */}
          <div>
            <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Users className="h-4 w-4" />
              Évolution des effectifs
            </h4>
            <div className="space-y-2">
              {computed.payrollByYear.map(({ year, headcount, payroll }) => (
                <div key={year} className="flex items-center justify-between p-2 rounded bg-muted/30">
                  <span className="text-sm font-medium">{year}</span>
                  <div className="flex items-center gap-4">
                    <span className="text-xs text-muted-foreground">{headcount} pers.</span>
                    <span className="font-mono-numbers text-sm">{formatCurrency(payroll, true)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </SectionCard>
  );
}

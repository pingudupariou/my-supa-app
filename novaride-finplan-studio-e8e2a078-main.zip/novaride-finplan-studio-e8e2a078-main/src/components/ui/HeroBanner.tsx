import { cn } from '@/lib/utils';
import heroCcdEvo from '@/assets/hero-ccd-evo.jpg';
import heroRd from '@/assets/hero-rd.jpg';
import aboutBanner from '@/assets/about-banner.jpg';

const images = {
  'ccd-evo': heroCcdEvo,
  'rd': heroRd,
  'about': aboutBanner,
} as const;

interface HeroBannerProps {
  image: keyof typeof images;
  title?: string;
  subtitle?: string;
  className?: string;
  height?: 'sm' | 'md' | 'lg';
  overlay?: boolean;
}

export function HeroBanner({
  image,
  title,
  subtitle,
  className,
  height = 'sm',
  overlay = true,
}: HeroBannerProps) {
  const heightClasses = {
    sm: 'h-32',
    md: 'h-48',
    lg: 'h-64',
  };

  return (
    <div
      className={cn(
        'relative w-full rounded-lg overflow-hidden',
        heightClasses[height],
        className
      )}
    >
      <img
        src={images[image]}
        alt={title || 'Novatoride'}
        className="w-full h-full object-cover"
      />
      {overlay && (
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/30 to-transparent" />
      )}
      {(title || subtitle) && (
        <div className="absolute inset-0 flex flex-col justify-center p-6">
          {title && (
            <h2 className="text-white text-2xl font-bold tracking-tight">
              {title}
            </h2>
          )}
          {subtitle && (
            <p className="text-white/80 text-sm mt-1">{subtitle}</p>
          )}
        </div>
      )}
    </div>
  );
}

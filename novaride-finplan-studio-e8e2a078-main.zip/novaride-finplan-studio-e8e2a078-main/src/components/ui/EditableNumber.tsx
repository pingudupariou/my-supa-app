import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface EditableNumberProps {
  value: number;
  onChange: (value: number) => void;
  format?: 'currency' | 'percent' | 'number';
  className?: string;
  disabled?: boolean;
}

export function EditableNumber({
  value,
  onChange,
  format = 'currency',
  className,
  disabled = false,
}: EditableNumberProps) {
  const displayValue = format === 'percent' ? value * 100 : value;
  const suffix = format === 'currency' ? ' €' : format === 'percent' ? ' %' : '';

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/[^\d.-]/g, '');
    const num = parseFloat(raw) || 0;
    const finalValue = format === 'percent' ? num / 100 : num;
    onChange(finalValue);
  };

  return (
    <div className="relative">
      <Input
        type="text"
        value={displayValue.toLocaleString('fr-FR')}
        onChange={handleChange}
        disabled={disabled}
        className={cn(
          'input-financial h-8 pr-8',
          className
        )}
      />
      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-muted-foreground pointer-events-none">
        {suffix.trim()}
      </span>
    </div>
  );
}

import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface KPICardProps {
  label: string;
  value: string | number;
  subValue?: string;
  trend?: 'up' | 'down' | 'neutral';
  className?: string;
}

export function KPICard({ label, value, subValue, trend, className }: KPICardProps) {
  return (
    <div className={cn('financial-card p-4', className)}>
      <p className="kpi-label mb-1">{label}</p>
      <p className={cn(
        'kpi-value',
        trend === 'up' && 'positive-value',
        trend === 'down' && 'negative-value'
      )}>
        {value}
      </p>
      {subValue && (
        <p className="text-xs text-muted-foreground mt-1">{subValue}</p>
      )}
    </div>
  );
}

interface SectionCardProps {
  title: string;
  children: ReactNode;
  className?: string;
  action?: ReactNode;
  id?: string;
}

export function SectionCard({ title, children, className, action, id }: SectionCardProps) {
  return (
    <div id={id} className={cn('financial-card', className)}>
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <h3 className="font-semibold text-sm">{title}</h3>
        {action}
      </div>
      <div className="p-4">
        {children}
      </div>
    </div>
  );
}

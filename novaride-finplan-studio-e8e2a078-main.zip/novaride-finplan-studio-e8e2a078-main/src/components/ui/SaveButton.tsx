import { Button } from '@/components/ui/button';
import { Save, Check, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SaveButtonProps {
  onSave: () => void;
  hasUnsavedChanges: boolean;
  lastSaved?: Date | null;
  className?: string;
  size?: 'default' | 'sm' | 'lg' | 'icon';
}

export function SaveButton({
  onSave,
  hasUnsavedChanges,
  lastSaved,
  className,
  size = 'sm',
}: SaveButtonProps) {
  const formatLastSaved = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return "À l'instant";
    if (minutes < 60) return `Il y a ${minutes} min`;
    
    return date.toLocaleTimeString('fr-FR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className={cn('flex items-center gap-2', className)}>
      {lastSaved && !hasUnsavedChanges && (
        <span className="text-xs text-muted-foreground flex items-center gap-1">
          <Clock className="h-3 w-3" />
          {formatLastSaved(lastSaved)}
        </span>
      )}
      <Button
        variant={hasUnsavedChanges ? 'default' : 'outline'}
        size={size}
        onClick={onSave}
        disabled={!hasUnsavedChanges}
        className={cn(
          'transition-all',
          hasUnsavedChanges && 'animate-pulse-subtle'
        )}
      >
        {hasUnsavedChanges ? (
          <>
            <Save className="h-4 w-4 mr-1" />
            Sauvegarder
          </>
        ) : (
          <>
            <Check className="h-4 w-4 mr-1" />
            Sauvegardé
          </>
        )}
      </Button>
    </div>
  );
}

import { cn } from '@/lib/utils';

interface NovarideLogoProps {
  className?: string;
  variant?: 'full' | 'compact';
  color?: 'light' | 'dark' | 'accent';
}

export function NovarideLogo({ 
  className, 
  variant = 'full',
  color = 'light' 
}: NovarideLogoProps) {
  const colorClasses = {
    light: 'text-white',
    dark: 'text-foreground',
    accent: 'text-accent',
  };

  if (variant === 'compact') {
    return (
      <div className={cn('font-bold tracking-tight', colorClasses[color], className)}>
        <span className="text-accent">N</span>
        <span>R</span>
      </div>
    );
  }

  return (
    <div className={cn('flex flex-col', colorClasses[color], className)}>
      <div className="flex items-center gap-1">
        <svg 
          viewBox="0 0 24 24" 
          className="h-6 w-6 text-accent"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="10" />
          <path d="M12 2a10 10 0 0 1 0 20" fill="currentColor" fillOpacity="0.2" stroke="none" />
          <circle cx="12" cy="12" r="3" />
          <line x1="12" y1="5" x2="12" y2="9" />
          <line x1="12" y1="15" x2="12" y2="19" />
          <line x1="5" y1="12" x2="9" y2="12" />
          <line x1="15" y1="12" x2="19" y2="12" />
        </svg>
        <span className="text-lg font-bold tracking-wider">
          NOVA<span className="text-accent">RIDE</span>
        </span>
      </div>
      <span className="text-[10px] tracking-widest text-muted-foreground uppercase">
        Financial Planner
      </span>
    </div>
  );
}
